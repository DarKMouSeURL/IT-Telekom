﻿namespace ProjektWindowsFormsApp1
{
    partial class Projekt1Forms
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.panel1 = new System.Windows.Forms.Panel();
            this.buttondoleva = new System.Windows.Forms.Button();
            this.buttondoprava = new System.Windows.Forms.Button();
            this.buttonnahoru = new System.Windows.Forms.Button();
            this.buttondolu = new System.Windows.Forms.Button();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.buttonstop = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // colorDialog1
            // 
            this.colorDialog1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gold;
            this.panel1.Location = new System.Drawing.Point(142, 48);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(186, 109);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // buttondoleva
            // 
            this.buttondoleva.Location = new System.Drawing.Point(2, 351);
            this.buttondoleva.Name = "buttondoleva";
            this.buttondoleva.Size = new System.Drawing.Size(114, 116);
            this.buttondoleva.TabIndex = 1;
            this.buttondoleva.Text = "doleva";
            this.buttondoleva.UseVisualStyleBackColor = true;
            this.buttondoleva.Click += new System.EventHandler(this.buttondoleva_Click);
            // 
            // buttondoprava
            // 
            this.buttondoprava.Location = new System.Drawing.Point(265, 351);
            this.buttondoprava.Name = "buttondoprava";
            this.buttondoprava.Size = new System.Drawing.Size(109, 116);
            this.buttondoprava.TabIndex = 2;
            this.buttondoprava.Text = "doprava";
            this.buttondoprava.UseVisualStyleBackColor = true;
            this.buttondoprava.Click += new System.EventHandler(this.buttondoprava_Click);
            // 
            // buttonnahoru
            // 
            this.buttonnahoru.Location = new System.Drawing.Point(122, 224);
            this.buttonnahoru.Name = "buttonnahoru";
            this.buttonnahoru.Size = new System.Drawing.Size(137, 121);
            this.buttonnahoru.TabIndex = 3;
            this.buttonnahoru.Text = "nahoru";
            this.buttonnahoru.UseVisualStyleBackColor = true;
            this.buttonnahoru.Click += new System.EventHandler(this.buttonnahoru_Click);
            // 
            // buttondolu
            // 
            this.buttondolu.Location = new System.Drawing.Point(117, 473);
            this.buttondolu.Name = "buttondolu";
            this.buttondolu.Size = new System.Drawing.Size(142, 117);
            this.buttondolu.TabIndex = 4;
            this.buttondolu.Text = "dolu";
            this.buttondolu.UseVisualStyleBackColor = true;
            this.buttondolu.Click += new System.EventHandler(this.buttondolu_Click);
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.numericUpDown1.Location = new System.Drawing.Point(12, 12);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            52,
            0,
            0,
            0});
            this.numericUpDown1.Minimum = new decimal(new int[] {
            52,
            0,
            0,
            -2147483648});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(53, 30);
            this.numericUpDown1.TabIndex = 5;
            this.numericUpDown1.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numericUpDown1.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // buttonstop
            // 
            this.buttonstop.Location = new System.Drawing.Point(122, 351);
            this.buttonstop.Name = "buttonstop";
            this.buttonstop.Size = new System.Drawing.Size(136, 115);
            this.buttonstop.TabIndex = 6;
            this.buttonstop.Text = "zastavitcasovac";
            this.buttonstop.UseVisualStyleBackColor = true;
            this.buttonstop.Click += new System.EventHandler(this.buttonstop_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LightGreen;
            this.panel2.Location = new System.Drawing.Point(490, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(846, 444);
            this.panel2.TabIndex = 7;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // Projekt1Forms
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1684, 961);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.buttonstop);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.buttondolu);
            this.Controls.Add(this.buttonnahoru);
            this.Controls.Add(this.buttondoprava);
            this.Controls.Add(this.buttondoleva);
            this.Controls.Add(this.panel1);
            this.Name = "Projekt1Forms";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Projekt1Forms_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.Projekt1Forms_Paint);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button buttondoleva;
        private System.Windows.Forms.Button buttondoprava;
        private System.Windows.Forms.Button buttonnahoru;
        private System.Windows.Forms.Button buttondolu;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button buttonstop;
        private System.Windows.Forms.Panel panel2;
    }
}

