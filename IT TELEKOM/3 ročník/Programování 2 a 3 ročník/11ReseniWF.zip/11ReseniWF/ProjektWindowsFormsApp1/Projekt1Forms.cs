﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjektWindowsFormsApp1
{
    public partial class Projekt1Forms : Form
    {
        public Projekt1Forms()
        {
            InitializeComponent();
        }
        private void Projekt1Forms_Load(object sender, EventArgs e)
        {
            //colorDialog1.ShowDialog();
            //this.BackColor = colorDialog1.Color;
            this.auto = Image.FromFile("auto1.png");
            //panel2.Refresh();

        }
        private void Projekt1Forms_Paint(object sender, PaintEventArgs e)
        {
            //Graphics papir = e.Graphics;

            //papir.DrawRectangle(Pens.Red, 0, 0, 500, 200);
            //papir.DrawEllipse(Pens.Blue, 0, 0, 500, 200);
        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            Graphics papir = e.Graphics;
            papir.DrawRectangle(Pens.Blue, 50, 70, 80, 30);
            papir.DrawRectangle(Pens.Blue, 50, 50, 35, 20);
            papir.DrawEllipse(Pens.Red, 50, 90, 20, 20);
            papir.DrawEllipse(Pens.Red, 110, 90, 20, 20);
        }
        private void buttondoleva_Click(object sender, EventArgs e)
        {
            //panel1.Left = panel1.Left - 5;
            panel1.Left = panel1.Left - (int)(numericUpDown1.Value);
        }
        private void buttondoprava_Click(object sender, EventArgs e)
        {
            //panel1.Left = panel1.Left + 5;
            panel1.Left = panel1.Left + (int)(numericUpDown1.Value);
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            //panel1.Left = panel1.Left - (int)(numericUpDown1.Value);

            if (panel1.Left < 0)
            {
                panel1.Left =1000;
            }
            else if (panel1.Left > 1600)
            {
                panel1.Left = 200;
            }
            else
            {
                panel1.Left = panel1.Left + (int)(numericUpDown1.Value);
            }
            panel2.Left = panel2.Left - (int)numericUpDown1.Value;
            panel2.Top = panel2.Top - (int)numericUpDown1.Value;
        }
        Image auto = null;
        private void buttonstop_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            //this.auto = Image.FromFile("auto1.png");
            //panel2.Refresh();
        }
        private void buttonnahoru_Click(object sender, EventArgs e)
        {
            panel1.Top = panel1.Top - (int)(numericUpDown1.Value);
        }
        private void buttondolu_Click(object sender, EventArgs e)
        {
            panel1.Top = panel1.Top + (int)(numericUpDown1.Value);
        }
        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }
        private void panel2_Paint(object sender, PaintEventArgs e)
        {
            Graphics papir = e.Graphics;
            if (auto != null)
            {
                papir.DrawImage(auto, 0, 0);
            }
        }
    }
}
