import java.util.*;
public class Main extends Tvaroh{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Golo k = new Golo(10);
        System.out.println(k);
        System.out.println("Obvod: "+k.VypocitatObvod());
        System.out.println("Obsah: " + k.VypocitatObsah());

        Obelnik m = new Obelnik(3,4);
        m.Nakreslit();

        Tvaroh[] poleTvaru = new Tvaroh[6];
        System.out.println("Vstupy");

        //uzivatel zada sirku a vysku pro prvni obelnik
        System.out.print("Obelnik Zadej prvni rozmer pls: ");
        int prvni = Integer.parseInt(sc.nextLine());
        System.out.print("Obelnik Zadej druhy rozmer pls: ");
        int druhy = Integer.parseInt(sc.nextLine());
        Obelnik o1 = new Obelnik(prvni, druhy);
        poleTvaru[0]= o1;

        Obelnik o2 = new Obelnik(10, 1);
        poleTvaru[1] = o2;

        //kocka
        System.out.print("Kocka Zadej rozmer pls: ");
        prvni = sc.nextInt();

        Kocka c1 = new Kocka(prvni);
        poleTvaru[2] = c1;

        Kocka c2 = new Kocka(3);
        poleTvaru[3] = c2;

        //golo
        System.out.print("Golo Zadej prvni rozmer pls: ");
        prvni = sc.nextInt();

        Golo g1 = new Golo(prvni);
        poleTvaru[4] = g1;

        Golo g2 = new Golo(8);
        poleTvaru[5] = g2;

        System.out.println();

        for (Tvaroh tvar : poleTvaru){
            System.out.println("Metoda ToString() pro => " + tvar.toString());
            System.out.println("Obvod je " + tvar.VypocitatObvod());
            System.out.println("Obsah je " + tvar.VypocitatObsah());
            tvar.Nakreslit();
            System.out.println();
        }
    }
}