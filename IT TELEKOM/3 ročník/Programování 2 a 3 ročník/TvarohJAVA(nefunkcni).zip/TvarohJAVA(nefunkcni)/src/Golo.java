public class Golo extends Tvaroh {
    public Golo() { }

    public Golo(int sirka){

    }
    
    @Override
    public void Nakreslit() {
        System.out.println("Kruh neni jednoduche v konzoli nakreslit");
    }

    @Override
    public double VypocitatObvod(){
        return 2 * Math.PI * (sirka / 2);
    }

    @Override
    public double VypocitatObsah(){
        return Math.PI + Math.pow(sirka / 2, 2);
    }

    @Override
    public String toString(){
        return "kruh " + super.toString();
    }
}
