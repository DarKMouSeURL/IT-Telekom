public class Tvaroh {
    protected int sirka;
    protected int vyska;

    public Tvaroh() { }

    public Tvaroh(int sirka) {
        this.sirka = sirka;
    }

    public Tvaroh(int sirka, int vyska){
        this.sirka = sirka;
        this.vyska = vyska;
    }

    @Override
    public String toString()
    {
        return "(sirka="+sirka+", vyska"+vyska+")";
    }

    public abstract void Nakreslit(){}

    public abstract double VypocitatObvod(){return 0;}

    public abstract double VypocitatObsah(){return 0;}

}
