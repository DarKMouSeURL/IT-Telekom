public class Kocka extends Obelnik{
    public Kocka() { }

    public Kocka(int sirka) { }

    @Override
    public String toString(){
        return "ctverec je specialni -> "+super.toString();
    }
}
