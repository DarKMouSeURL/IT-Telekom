public class Obelnik extends Tvaroh{
    public Obelnik() { }
    public Obelnik(int sirka, int vyska){ }

    @Override
    public void Nakreslit(){
        for (int j = 0; j < sirka; j++){
            for (int k = 0; k < vyska; k++){
                System.out.print("■ ");

            }
            System.out.println();
        }
    }

    @Override
    public double VypocitatObsah(){
        return sirka*vyska;
    }

    @Override
    public double VypocitatObvod(){
        return 2*vyska+2*sirka;
    }

    @Override
    public String toString(){
        return "obdelnik " + super.toString();
    }
}
