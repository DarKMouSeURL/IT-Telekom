﻿using System.Diagnostics.CodeAnalysis;

namespace ConsoleApp4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int souc = 0;
            int pocet = 0;
            for (int i = 30; i <= 130; i+=2)
            {
                if (i%2==0)
                {
                    pocet++;
                    souc += i;
                }
            }
            Console.WriteLine((double)souc/(double)pocet);
            
        }
    }
}