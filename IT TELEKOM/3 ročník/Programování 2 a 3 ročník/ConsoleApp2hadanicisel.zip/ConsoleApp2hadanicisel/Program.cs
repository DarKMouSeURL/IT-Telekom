﻿using System;

internal class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("hra hadani cisel");

        //int cislotajne = 12;

        int cislotajne = new Random() .Next(20);   //od 0 do 19
        //Console.WriteLine(cislotajne);
 
        while (true)
        {
            Console.WriteLine();
            Console.Write("zadej cislo od 0 do 19: ");

            string klavesnice = Console.ReadLine();
            int cislozadane = Convert.ToInt32(klavesnice);

            if (cislotajne == cislozadane)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.BackgroundColor = ConsoleColor.DarkMagenta;

                Console.WriteLine("Vyhral jsi! Frajer");

                Console.ForegroundColor = ConsoleColor.Gray;
                Console.BackgroundColor = ConsoleColor.Black;
                break;
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.BackgroundColor = ConsoleColor.Yellow;

                Console.WriteLine("Prohral jsi! Zkus znova");

                Console.ForegroundColor= ConsoleColor.Gray;
                Console.BackgroundColor = ConsoleColor.Black;
                if (cislotajne > cislozadane)
                {
                    Console.WriteLine("More pridaj");
                }
                else
                {
                    Console.WriteLine("To je zas moc");
                }
            }
        }

        Console.WriteLine();
        Console.WriteLine("Zkus znova - stikni enter");
        Console.ReadLine();
    }
}