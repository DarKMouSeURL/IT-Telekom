﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace koctka
{
    public class Kostka : Panel
    {
        //Button b1 = null;
        Puntik b1 = null;
        Puntik b6 = null;
        Puntik b7 = null;
        Puntik b3 = null;
        Puntik b4 = null;
        Puntik b5 = null;
        Puntik b2 = null;


        public static Random lz = new Random();


        public Kostka()
        {
            //clenske promene
            this.BackColor = Color.AliceBlue;
            this.Width = 300;
            this.Height = 300;

            this.b1 = new Puntik(this,40,30);
            this.b6 = new Puntik(this,230, 240);
            this.b7 = new Puntik(this, 135, 135);
            this.b2 = new Puntik(this, 40, 135);
            this.b3 = new Puntik(this, 40, 240);
            this.b4 = new Puntik(this, 230, 30);
            this.b5 = new Puntik(this, 230, 135);
        }
        public void Smazat()
        {
            this.b1.Visible = false;
            this.b7.Visible = false;
            this.b6.Visible = false;
            this.b2.Visible = false;
            this.b3.Visible = false;
            this.b4.Visible = false;
            this.b5.Visible = false;
        }
        public void zobrazait(int hod)
        {
            if (hod == 1)
            {
                this.b7.Visible = true;
            }
            if (hod == 2)
            {
                this.b1.Visible = true;
                this.b6.Visible = true;
            }

            if (hod == 3)
            {
                this.b1.Visible = true;
                this.b6.Visible = true;
                this.b7.Visible = true;
            }
            if (hod == 4)
            {
                this.b1.Visible = true;
                this.b3.Visible = true;
                this.b4.Visible = true;
                this.b6.Visible = true;
            }
            if (hod == 5)
            {
                this.b1.Visible = true;
                this.b3.Visible = true;
                this.b4.Visible = true;
                this.b6.Visible = true;
                this.b7.Visible = true;
            }
            if (hod == 6)
            {
                this.b1.Visible = true;
                this.b3.Visible = true;
                this.b4.Visible = true;
                this.b6.Visible = true;
                this.b2.Visible = true;
                this.b5.Visible = true;
            }



        }
        public void Hodit()
        {
            this.Smazat();
            int hod = lz.Next(6) + 1;
            this.zobrazait(hod);
        }
    }

}
