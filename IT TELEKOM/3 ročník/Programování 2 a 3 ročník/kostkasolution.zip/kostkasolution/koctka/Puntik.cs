﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace koctka
{
    public class Puntik : Button
    {
        //vice paramerticky konstruktor
        public Puntik(Kostka kostka, int zleva, int zezhora)
        {
            this.Parent = kostka;
            this.BackColor = Color.Red;
            this.Enabled = false;
            this.Width = 40;
            this.Height = 40;
            this.Left = zleva;
            this.Top = zezhora;
        }
    }
}
