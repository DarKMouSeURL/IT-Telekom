﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace koctka
{
    public partial class Form1 : Form
    {
        Color barva = Color.Blue;
        public Form1()
        {
            InitializeComponent();
            Kostka kostka1 = new Kostka();
            kostka1.Parent = this;
            kostka1.Hodit();
            Kostka kostka2 = new Kostka();
            kostka2.Parent = this;
            kostka2.BackColor = Color.Lavender;
            kostka2.Left = 350;
            kostka2.Hodit();
            Kostka kostka3 = new Kostka();
            kostka3.Parent = this;
            kostka3.BackColor = Color.SandyBrown;
            kostka3.Left = 700;
            kostka3.Hodit();
            Kostka kostka4 = new Kostka();
            kostka4.Parent = this;
            kostka4.BackColor = Color.GhostWhite;
            kostka4.Left = 1050;
            kostka4.Hodit();


        }

        private void fileSystemWatcher1_Changed(object sender, System.IO.FileSystemEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void barva_Click(object sender, EventArgs e)
        {
            colorDialog1.ShowDialog();
        }
    }
    /*
    public class Kostka : Panel
    {
        Button b1 = null;
        Button b6 = null;
        Button b7 = null;
        public static Random lz = new Random();


        public Kostka()
        {
            //clenske promene
            this.BackColor = Color.AliceBlue;
            this.Width = 300;
            this.Height = 300;
            this.b1 = new Button();
            this.b1.Parent = this;
            this.b1.BackColor = Color.Red;
            this.b1.Enabled = false;
            this.b1.Width = 40;
            this.b1.Height = 40;
            this.b1.Left = 40;
            this.b1.Top = 30;

            this.b6 = new Button();
            this.b6.Parent = this;
            this.b6.BackColor = Color.Red;
            this.b6.Enabled = false;
            this.b6.Width = 40;
            this.b6.Height = 40;
            this.b6.Left = 230;
            this.b6.Top = 230;

            this.b7 = new Button();
            this.b7.Parent = this;
            this.b7.BackColor = Color.Red;
            this.b7.Enabled = false;
            this.b7.Width = 40;
            this.b7.Height = 40;
            this.b7.Left = 130;
            this.b7.Top = 130;
        }
        public void Smazat()
        {
            this.b1.Visible = false;
            this.b7.Visible = false;
            this.b6.Visible = false;
        }
        public void zobrazait(int hod)
        {
            if (hod == 1)
            {
                this.b7.Visible = true;
            }
            if (hod == 2)
            {
                this.b1.Visible = true;
                this.b6.Visible = true;
            }

            if (hod == 3)
            {
                this.b1.Visible = true;
                this.b6.Visible = true;
                this.b7.Visible = true;
            }


        }
        public void Hodit()
        {
            this.Smazat();
            int hod = lz.Next(3) + 1;
            this.zobrazait(hod);
        }
    }
    */
}

    