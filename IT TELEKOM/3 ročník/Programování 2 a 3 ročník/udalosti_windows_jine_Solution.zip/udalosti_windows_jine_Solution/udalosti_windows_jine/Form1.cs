﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace udalosti_windows_jine
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //colorDialog1.ShowDialog();
            //this.BackColor = colorDialog1.Color;
        }
        private void Form1_BackColorChanged(object sender, EventArgs e)
        {
        }

        private void Form1_Click(object sender, EventArgs e)
        {
        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {

        }

        private void button1_BackColorChanged(object sender, EventArgs e)
        {
            //MessageBox.Show("stopka button1");
            button2.BackColor = Color.Green;
        }

        private void button2_BackgroundImageChanged(object sender, EventArgs e)
        {
            button3.Text = "zmena na trojce";
        }

        private void button3_TextChanged(object sender, EventArgs e)
        {
            button4.BackColor = Color.Red;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            button1.Text = "button1";
            button2.Text = "button2";
            button3.Text = "button3";
            button4.Text = "button4";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            button1.BackColor = Color.Green;
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics papir = e.Graphics;
            papir.DrawLine(Pens.Red, 0, 0, 300, 200);
            papir.DrawEllipse(Pens.Blue, 100, 500, 700, 450);
            papir.DrawRectangle(Pens.Magenta, 100, 500, 300, 50);
        }
    }
}
