﻿// See https://aka.ms/new-console-template for more information
using UzivRozhraniConsole;

UzivRozhrani.Run();
