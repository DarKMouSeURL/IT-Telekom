﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EditaceTextuLibrary;

namespace UzivRozhraniConsole

{
    static class UzivRozhrani
    {
        //DELSP, SUBSTR, CHECKP, HELP, EXIT

        public static void Run()
        {
            Console.WriteLine("--- Vítejte v Textovém editoru ---");
            string prikaz="";
            do
            {
                Console.Write("\r\nCommand: ");
                prikaz = Console.ReadLine().Trim().ToUpper();
                RozcestnikPrikazu(prikaz);

            } while (!prikaz.Equals("EXIT"));
        }

        public static void RozcestnikPrikazu(string prikaz)
        {
            switch (prikaz)
            {
                case "DELSP": DELSPCommand();    break;
                case "SUBSTR": SUBSTRCommand(); break;
                case "CHECKP": CHECKPCommand();  break;
                case "HELP": HELPCommand(); break;
                case "EXIT": Console.WriteLine("Program bude nyní ukončen"); break;
                default: Console.WriteLine("Příkaz neexistuje, pokračujte příkazem help"); break;                   
            }
        }

        public static void SUBSTRCommand()
        {
            Console.WriteLine("Metoda vrací požadovaný výsek textu");
            Console.Write("Zadej text: ");
            string text = Console.ReadLine();
            string vysledek;

            try
            {
                Console.Write("Zadej číslo prvího znaku: ");
                int _od = int.Parse(Console.ReadLine());
                Console.Write("Zadej číslo posledního znaku: ");
                int _do = int.Parse(Console.ReadLine());

                if (_od > _do)
                    throw new Exception(); //vyvolá se výjimka, ikdyž se nejedná o kritickou chybu
                else
                    vysledek = UpravyTextu.VratVysekTextu(text, _od, _do);
            }
            catch (Exception)
            {
                vysledek = "Chyba při zadávání mezí, opakujte akci!";
            }
           
            Console.WriteLine($"Výsledek: {vysledek}");
        }

        public static void CHECKPCommand()
        {
            Console.WriteLine("Metoda ověřuje palindom");
            Console.Write("Zadej text: ");
            string text = Console.ReadLine();
            if (UpravyTextu.OverPalindrom(text))
                Console.WriteLine("Zadaný text je palindrom :)");
            else
                Console.WriteLine("Zadaný text není palindrom :(");
        }

        public static void DELSPCommand()
        {
            Console.WriteLine("Mazání mezer v textu");
            Console.Write("Zadej text: ");
            string text = Console.ReadLine();
            Console.WriteLine("Výsledek: " + UpravyTextu.OdstranMezery(text));
        }

        public static void HELPCommand()
        {
            Console.WriteLine("Nápověda:");
            Console.WriteLine("   - delsp".PadRight(15)+   "smaže všechny mezery v textu");
            Console.WriteLine("   - substr".PadRight(15)+  "zobrazí výňatek textu");
            Console.WriteLine("   - checkp".PadRight(15)+  "Ověř, zda text je palindrom");
            Console.WriteLine("   - help".PadRight(15)+    "Zobraz nápovědu");
            Console.WriteLine("   - exit".PadRight(15)+    "Ukonči program");

        }
    }
}
