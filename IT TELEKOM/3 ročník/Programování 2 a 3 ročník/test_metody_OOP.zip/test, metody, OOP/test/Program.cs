﻿namespace test
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Kostka kostka = new Kostka();

            Console.WriteLine(kostka.Hod());
            Console.WriteLine(kostka.ZmenPocetSten(9));
            kostka.Diagnostika();
        }
    }
}
