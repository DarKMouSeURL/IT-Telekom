﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test
{
    internal class Kostka
    {
        int pocetstran = 6;

        public int Hod()
        { 
            Random rnd = new Random();
            return rnd.Next(1,pocetstran+1);
        }

        public bool ZmenPocetSten(int novypocet)
        {
            if (novypocet <2)
                return false;
            else
                pocetstran = novypocet;
                return true;
        }

        public void Diagnostika()
        {
            if (pocetstran % 2 == 0)
                Console.WriteLine("sudé");
            else
                Console.WriteLine("liché");
        }
    }
}
