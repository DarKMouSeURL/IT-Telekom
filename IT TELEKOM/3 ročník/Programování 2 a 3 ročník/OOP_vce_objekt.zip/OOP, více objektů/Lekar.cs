﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp11
{
    internal class Lekar
    {
        public string jmeno;
        public string telefon;
        public string adresaOrdinace;

        public Lekar(string jmeno, string telefon, string adresaOrdinace)
        {
            this.jmeno = jmeno;
            this.telefon = telefon;
            this.adresaOrdinace = adresaOrdinace;
        }

        public override string ToString()
        {
            return jmeno;
        }
    }
}
