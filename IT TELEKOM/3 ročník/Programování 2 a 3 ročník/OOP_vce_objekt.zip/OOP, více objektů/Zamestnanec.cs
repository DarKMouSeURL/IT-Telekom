﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp11
{
    internal class Zamestnanec
    {
        public string jmeno;
        public bool zdravotniomezeni;
        public int odpracovaneroky;
        public Lekar osetrujicilekar;
        public DateTime datumnarozeni;

        public Zamestnanec(string jmeno, bool zdravotniomezeni, int odpracovaneroky, Lekar osetrujicilekar, DateTime datumnarozeni)
        {
            this.jmeno = jmeno;
            this.zdravotniomezeni = zdravotniomezeni;
            this.odpracovaneroky = odpracovaneroky;
            this.osetrujicilekar = osetrujicilekar;
            this.datumnarozeni = datumnarozeni;
        }

        public override string ToString()
        {
            if (zdravotniomezeni == true)
                return string.Format($"{jmeno}, odpracovano: {odpracovaneroky} let, zdravotni omezeni: ano, datum narozeni {datumnarozeni.ToLongDateString()}, vek {2024 - datumnarozeni.Year}");
            else
                return string.Format($"{jmeno}, odpracovano: {odpracovaneroky} let, zdravotni omezeni: ne, datum narozeni {datumnarozeni.ToLongDateString()}, vek {2024 - datumnarozeni.Year}");
            string ome = zdravotniomezeni ? "ano" : "ne";
            return string.Format($"{jmeno}, odpracovano: {odpracovaneroky} let, zdravotni omezeni: {ome}, datum narozeni {datumnarozeni.ToLongDateString()}, vek {2024 - datumnarozeni.Year}");

        }
    }
}
