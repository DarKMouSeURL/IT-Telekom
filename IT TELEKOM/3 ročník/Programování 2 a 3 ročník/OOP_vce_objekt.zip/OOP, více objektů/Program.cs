﻿namespace ConsoleApp11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            DateTime cd1 = new DateTime(1999, 12, 2);
            Zamestnanec zamestnanec = new Zamestnanec("Martin", false, 15, {osetrujici}, cd1);
            Zamestnanec zamestnanec1 = new Zamestnanec("Petra", true, 51, , new DateTime(2000, 2, 5));
            Console.WriteLine(zamestnanec);
            Console.WriteLine(zamestnanec1);
            Lekar lekar = new Lekar("Mudr. Vlasta ticha", "16545656", "fdsf");
           
        }
    }
}