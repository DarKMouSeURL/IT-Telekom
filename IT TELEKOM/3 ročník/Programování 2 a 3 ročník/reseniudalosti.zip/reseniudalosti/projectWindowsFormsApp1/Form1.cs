﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projectWindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.BackColor = Color.RoyalBlue;
            this.Text = "okno na pokusy";
            this.Width = 1700;
            this.Height = 200;
            this.MaximizeBox = false;
        }

        private void Form1_MouseEnter(object sender, EventArgs e)
        {
            this.BackColor = Color.DarkRed;
        }

        private void Form1_MouseLeave(object sender, EventArgs e)
        {
            this.BackColor= Color.RoyalBlue;
        }

        private void Form1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Nastala udalost Click na Form1");
            this.Width = 800;
            this.Height = 600;
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            MessageBox.Show("udalost FormCosed...");
        }
    }
}
