﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace deleni_vetveni
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // vstup
            Console.WriteLine("delenec: ");
            int delenec = int.Parse(Console.ReadLine());
            Console.WriteLine("delitel: ");
            int delitel = int.Parse(Console.ReadLine());
            
            double podil = delenec / delitel;
            Console.WriteLine(podil); //celociselne deleni, kdyz jsou INT

            Console.WriteLine("zbytek po celociselnem deleni");
            double zbytek = delenec % delitel;
            Console.WriteLine($@"zbytek po celociselnem deleni ""{zbytek}""");

             //kdyz aspon JEDEN je BOUBLE
            double podild = (double)delenec / (double)delitel;
            Console.WriteLine(podild);

            if (delitel != 0)
            {
                double podil4 = delenec / delitel;
                Console.WriteLine(podil4);                
            }
        }
    }   

}
