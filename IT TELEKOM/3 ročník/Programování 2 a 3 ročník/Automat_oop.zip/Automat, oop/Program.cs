﻿using System.Security.Cryptography;

namespace ConsoleApp9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*
            Automat a1 = new Automat("CocaCola", 12, true);
            Console.Write("Znacka: ");
            string zna = Console.ReadLine();
            Console.Write("Pocet napoju: ");
            decimal poce = decimal.Parse(Console.ReadLine());
            Console.Write("Vraci? ");
            string h = Console.ReadLine();
            bool j = false;
            

            if (h.ToLower() == "a")
                j= true;
            */
            bool k = true;
            bool j = false;
            int g = 3;
            while (k == true)
            {
                Automat a1 = new Automat("CocaCola", 12, true);
                Console.Write("Znacka: ");
                string zna = Console.ReadLine();
                Console.Write("Pocet napoju: ");
                decimal poce = decimal.Parse(Console.ReadLine());
                Console.Write("Vraci? ");
                string h = Console.ReadLine();

                if (h.ToLower() == "a")
                    j = true;

                Automat a2 = new Automat(zna, poce, j);
                Console.WriteLine(a2.ToString());
                Automat a[g] = a2;
                Console.Write("Znovu? ");
                string od = Console.ReadLine();
                if (od.ToLower() == "n")
                {
                    k = false;
                }
                g++;
            }
           
            /*
            Console.WriteLine(a1.ToString());
            Console.WriteLine(a2.ToString());
            */

        }
    }
}