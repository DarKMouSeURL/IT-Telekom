﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp9
{
    internal class Automat
    {
        public string znacka;
        public decimal pocetnapoju;
        public bool vraci = true;

        public Automat(string znacka, decimal pocetnapoju, bool vraci)
        {
            this.znacka = znacka;
            this.pocetnapoju = pocetnapoju;
            this.vraci = vraci;
        }
        public override string ToString()
        {
            return string.Format($"znacka: {znacka}, kolik ma pocet napoju: {pocetnapoju}, vraci: {vraci}.");
        }
    }
}
