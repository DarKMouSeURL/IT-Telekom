﻿using System.Security.Authentication.ExtendedProtection;

namespace ConsoleApp5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] nasobilka = new int[10];
            nasobilka[0] = 0;
            nasobilka[nasobilka.Length - 1] = 0;
            for (int i = 0; i < nasobilka.Length; i++)
            {
                nasobilka[i] = 5 * i;
                nasobilka[0] = 0;
                nasobilka[nasobilka.Length - 1] = 0;
                if (nasobilka[i] %2==0)
                    Console.WriteLine(nasobilka[i]);
                
            }
            Console.WriteLine();

            Random rnd = new Random();
            int[] merak = new int[60];
            for (int i = 0; i < merak.Length; i++)
            {
                int num = rnd.Next(-100, 101);
                merak[i] = num;
                Console.Write(merak[i] + ",");
            }
            Console.WriteLine();

            Console.WriteLine(merak[0]);
            Console.WriteLine(merak[merak.Length-1]);

            Console.WriteLine("Max v meraku: " + merak.Max(x => x));
            Console.WriteLine("Min v meraku: " + merak.Min());

            int kladne = 0;
            int zaporne = 0;
            int nula = 0;
            int prumer = 0;

            for (int i = 0; i < merak.Length; i++)
            {
                if (merak[i] < 0)
                {
                    kladne++;
                }
                if (merak[i] > 0)
                {
                    zaporne++;
                }
                if (merak[i] == 0)
                {
                    nula++;
                }
                prumer = merak[i + 1];
            }
            prumer /= merak.Length-1    ;
            Console.WriteLine("Hodnot kladnych je: " + kladne);
            Console.WriteLine("Hodnot zaporne je: " + zaporne);
            Console.WriteLine("Hodnot nulovych je: " + nula);

            Console.WriteLine("prumer je: " + prumer);


        }
    }
}