﻿using System;
using System.Security.Cryptography.X509Certificates;
using System.Threading;

namespace diagnostika_cisla
{
    internal class Program
    {
        static void Main(string[] args)
        {
        start:
            Console.Write("napis cislo na diagnostiku: ");
            int cislo = int.Parse(Console.ReadLine());
            if (cislo > 0)
                Console.WriteLine("kladne");
            else if (cislo < 0)
                Console.WriteLine("zaporne");
            else
                Console.WriteLine("NULA");

            if (cislo % 2 == 0)
                Console.WriteLine("sude");
            else
                Console.WriteLine("liche");

            Console.Write("absolutni hodnota je: ");
            if (cislo < 0)
                Console.WriteLine(cislo * -1);
            else
                Console.WriteLine(cislo);

            Console.WriteLine("znovu? (a/n)");
            string odpoved = Console.ReadLine().Trim().ToLower();
            if (odpoved.Equals("a"))
                goto start;

            //intervaly
            double y = 16;
            if (y > -5 && y <= 10)
                Console.WriteLine("neco");

            if ((y < -5) || (y >= 5)) 
                Console.WriteLine(y);

            int x = 20;
            if (x >= -10 && x % 2 != 0)
                Console.WriteLine($"1) {x}");
            if (x>= -10 && x<= 10 )
                Console.WriteLine($"2) {x}");
            if (x > -10 && x < 10)
                Console.WriteLine($"3) {x}");
            if ( x < -10 || x >10)
                Console.WriteLine($"4) {x}");
            if (x > 100 || x % 2 ==0)
                Console.WriteLine($"5) {x}");
            if (x <= 0)
                Console.WriteLine($"6) {x}");


        }
    }
}
