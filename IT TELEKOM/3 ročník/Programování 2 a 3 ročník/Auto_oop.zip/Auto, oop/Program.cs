﻿namespace ConsoleApp8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Auto a1 = new Auto("Mergl", 5, 456, "789R5J45D2");

            Auto a2 = new Auto();
            a2.znacka = "Toyota";
            a2.vykonHP = 40;
            a2.VINkod = "A44556f77564fre";
            a2.kolikdvere = 3;
            Console.WriteLine(a2.ToString());
        }
    }
}