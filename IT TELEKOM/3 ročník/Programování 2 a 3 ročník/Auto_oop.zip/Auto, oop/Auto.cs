﻿namespace ConsoleApp8
{
    internal class Auto
    {
        public string znacka;
        public int kolikdvere = 5;
        public int vykonHP;
        public string VINkod;

        public Auto(string znacka, int kolikdvere, int vykonHP, string VINkod)
        {
            this.znacka = znacka;
            this.kolikdvere = kolikdvere;
            this.vykonHP = vykonHP;
            this.VINkod = VINkod;
        }
        public Auto()
        { }

        public override string ToString()
        {
            return string.Format($"znacka: {znacka}, auto ma dveri: {kolikdvere}, vykon v konich {vykonHP}, VIN {VINkod}.");
        }
    }
}
