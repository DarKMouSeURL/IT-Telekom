﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace nwm
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //print("abc");
            Console.WriteLine("abc");
            //x = 10;
            int x = 10;
            int y = 20;
            int soucet = x + y;
            //Console.WriteLine(soucet);
            Console.WriteLine(x + "+" + y + "=" + soucet);
            Console.WriteLine("abc");

            int rozdil = x - y;
            Console.WriteLine(rozdil);
            Console.WriteLine(x + "-" + y + "=" + rozdil);
            
        }
    }
}
