﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EditaceTextuLibrary;

namespace UzivRozhraniConsole

{
    static class UzivRozhrani
    {
        //DELSP, SUBSTR, CHECKP, HELP, EXIT

        public static void Run()
        {
            Console.WriteLine("--- Vítejte v Textovém editoru ---");
            string prikaz="";
            do
            {
                Console.Write("\r\nCommand: ");
                prikaz = Console.ReadLine().Trim().ToUpper();
                RozcestnikPrikazu(prikaz);

            } while (!prikaz.Equals("EXIT"));
        }

        public static void RozcestnikPrikazu(string prikaz)
        {
            switch (prikaz)
            {
                case "DELSP": DELSPCommand();    break;
                case "SUBSTR": break;
                case "CHECKP": CHECKPCommand();  break;
                case "HELP": HELPCommand(); break;
                case "EXIT": Console.WriteLine("Program bude nyní ukončen"); break;
                default: Console.WriteLine("Příkaz neexistuje, pokračujte příkazem help"); break;                   
            }
        }

        public static void CHECKPCommand()
        {
            Console.WriteLine("Metoda ověřuje palindom");
            Console.Write("Zadej text: ");
            string text = Console.ReadLine();
            if (UpravyTextu.OverPalindrom(text))
                Console.WriteLine("Zadaný text je palindrom :)");
            else
                Console.WriteLine("Zadaný text není palindrom :(");
        }

        public static void DELSPCommand()
        {
            Console.WriteLine("Mazání mezer v textu");
            Console.Write("Zadej text: ");
            string text = Console.ReadLine();
            Console.WriteLine("Výsledek: " + UpravyTextu.OdstranMezery(text));
        }

        public static void HELPCommand()
        {
            Console.WriteLine("Nápověda:");
            Console.WriteLine("\t- delsp\tsmaže všechny mezery v textu");
            Console.WriteLine("\t- substr\tzobrazí výňatek textu");
            Console.WriteLine("\t- checkp\tOvěř, zda text je palindrom");
            Console.WriteLine("\t- help\tZobraz nápovědu");
            Console.WriteLine("\t- exit\tUkonči program");
        }
    }
}
