﻿using System.Text;

namespace EditaceTextuLibrary
{
    public class UpravyTextu
    {
        public static string OdstranMezery(string text)
        {
            StringBuilder sb = new StringBuilder();
            foreach (char znak in text)
            {
                if (znak != ' ')
                    sb.Append(znak);
            }
            return sb.ToString();
        }

        public static string VratVysekTextu(string text, int _od, int _do)
        {
            return text.Substring(_od - 1, _do); //uživatel počítá od 1, proto musí u _od dát -1
                                                 //k druhé mezi musím myslet na přidání +1, tedy 
                                                 //-1 + 1 -> proměnnou _do neměním
        }

        public static bool OverPalindrom(string text)
        {
            text = OdstranMezery(text).ToLower();

            char[] charArray = text.ToCharArray();
            Array.Reverse(charArray);
            string text2 = new string(charArray);

            if (text.Equals(text2))
                return true;

            return false;
        }

    }
}
