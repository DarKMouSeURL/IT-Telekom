import Zbozi.Kava;
import Zbozi.Napoj;

public class Main {
    public static void main(String[] args) {

        Kava k1 = new Kava("Lavaza arabica", 1,299,5,4,0);

        System.out.println(k1);
    }
}