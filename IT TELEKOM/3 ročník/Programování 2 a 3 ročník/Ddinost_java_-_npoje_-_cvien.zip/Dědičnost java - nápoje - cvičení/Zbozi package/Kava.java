package Zbozi;

public class Kava extends Nealko {
    int intensity;
    int roasting;
    int acidity;

    public Kava(String nazev, double objem, double cena, int intensity,int roasting,int acidity)
    {
        super(nazev, objem, cena);

        this.intensity=intensity;
        this.roasting=roasting;
        this.acidity=acidity;
    }

    @Override
    public String toString() {
        return "{" +super.toString()+
                "intensity=" + intensity +
                ", roasting=" + roasting +
                ", acidity=" + acidity +
                '}';
    }
}
