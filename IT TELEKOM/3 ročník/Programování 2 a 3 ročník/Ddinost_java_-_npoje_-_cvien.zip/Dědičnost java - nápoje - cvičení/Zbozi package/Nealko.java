package Zbozi;

public class Nealko extends Napoj {


    public Nealko(String nazev, double objem, double cena)
    {
        super(nazev, objem,cena);
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
