package Zbozi;

public  class Napoj {

    protected String nazev;
    protected double objem;
    protected double cena;

    public Napoj(String nazev, double objem, double cena)
    {
        this.nazev=nazev;
        this.objem=objem;
        this.cena = cena;
    }

    @Override
    public String toString() {
        return "{" +
                "nazev='" + nazev + '\'' +
                ", objem=" + objem +
                ", cena=" + cena +
                '}';
    }
}
