﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsAppKostka
{
    public class Kostka : Panel  //trida je predstava o budoucim objektu
    {
        //clenske promenne
        Puntik b1 = null;
        Puntik b7 = null;
        Puntik b6 = null;
        Puntik b2 = null;
        Puntik b3 = null;
        Puntik b4 = null;
        Puntik b5 = null;

        public static Random lz = new Random();
        public Color barvaOrginal = Color.Transparent;
        public int hod = 0;

        //konstruktor
        public Kostka(Form1 f1, Color barva, int zleva, int zezhora, Color bp)
        {
            this.Parent = f1;
            this.Left = zleva;
            this.Top = zezhora;
            this.BackColor = barva;
            this.Width = 300;
            this.Height = 300;

            /*
            this.b1 = new Button();
            this.b1.Parent = this;
            this.b1.BackColor = Color.Red;
            this.b1.Enabled = false;
            this.b1.Width = 30;
            this.b1.Height = 30;
            this.b1.Left = 20;
            this.b1.Top = 20;
            */

            this.b1 = new Puntik(this, 30, 30, bp);
            this.b7 = new Puntik(this, 130, 130, bp);
            this.b6 = new Puntik(this, 230, 230, bp);
            this.b2 = new Puntik(this, 30, 130, bp);
            this.b3 = new Puntik(this, 30, 230, bp);
            this.b4 = new Puntik(this, 230, 30, bp);
            this.b5 = new Puntik(this, 230, 130, bp);

            this.barvaOrginal = barva;
        }

        //metody = programy
        public void Smazat()
        {
            this.b1.Visible = false;
            this.b6.Visible = false;
            this.b7.Visible = false;
            this.b2.Visible = false;
            this.b3.Visible = false;
            this.b4.Visible = false;
            this.b5.Visible = false;
        }
        public void Zobrazit(int hod)
        {
            if (hod == 1)
            {
                this.b7.Visible = true;
            }

            if (hod == 2)
            {
                this.b1.Visible = true;
                this.b6.Visible = true;
            }

            if (hod == 3)
            {
                this.b1.Visible = true;
                this.b6.Visible = true;
                this.b7.Visible = true;
            }

            if (hod == 4)
            {
                this.b1.Visible = true;
                this.b6.Visible = true;
                this.b3.Visible = true;
                this.b4.Visible = true;
            }

            if (hod == 5)
            {
                this.b1.Visible = true;
                this.b6.Visible = true;
                this.b3.Visible = true;
                this.b4.Visible = true;
                this.b7.Visible = true;
            }

            if (hod == 6)
            {
                this.b1.Visible = true;
                this.b6.Visible = true;
                this.b3.Visible = true;
                this.b4.Visible = true;
                this.b2.Visible = true;
                this.b5.Visible = true;
            }
        }
        public void Hodit()
        {
            this.Smazat();
            int hod = lz.Next(6) + 1;
            this.Zobrazit(hod);
            this.hod = hod;
        }

        public void SetBarva(Color barva)
        {
            this.BackColor = barva;        
        }
    }
}
