﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsAppKostka
{
    public partial class Form1 : Form
    {
        public Color barvapuntiku = Color.AntiqueWhite;
        public Kostka kostka1 = null;
        public Kostka kostka101 = null;
        public Kostka aktivnikostka = null;
        public Kostka kostka2 = null;
        public Kostka kostka3 = null;
        //static int red = rand.Next(256);
        public Form1()
        {
            InitializeComponent();
            //Kostka kostka1 = new Kostka(this, Color.GreenYellow, 0, 0);
            //kostka1.Hodit();
            this.kostka1 = new Kostka(this, Color.GreenYellow, 0, 0, this.barvapuntiku);
            this.kostka1.Hodit();
            this.kostka2 = new Kostka(this, Color.Honeydew, 350, 0, this.barvapuntiku);
            this.kostka2.Hodit();
            this.kostka3 = new Kostka(this, Color.Ivory, 700, 0, this.barvapuntiku);
            this.kostka3.Hodit();
            new Kostka(this, Color.HotPink, 1050, 0, this.barvapuntiku).Hodit();

            for (int i = 0; i < 30; i++)
            {
                //Random rand = new Random();
                //int red = rand.Next(256);
                //int blue = rand.Next(256);
                //int green = rand.Next(256);
                //Color barvaRGB = Color.FromArgb(red, green, blue);

                Kostka k = new Kostka(this, Color.Beige, 28 * i, 300 + (5 * i), this.barvapuntiku);
                k.Hodit();
                k.Click += delegate (object sender, EventArgs e)
                {
                    //MessageBox.Show(k.hod.ToString());
                    this.aktivnikostka.BackColor = this.aktivnikostka.barvaOrginal;
                    this.aktivnikostka.SendToBack();
                    this.aktivnikostka.Top += 40;
                    this.aktivnikostka = k;
                    this.trackBar2.Value = this.aktivnikostka.Left;
                    this.trackBar3.Value = this.aktivnikostka.Top;
                    this.aktivnikostka.SetBarva(Color.BlueViolet);
                    this.Text = this.aktivnikostka.hod.ToString();
                    this.label2.Text = this.aktivnikostka.hod.ToString();
                    this.textBox1.Text = this.aktivnikostka.hod.ToString();
                    //this.label2.BackColor = this.aktivnikostka.BackColor;
                    //this.textBox1.BackColor = this.aktivnikostka.BackColor;
                    this.label2.BackColor = this.aktivnikostka.barvaOrginal;

                    this.aktivnikostka.BringToFront();
                    this.aktivnikostka.Top -= 40;
                };
            }   
            this.aktivnikostka = this.kostka2;
            this.trackBar2.Value = this.aktivnikostka.Left;
            this.kostka1.Click += new EventHandler(Kostka1_Click);
            this.kostka2.Click += Kostka2_Click;
            this.kostka3.Click += Kostka3_Click;
        }

        private void Kostka2_Click(object sender, EventArgs e)
        {
            this.aktivnikostka.BackColor = this.aktivnikostka.barvaOrginal;
            this.aktivnikostka = this.kostka2;
            this.trackBar2.Value = this.aktivnikostka.Left;
            this.trackBar3.Value = this.aktivnikostka.Top;
            this.aktivnikostka.SetBarva(Color.BlueViolet);
            this.aktivnikostka.BringToFront();

        }
        private void Kostka3_Click(object sender, EventArgs e)
        {
            this.aktivnikostka.BackColor = this.aktivnikostka.barvaOrginal;
            this.aktivnikostka = this.kostka3;
            this.trackBar2.Value = this.aktivnikostka.Left;
            this.trackBar3.Value = this.aktivnikostka.Top;
            this.aktivnikostka.SetBarva(Color.BlueViolet);
            this.aktivnikostka.BringToFront();
        }
        private void Kostka1_Click(object sender, EventArgs e)
        {
            this.aktivnikostka.BackColor = this.aktivnikostka.barvaOrginal;
            this.aktivnikostka = this.kostka1;
            this.trackBar2.Value = this.aktivnikostka.Left;
            this.trackBar3.Value = this.aktivnikostka.Top;
            this.aktivnikostka.SetBarva(Color.BlueViolet);
            this.aktivnikostka.BringToFront();

        }
        private void buttonBarva_Click(object sender, EventArgs e)
        {
            //colorDialog1.ShowDialog();
            //this.kostka1 = null;
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                this.barvapuntiku = colorDialog1.Color;
            }
            else
            {
                MessageBox.Show("zruseno");
            }
            this.kostka101 = new Kostka(this, Color.Beige, 1400, 10, this.barvapuntiku);
            this.kostka101.Hodit();
        }
        private void trackBar2_Scroll(object sender, EventArgs e)
        {
            //this.kostka1.Left = trackBar2.Value;
            //if (this.kostka101 != null)
            //    this.kostka101.Left = trackBar2.Value + 1400;
            this.aktivnikostka.Left = trackBar2.Value;
        }
        private void trackBar3_Scroll(object sender, EventArgs e)
        {
            //this.kostka1.Top = trackBar3.Value;
            //if (this.kostka101 != null)
            //this.kostka101.Top = trackBar3.Value + 200;
            this.aktivnikostka.Top = trackBar3.Value;
        }
        private void panel1_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.CornflowerBlue;
        }
        private void buttonzmenitbarvukostky_Click(object sender, EventArgs e)
        {
            this.aktivnikostka.SetBarva(Color.BlueViolet);
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            //e.KeyCode
            switch (e.KeyCode)
            {
                case Keys.Down:
                    //this.aktivnikostka.Top = this.aktivnikostka.Top + 20;
                    //this.aktivnikostka.Top += 120;
                    this.aktivnikostka.Top += (int)this.numericUpDown2krok.Value;
                    break;
                case Keys.Up:
                    //this.aktivnikostka.Top -= 20;
                    this.aktivnikostka.Top -= (int)this.numericUpDown2krok.Value;
                    break;
                case Keys.Right:
                    //this.aktivnikostka.Left += 20;
                    this.aktivnikostka.Left += (int)this.numericUpDown2krok.Value;
                    break;
                case Keys.Left:
                    //this.aktivnikostka.Left -= 20;
                    this.aktivnikostka.Left -= (int)this.numericUpDown2krok.Value;
                    break;
            }
            e.Handled = true;
            //this.trackBar2.Value = this.aktivnikostka.Left;
            //this.trackBar3.Value = this.aktivnikostka.Top;
            if (this.trackBar2.Value <0 || this.trackBar2.Value > 1400)
            {

            }
            else
            {
                this.trackBar2.Value = this.aktivnikostka.Left; //tady!!!!!!!
            }

            this.trackBar3.Value = this.aktivnikostka.Top;


        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            //nhiigcftuj
        }

        private void numericUpDown2krok_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
