﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsAppKostka
{
    public class Puntik : Button
    {
        //vice parametricky konstruktor
        public Puntik(Kostka kostka, int zleva, int zezhora, Color barvap)
        {
            this.Parent = kostka;
            this.BackColor = barvap; //Color.Red;
            this.Enabled = false;
            this.Width = 30;
            this.Height = 30;
            this.Left = zleva;
            this.Top = zezhora;
        }
        public void setBarva(Color barva)
        { 
            this.BackColor=barva;
        }
    }
}
