import javax.swing.*;
import java.util.*;
public class Main {
    public static void main(String[] args) {
        ArrayList<Ucet> ucty = new ArrayList<Ucet>();
        //ucty.add(new Ucet("11111", "Petr", 50000));
        Scanner sc = new Scanner(System.in);

        try{
            System.out.print("zadejte cislo uctu: ");
            String cislo = sc.nextLine();

            System.out.print("zadejte majitel uctu: ");
            String majitel = sc.nextLine(); //more tady scanner!!!!

            String zustatek = JOptionPane.showInputDialog("MORE tady zadej zustatek: "); // pro fajnsmakery

            ucty.add(new Ucet(cislo, majitel, Double.parseDouble(zustatek)));
        }
        catch (Exception ex){

            System.out.println("Pri zadavani doslo k chybe: "+ex);
            System.out.println("Ukoncuji aplikaci...");
            System.exit(0);
        }

        ucty.add(new KontokorentniUcet("222222", "Jana", 13000, 2000));
        ucty.add(new SporiciUcet("33333", "Marie", 4400, 2.2));

    //-------------- VYPIS ---------------
        System.out.println("Vypis uctu: ");
        for (Ucet ucet : ucty)
            System.out.println(ucet.toString());

        System.out.println("\nTEST1: vlozit 10000,- Kc na ucet 1");
        System.out.println(ucty.get(0).vlozit(10000));

    //-------------- VYPIS ---------------
        System.out.println("TEST2: vybrat 14000 kc ze vsech uctu");
        for (Ucet ucet : ucty)
            System.out.println(ucet.vybrat(14000));
        //nefunguje u kontokorentu

    //-------------- VYPIS ---------------
        System.out.println("TEST3: na vsechny ucty priste urok!!!!!!!!");
        for (Ucet ucet : ucty)
            System.out.println(ucet.pripsatUrok());
    }
}