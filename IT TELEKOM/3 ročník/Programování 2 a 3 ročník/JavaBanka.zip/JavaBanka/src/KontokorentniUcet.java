public class KontokorentniUcet extends Ucet{
    private double limit;

    public KontokorentniUcet(String cislo, String majitel, double limit){
            super(cislo, majitel);
            this.limit = limit;
    }

    public KontokorentniUcet(String cislo, String majitel, double zustatek, double limit){
        super(cislo, majitel, zustatek);
        this.limit = limit;
    }

    @Override
    public String vybrat(double castka) {
        if ((zustatek+limit) >= castka){
            zustatek -= castka;
            return "Z uctu " + vratCeleCisloUctu() + "Byla vybrana castka" + castka + "Kc. Aktualni zustatek: " + zustatek + "kc.";
        }
        return "Nedostatek prostredku na uctu" + vratCeleCisloUctu() + ", transakce nebyla dokoncena. Aktualni zustatek: " + zustatek + "Kc.";
    }

    @Override
    public String toString() {
        return "Sporici ucet [" + vratCeleCisloUctu() + ", majitel: " + majitel + ", zustatek: " + zustatek + "kc, limit: " + limit + "%]";
    }
}
