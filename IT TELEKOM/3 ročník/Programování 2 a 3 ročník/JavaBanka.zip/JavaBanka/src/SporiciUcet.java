public class SporiciUcet extends Ucet {
    private double urokovaSazba;

    public SporiciUcet(String cislo, String majitel, double urokovaSazba){
        super(cislo, majitel);
        this.urokovaSazba = urokovaSazba;
    }

    public SporiciUcet(String cislo, String majitel, double zustatek, double urokovaSazba){
        super(cislo, majitel, zustatek);
        this.cislo = cislo;
        this.majitel = majitel;
        this.urokovaSazba = urokovaSazba;
        this.zustatek = zustatek;
    }

    @Override
    public String pripsatUrok() {
        zustatek += (zustatek * urokovaSazba) / 100;
        return "Na ucet "+vratCeleCisloUctu()+" byl pripsan urok " + urokovaSazba + " %. aktualni zustatek: " + zustatek + "Kc. ";
    }

    @Override
    public String toString() {
        return "Sporici ucet [" + vratCeleCisloUctu() + ", majitel: " + majitel + ", zustatek: " + zustatek + "kc, urokova sazba: " +urokovaSazba+"%]";
    }
}
