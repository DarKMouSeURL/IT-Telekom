public class Ucet {
    private final int KODBANKY = 1234;
    protected String cislo;
    protected String majitel;
    protected double zustatek;

    public Ucet (String cislo, String majitel, double zustatek){
        this.cislo = cislo;
        this.majitel = majitel;
        this.zustatek = zustatek;
    }

    public Ucet(String cislo, String majitel) {
        this.cislo= cislo;
        this.majitel= majitel;
    }

    public Ucet() { }

    public String vlozit(double castka) {
        zustatek += castka;
        return "Na ucet" + vratCeleCisloUctu() + " byla vlozena castka " + castka + " Kc. akualni zustatek: "+zustatek+".";
    }

    public String vybrat(double castka) {
        if (zustatek >= castka){
            zustatek -= castka;
            return "Z uctu " + vratCeleCisloUctu() + "Byla vybrana castka" + castka + "Kc. Aktualni zustatek: " + zustatek + "kc.";
        }
        return "Nedostatek prostredku na uctu" + vratCeleCisloUctu() + ", transakce nebyla dokoncena. Aktualni zustatek: "+zustatek+"Kc.";
    }
    protected String vratCeleCisloUctu() {
        return cislo+"/"+KODBANKY;
    }

    @Override
    public String toString() {
        return "Ucet ["+vratCeleCisloUctu()+", majitel: "+ majitel+", zustatek: "+ zustatek+"kc]";
    }
    
    public String pripsatUrok() {
        return "transakci nelze provest, ucet neni sporici!";
    }
}
