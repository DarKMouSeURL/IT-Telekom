﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _6hodina.forms
{
    public partial class Form1 : Form
    {

        public int cislotajne = 14;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //int cislotajne = 14;
            //int cislotajne = new Random().Next(1, 20);
            this.cislotajne = new Ramdom().Next(1, 20);
            label1.Text = cislotajne.ToString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //kod pro pokus klik....
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
         
        }

        private void akcehra_Click(object sender, EventArgs e)
        {
            string cislozadaneStr = textBoxzadatcislo.Text;
            int cislozadane = Convert.ToInt32(cislozadaneStr);

            if (cislozadane == cislotajne)
            {
                //Console.WriteLine("To jsi teda opradu dost vyhral");
                labelprubeh.Text = "To jsi teda opradu dost vyhral";
            }
            else
            {
                //Console.WriteLine("HA! vedle");
                labelprubeh.Text = "To jsi teda opradu dost vyhral";
            }
        }
    }
}
