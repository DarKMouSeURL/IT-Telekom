﻿namespace _6hodina.forms
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.akcehra = new System.Windows.Forms.Button();
            this.textBoxzadatcislo = new System.Windows.Forms.TextBox();
            this.labelprubeh = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button1.Location = new System.Drawing.Point(560, 276);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(401, 156);
            this.button1.TabIndex = 0;
            this.button1.Text = "nova hra";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(507, 419);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(13, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "?";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // akcehra
            // 
            this.akcehra.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.akcehra.Location = new System.Drawing.Point(199, 123);
            this.akcehra.Name = "akcehra";
            this.akcehra.Size = new System.Drawing.Size(303, 282);
            this.akcehra.TabIndex = 2;
            this.akcehra.Text = "akce";
            this.akcehra.UseVisualStyleBackColor = true;
            this.akcehra.Click += new System.EventHandler(this.akcehra_Click);
            // 
            // textBoxzadatcislo
            // 
            this.textBoxzadatcislo.Location = new System.Drawing.Point(411, 528);
            this.textBoxzadatcislo.Name = "textBoxzadatcislo";
            this.textBoxzadatcislo.Size = new System.Drawing.Size(463, 20);
            this.textBoxzadatcislo.TabIndex = 3;
            this.textBoxzadatcislo.Text = "7";
            this.textBoxzadatcislo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxzadatcislo.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // labelprubeh
            // 
            this.labelprubeh.AutoSize = true;
            this.labelprubeh.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelprubeh.Location = new System.Drawing.Point(416, 473);
            this.labelprubeh.Name = "labelprubeh";
            this.labelprubeh.Size = new System.Drawing.Size(39, 39);
            this.labelprubeh.TabIndex = 4;
            this.labelprubeh.Text = "--";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.ClientSize = new System.Drawing.Size(1272, 744);
            this.Controls.Add(this.labelprubeh);
            this.Controls.Add(this.textBoxzadatcislo);
            this.Controls.Add(this.akcehra);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "hadani cisel";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button akcehra;
        private System.Windows.Forms.TextBox textBoxzadatcislo;
        private System.Windows.Forms.Label labelprubeh;
    }
}

