﻿namespace veverui
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Kniha kniha1 = new Kniha("THE MAN", "MAN", 500, 45);
            kniha1.UpravaCeny();
            Console.WriteLine(kniha1.GetCena());
            Console.WriteLine(kniha1.ToString());
            Console.WriteLine(kniha1.CenaKnih(400));

            Console.WriteLine(kniha1.GetPocetSkladem(501));

        }
    }
}
