﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace veverui
{
    internal class Kniha
    {
        string nazev;
        string autor;
        double cena;
        int pocetSkladem;
        //1. Vytvořte 4-parametrický konstruktor pro vytvoření nové knihy
        public Kniha(string nazev, string autor, double cena, int pocetSkladem)
        {
            this.nazev = nazev;
            this.autor = autor;
            this.cena = cena;
            this.pocetSkladem = pocetSkladem;
        }

        //2. Metoda upraví základní cenu knihy na polovinu
        public void UpravaCeny()
        {
            cena = cena / 2;
        }
        double dph = 21;
        //3. Metoda vrátí cenu knihy s DPH (pozn. DPH bude statická proměnná v class Kniha)
        public double GetCena() 
        {  
            return (cena/100)*(100+dph);
        }

        //4. Metodá VratInfo vrátí informaci o knize ve formě:

        //"Kniha džunglí (Rudyard Kipling): cena 268 Kč vč. dph"
        public override string ToString() 
        {
            return string.Format($"{nazev}, ({autor}), cena {GetCena()} Kč vč. dph");
        }
        //5. Metoda vrátí celkovou cenu, kterou zaplatí zákazník za požadovaný počet výtisků knihy
        public double CenaKnih(int pocet)
        {
            return cena * pocet;
        }
        //6. Metoda vrátí informaci, kolik ks knih jsme schopni koupit za daný obnos v peněžence
        public double GetPocetSkladem(double penize) 
        {
            double pocet = (GetCena()/penize);
            int poocet = Convert.ToInt64(pocet);
            if (pocet > pocetSkladem)
                return pocetSkladem;
            return pocet;

        }
        //Pokud daný počet není skladem, vypíše se pouze množství knih dané skladovými zásobami

        //7. Metoda vrátí textovou informaci:
        public string Vrati()
        {
            if (pocetSkladem == 0)
                return "neni skladem";
            else if (pocetSkladem <= 5)
                return "Posledni 3 kusy";
            return "skladem";
        }
        //Skladem

        //Není skladem

        //Poslední 3 kusy (pokud ks na skladě je 5 a méně, napíše danou informaci s číslem)

        //8. Metoda přidá daný počet kusů do pocetSkladem
        public void Pridat(int p)
        { 
            pocetSkladem += p;
        }
    }
}
