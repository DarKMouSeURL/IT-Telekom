import java.util.ArrayList;
import java.util.Random;

public class Main {
    static ArrayList<Integer> cisla = new ArrayList<>();
    static void VypisSeznam(){
        for (Integer polozka:cisla)
            System.out.print(polozka+", ");
    }
    public static void main(String[] args) {
        int count = 0;
        //Pozn. Správnost řešení kontrolujte voláním metody VypisPolozek řešenou v bodu č. 3
        //1. Vytvořte seznam celých čísel s názvem cisla a uložte do něho na začátku hodnoty 10,18,15,-5
        cisla.add(10);
        cisla.add(18);
        cisla.add(15);
        cisla.add(-5);
        //2. Do tohoto seznamu nalosujte navíc dalších 100 čísel od -20 do 20
        Random ran = new Random();
        for(int i=0; i<=100; i++){
            cisla.add(ran.nextInt(-20, 21));
        }
        //3. Vytvořte samostatnou metodu VypisSeznam – pro výpis položek seznamu vedle sebe
        VypisSeznam();
        System.out.println();
        //4. Vymažte všechny výskyty čísla 0 ze seznamu
        while (cisla.contains(0)){
            cisla.remove((Integer)0);
        }
        //5.Vymažte všechny výskyty záporných dvouciferných čísel ze seznamu
        for (Integer polozka:cisla){
            if(polozka>=-99&&polozka<0)
                cisla.remove(count);
            else
                count++;
        }
        //6.Vymažte každý 5. prvek (počínaje prvkem na indexu 4)
        //    Pozor, prvky se postupně umazávají a hodnoty na indexech se posouvají!
        for (int i=4;i< cisla.size();i+=4){
            cisla.remove(i);
        }
        //7.Vypište číslo indexu, na kterém leží
        //      1. hodnota 10, pokud v seznamu hodnota není, napište NENALEZENO
        if(cisla.indexOf((Integer) 10)!=-1)
            System.out.println(cisla.indexOf((Integer) 10));
        else
            System.out.println("NENALEZENO");
        //8. Vypište , kolik hodnot v poli je nezáporných
        int nezaporne=0;
        for (Integer polozka:cisla){
            if (polozka>=0)
                nezaporne++;
        }
    }
}