package tvary;

public class Obdelnik extends Tvar {
    //konstruktory
    public Obdelnik()
    {
        super();
    }
    public Obdelnik(int sirka, int vyska) {
        //this.sirka = sirka;
        //this.vyska = vyska;
        super(sirka, vyska);
    }
    //metody
    @Override
    public  void nakreslit() {
        //nakreslit obdelnik
        System.out.println("...kreslim obdelnik...");
        for(int y=0; y<this.vyska; y++) {
            for(int x=0; x<this.sirka; x++) {
                System.out.print("X");
            }
            System.out.println();
        }
    }
    @Override
    public  double vypocitatObvod() {
        //return 2*(this.sirka+this.vyska);
        double obvod = 2*(this.sirka+this.vyska);
        //skolni uloha, chyba je obvod > 40
        if (obvod > 40)
        {
            throw new ArithmeticException(">>>Moc dlouhy obvod > 40  "+ this.sirka + "x" + this.vyska +"\n>>>Moc dlouhy obvod > 40\n");
        }
        return obvod;
    }
    @Override
    public  double vypocitatObsah() {
        //return this.sirka * this.vyska;
        double obsah =this.sirka * this.vyska;
        //chybovy stav, skolni priklad... obsah>50
        if (obsah > 50)
        {
            throw new ArithmeticException(">>>Moc velky OBSAH > 50\n>>>Moc velky OBSAH > 50\n");
        }
        return obsah;
    }
    @Override
    public String toString()
    {
        return "Obdelnik je " + super.toString();
    }
}
