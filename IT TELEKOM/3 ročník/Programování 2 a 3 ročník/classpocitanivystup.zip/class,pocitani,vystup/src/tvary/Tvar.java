package tvary;

public abstract class Tvar {
    //clenske promenne
    protected int sirka;
    protected int vyska;
    //konstruktory
    public Tvar() {
        //this.sirka = 0;
        //this.vyska = 0;
        this(0,0);
    }
    public Tvar(int sirka) {
        //this.sirka = sirka;
        //this.vyska = sirka;
        this(sirka, sirka);
    }
    public Tvar(int sirka, int vyska) {
        this.sirka = sirka;
        this.vyska = vyska;
    }
    //metody
    public abstract void nakreslit();

    //samostatna prace...
    //public abstract void nakreslitObvod();

    public abstract double vypocitatObvod() throws MojeVyjimka;
    public abstract double vypocitatObsah();
    @Override
    public String toString()
    {
        return "Tvar sirka=" + this.sirka + " vyska=" + this.vyska + " " + super.toString();
    }
}

/*
public  class Tvar
{
    //clenske promenne
    protected int sirka;
    protected int vyska;

    //konstruktory

    //metody
    public void nakreslit()
    {
        //nevime co kreslit...
        System.out.println("chci kreslit tvar");
    }
    public double vypocitatObvod()
    {
        return 0;  //nevime jak vypocitat...
    }

    public double vypocitatObsah()
    {
        return 0;  //nevime jak vypocitat...
    }

    @Override
    public String toString()
    {
        return "Tvar sirka=" + this.sirka + " vyska=" + this.vyska;
    }
}
*/