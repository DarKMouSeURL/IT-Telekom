package tvary;

public class Kruh extends  Tvar {
    //konstruktory
    public Kruh() {
        super();
    }
    public Kruh(int sirka) {
        super(sirka);
    }
    //metody
    @Override
    public void nakreslit() {
        System.out.println("Neni jednoduche v console nakreslit kruh");
    }
    @Override
    public double vypocitatObvod() throws MojeVyjimka {
        //return 3.14 * this.sirka;
        double obvod = 3.14 * this.sirka;
        if (obvod < 30)
        {
            throw new MojeVyjimka(">>>Opravdu maly kruh, obvod je mensi nez 30...");
        }
        return obvod;
    }
    @Override
    public double vypocitatObsah() {
        double r = (double)this.sirka / 2.0;
        return Math.PI * r * r;
    }
    @Override
    public String toString() {
        return "Kruh je " + super.toString();
    }
}









