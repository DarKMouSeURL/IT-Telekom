package tvary;

public class MojeVyjimka extends Exception
//public class MojeVyjimka extends RuntimeException
{
    public MojeVyjimka()
    {
        super();
    }
    public  MojeVyjimka(String zprava)
    {
        super(zprava);
    }
}
