package tvary;

public class Ctverec extends Obdelnik {
    //konstruktory
    public Ctverec() {
        super();
    }
    public Ctverec(int sirka) {
        super(sirka,sirka);
    }
    //metody
    @Override
    public String toString() {
        return "Ctverec je " + super.toString();
    }
}
