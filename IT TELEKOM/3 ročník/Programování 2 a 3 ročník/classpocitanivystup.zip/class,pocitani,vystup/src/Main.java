import priklad.Matika;
import com.pokus.Pomocna;
import ostatni.Overeni;
import java.io.*;

public class Main {
    public static void main(String[] args) throws IOException {
        System.out.println("Soucet je: " + Matika.secist(40,3));
        Pomocna.hlaseni("Moc velky projekt v Java...");
        //Overeni.spustitBanku();
        //Overeni.spustitKalkulator();
        Overeni.spustitTvary();

        //jeste dodelat balik dds....

    }
}