package com.pokus;

public class Pomocna {
    public static void hlaseni(String zprava) {
        System.out.println("*******************");
        System.out.println("* " + zprava);
        System.out.println("*******************");
    }
}
