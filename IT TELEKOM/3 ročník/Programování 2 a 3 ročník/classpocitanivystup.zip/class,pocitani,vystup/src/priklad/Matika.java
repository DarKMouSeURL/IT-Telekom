package priklad;

public class Matika {

    public static int secist(int a, int b) {
        return a+b;
    }
}
