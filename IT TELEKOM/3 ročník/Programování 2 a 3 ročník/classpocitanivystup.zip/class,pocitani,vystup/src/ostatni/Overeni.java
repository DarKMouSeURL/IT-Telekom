package ostatni;

import banka.BeznyUcet;
import banka.SporiciUcet;
import banka.Ucet;

import kalkulator.Kalkulator;

import tvary.*;

import java.util.LinkedList;
import java.io.*;
import java.util.*;   //pro vyjimky...
import java.util.Scanner;

public class Overeni {
    public static void spustitBanku() {
        System.out.printf("Projekt banka!\n\n");
        /*
        int v = Matika.secist(10,5);
        System.out.println("Soucet je " + v);

        Pomocna.hlaseni("Na 5 kolej prijizdi vlak");
        Pomocna.hlaseni("Na 6 kolej prijizdi vlak");
        */
        System.out.println( "Pocet uctu je: " + Ucet.pocet );
        Ucet u1 = new Ucet();
        System.out.println( u1.toString() );
        //u1.cislo = "123456";
        u1.vlozit(100000);
        System.out.println( u1.toString() );
        u1.vybrat(100);
        System.out.println( u1.toString() );
        System.out.println( "Pocet uctu je: " + Ucet.pocet );
        System.out.println( "-------------------" );

        Ucet u2 = new Ucet("456456/0300","Pepa Dvorak",17000);
        System.out.println( u2.toString() );
        u2.vlozit(200000);
        System.out.println( u2.toString() );

        //u2.vybrat(100);
        //if(u2.vybrat((100)))
        if(u2.vybrat((220000)))
            System.out.println( "vybrano OK: " + u2.toString() );
        else
            System.out.println( "Na uctu je malo penez NIC: " + u2.toString() );

        System.out.println( u2.toString() );
        System.out.println( "Pocet uctu je: " + Ucet.pocet );
        System.out.println( "-------------------" );

        SporiciUcet sp1 = new SporiciUcet();
        System.out.println( sp1.toString() );
        sp1.pripsatUrok();
        System.out.println( sp1.toString() );
        sp1.vlozit(200000);
        System.out.println( sp1.toString() );
        System.out.println( "-------------------" );

        SporiciUcet sp2 = new SporiciUcet("123456/0700","Jana Bohata",100000.0,5.0);
        System.out.println( sp2.toString() );
        sp2.pripsatUrok();
        System.out.println( sp2.toString() );
        if(sp2.vybrat((150000)))
            System.out.println( "vybrano OK: " + sp2.toString() );
        else
            System.out.println( "Na uctu je malo penez NIC: " + sp2.toString() );
        System.out.println( "-------------------" );
        System.out.println( "-------------------" );

        BeznyUcet bu1 = new BeznyUcet();
        System.out.println( bu1.toString() );

        BeznyUcet bu2 = new BeznyUcet("777888/0900","Klara Bezna",777000);
        System.out.println( bu2.toString() );

        boolean anoNe = bu2.prevestNa(bu1,500123);
        System.out.println( "--------" + anoNe );
        System.out.println( bu1.toString() );
        System.out.println( bu2.toString() );
        System.out.println( "--------" + anoNe  );

        anoNe = bu2.prevestNa(bu1,500123);
        System.out.println( "---" + anoNe  );
        System.out.println( bu1.toString() );
        System.out.println( bu2.toString() );
        System.out.println( "---" + anoNe  );


        //spolecne zpracovani vse uctu:
        Ucet[] poleUctu = new Ucet[6];
        poleUctu[0] = u1;
        poleUctu[1] = u2;
        poleUctu[2] = sp1;
        poleUctu[3] = sp2;
        poleUctu[4] = bu1;
        poleUctu[5] = bu2;

        BeznyUcet cu = new BeznyUcet("999999/0900","Tom Cilovy",99000);
        System.out.println( "----" );
        System.out.println( cu.toString() );
        System.out.println( "----" );

        for(Ucet ucet : poleUctu) {
            System.out.println(ucet.toString());
            ucet.vlozit(1);
            System.out.println(ucet.toString());
            ucet.vybrat(2);
            System.out.println(ucet.toString());
            if (ucet instanceof SporiciUcet) {
                ((SporiciUcet) ucet).pripsatUrok();
                System.out.println(ucet.toString());
                System.out.println("--");
            }
            if (ucet instanceof BeznyUcet) {
                boolean b = ((BeznyUcet) ucet).prevestNa(cu, 500000);
                System.out.println("vybrano/nebybrano, true/false: " + b);
                System.out.println(ucet.toString());
                System.out.println(cu.toString());
                System.out.println("-");
            }
            System.out.println("------");
        }
    }
    public static void spustitKalkulator() {
        System.out.printf("Projekt Kalkulator \n");

        int[] pole1 = Kalkulator.generovatPole(10);
        Kalkulator.vypsat(pole1);
        Kalkulator.vypsatPozpatku(pole1);
        System.out.println("Delka pole1 je: " + Kalkulator.zpracovatDelka(pole1));
        System.out.println("Soucet pole1 je: " + Kalkulator.zpracovatSoucet(pole1));
        System.out.println("Ar. prumer pole1 je: " + Kalkulator.zpracovatArPrumer(pole1));
        System.out.println("Maximum v pole1 je: " + Kalkulator.zpracovatMaximum(pole1));
        System.out.println("Minimum v pole1 je: ...");
        int[] pole1Serazeno = Kalkulator.zpracovatSeraditVzestupne(pole1);
        System.out.println("Vypis serazeneho pole1:");
        Kalkulator.vypsat(pole1Serazeno);
        System.out.println("Vypis puvodniho pole1:");
        Kalkulator.vypsat(pole1);
        System.out.println("-----------------");

        int[] pole2 = Kalkulator.generovatPole(6, 500);
        Kalkulator.vypsat(pole2);
        Kalkulator.vypsatPozpatku(pole2);
        System.out.println("Delka pole2 je: " + Kalkulator.zpracovatDelka(pole2));
        System.out.println("Soucet pole2 je: " + Kalkulator.zpracovatSoucet(pole2));
        System.out.println("Ar. prumer pole2 je: " + Kalkulator.zpracovatArPrumer(pole2));
        System.out.println("Maximum v pole2 je: " + Kalkulator.zpracovatMaximum(pole2));
        System.out.println("Minimum v pole2 je: ...");
        int[] pole2Serazeno = Kalkulator.zpracovatSeraditVzestupne(pole2);
        System.out.println("Vypis serazeneho pole2:");
        Kalkulator.vypsat(pole2Serazeno);
        System.out.println("Vypis puvodniho pole2:");
        Kalkulator.vypsat(pole2);
        System.out.println("-----------------");
    }
    public static void spustitTvary() throws IOException {
        System.out.println("Projekt tvary");

        int[] pole = {10,20,30};

        Obdelnik obdelnik1 = new Obdelnik();

        Scanner sc = new Scanner(System.in);
        int sirkaO1 = 0;
        int vyskaO1 = 0;
        try
        {
            System.out.print("zadej sirku: ");
            sirkaO1 = sc.nextInt();
            System.out.print("zadej vysku: ");
            vyskaO1 = sc.nextInt();
            //pokus s indexy pole
            //int x = pole[3];
            int citatel = 50;
            int jmenovatel = 0;
            int podil1 = citatel / jmenovatel;
            //double podil2 = (double)citatel / (double)jmenovatel;
        }
        catch (InputMismatchException e)
        {
            System.out.println("Nastala vyjimka InputMismatchException...");
            System.out.println(e.getMessage());
        }
        catch (IndexOutOfBoundsException e)
        {
            System.out.println("Nastala vyjimka IndexOutOfBoundsException...");
            System.out.println(e.getMessage());
        }
        catch (ArithmeticException e)
        {
            System.out.println("Nastala vyjimka ArithmeticException...  deleni nulou...");
        }
        catch (Exception e)
        {
            System.out.println("Nastala vyjimka obecna...");
            System.out.println(e.getMessage());
        }
        finally
        {
            System.out.println("Sekce finally...");
        }
        System.out.println("-------------------");
        System.out.println("-------------------");

        Obdelnik obdelnik2 = new Obdelnik(sirkaO1, vyskaO1);
        Kruh kruh1 = new Kruh();
        //Kruh kruh2 = new Kruh(100);
        Kruh kruh2 = new Kruh(3);
        Ctverec ctverec1 = new Ctverec();
        Ctverec ctverec2 = new Ctverec(11);

        Tvar[] poleTvaru = new Tvar[6];
        poleTvaru[0] = obdelnik1;
        poleTvaru[1] = obdelnik2;
        poleTvaru[2] = kruh1;
        poleTvaru[3] = kruh2;
        poleTvaru[4] = ctverec1;
        poleTvaru[5] = ctverec2;
        for (int i = 0; i < 6; i++) {
            System.out.println(poleTvaru[i].toString());
            poleTvaru[i].nakreslit();
            //System.out.println("obvod je " + poleTvaru[i].vypocitatObvod());  //Exception in thread "main" java.lang.ArithmeticException: >>>Moc dlouhy obvod > 40

            try {
                System.out.println("obvod je " + poleTvaru[i].vypocitatObvod());
            } catch (ArithmeticException e){
                System.out.println( e.getMessage() );
            } catch (MojeVyjimka e) {
                System.out.println( e.getMessage() );
            }

            //System.out.println("obsah je " + poleTvaru[i].vypocitatObsah());  //Exception in thread "main" java.lang.ArithmeticException: >>>Moc velky OBSAH > 50
            try {
                System.out.println("obsah je " + poleTvaru[i].vypocitatObsah());
            } catch (ArithmeticException e){
                System.out.println( e.getMessage() );
            }

            System.out.println("-------------------");
        }
        System.out.println("-------------------");
        System.out.println("-------------------");

        LinkedList<Tvar> seznamTvaru = new LinkedList<Tvar>();
        seznamTvaru.add(obdelnik1);
        seznamTvaru.add(obdelnik2);
        seznamTvaru.add(ctverec1);
        seznamTvaru.add(ctverec2);
        seznamTvaru.add(kruh1);
        seznamTvaru.add(kruh2);
        for(Tvar tvar : seznamTvaru)
        {
            tvar.nakreslit();
            System.out.println(tvar.toString());
            System.out.println("---");
        }
    }
}
