package kalkulator;

import java.util.Random;
import java.util.Stack;

public class Kalkulator
{
    public static int[] generovatPole(int pocetPrvku)
    {
        //chci generovat cela cisla <0,99>
        Random lz = new Random();
        int[] poleInt = new int[pocetPrvku];
        for(int i = 0; i < poleInt.length; i++)
        {
            int cislo = lz.nextInt(100);
            poleInt[i] = cislo;
        }
        return  poleInt;
    }
    public static int[] generovatPole(int pocetPrvku, int rozsahPrvku)
    {
        //chci generovat cela cisla <0,rozsahPrvku>
        Random lz = new Random();
        int[] poleInt = new int[pocetPrvku];
        for(int i = 0; i < poleInt.length; i++)
        {
            int cislo = lz.nextInt(rozsahPrvku);
            poleInt[i] = cislo;
        }
        return  poleInt;
    }
    public static void vypsat(int[] pole)
    {
        for(int i = 0; i < pole.length; i++)
        {
            System.out.print(pole[i] + " ");
        }
        System.out.println();
    }
    public static int zpracovatDelka(int[] pole)
    {
        return pole.length;
    }
    public static void vypsatPozpatku(int[] pole)
    {
        Stack<Integer> zasobnik = new Stack<Integer>();
        //zasobnik.push(123);
        //zasobnik.pop();
        for (int i = 0; i < pole.length; i++)
        {
            zasobnik.push(pole[i]);
        }
        for (int i = 0; i < pole.length; i++)
        {
            System.out.print(zasobnik.pop() + " ");
        }
        System.out.println();
    }
    public static int zpracovatSoucet(int[] pole)
    {
        int soucet = 0;
        for(int cislo : pole)
        {
            soucet += cislo;
        }
        return soucet;
    }
    public static double zpracovatArPrumer(int[] pole)
    {
        int soucet = Kalkulator.zpracovatSoucet(pole);
        int pocet = Kalkulator.zpracovatDelka(pole);
        double arPrumer = (double)soucet / (double)pocet;
        return arPrumer;
    }
    public static int zpracovatMaximum(int[] pole)
    {
        int nejvetsi=pole[0];
        for(int i = 0; i < pole.length; i++)
        {
            if(pole[i]>nejvetsi)
            {
                nejvetsi = pole[i];
            }
        }
        return nejvetsi;
    }
    //samostatne
    //public static int zpracovatMinimum(int[] pole)
    public static int[] zpracovatSeraditVzestupne(int[] pole)
    {
        int[] poleKlon = pole.clone();

        for(int i = 0; i < poleKlon.length-1; i++)
        {
            for(int j = 0; j < poleKlon.length-1; j++)
            {
                if(poleKlon[j]>poleKlon[j+1])
                {
                    int temp = poleKlon[j];
                    poleKlon[j] = poleKlon[j+1];
                    poleKlon[j+1] = temp;
                }
            }
        }
        return poleKlon;
    }
}
