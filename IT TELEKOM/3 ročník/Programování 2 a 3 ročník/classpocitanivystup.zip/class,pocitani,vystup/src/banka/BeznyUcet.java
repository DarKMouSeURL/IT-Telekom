package banka;
public class BeznyUcet extends Ucet {
    //konstruktory
    public BeznyUcet() {
        super();
    }
    public BeznyUcet(String cislo, String majitel, double zustatek) {
        super(cislo, majitel, zustatek);
    }
    //metody
    @Override
    public String toString() {
        return "Bezny " + super.toString();
    }
    public boolean prevestNa(BeznyUcet cilovyUcet, double penize) {
        if(this.vybrat(penize)) {
            cilovyUcet.vlozit(penize);
            return true;
        } else {
            return false;
        }
    }
}
