package banka;
public class Ucet extends Object {
    //clenske promenne
    public static int pocet;
    private String cislo;
    private String majitel;
    protected double zustatek;
    //konstruktory
    public Ucet() {
        this("123456/0100", "Lojza Chytry", 50555.99);
        //this.cislo = "123456/0100";
        //this.majitel = "Lojza Chytry";
        //this.zustatek = 50555.99;
        //Ucet.pocet++;
    }
    public Ucet(String cislo, String majitel, double zustatek) {
        this.cislo = cislo;
        this.majitel = majitel;
        this.zustatek = zustatek;
        Ucet.pocet++;
    }
    //metody
    @Override
    public String toString() {
        return "Ucet: " + this.cislo + "; " + this.majitel + "; " + this.zustatek + " Kc; pocet uctu=" + Ucet.pocet;
    }
    public void vlozit(double penize) {
        this.zustatek+=penize;
    }
    public boolean vybrat(double penize) {
        if(penize <= this.zustatek) {
            this.vlozit(-penize);
            return true;
        }
        return false;
    }
}