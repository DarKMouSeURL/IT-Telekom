package banka;
public class SporiciUcet extends Ucet {
    //clenske promenne = atributy
    private double urokovaSazba;
    //konstruktory
    public SporiciUcet() {
        //super("444555/0200", "Karel Sporivy", 30000);
        //this.urokovaSazba = 10.0;
        this("444555/0200", "Karel Sporivy", 30000, 10.0);
    }
    public  SporiciUcet(String cislo, String majitel, double zustatek, double urokovaSazba) {
        super(cislo, majitel, zustatek);
        this.urokovaSazba = urokovaSazba;
    }
    //metody
    @Override
    public String toString() {
        return "Sporici " + super.toString() + " urok. sazba: " + this.urokovaSazba + " %";
    }
    public void pripsatUrok() {
        double urok =(this.urokovaSazba / 100.0) * this.zustatek;
        this.vlozit(urok);
    }
}