import java.util.ArrayList;
import java.util.Random;

public class Main {
public static void main(String[] args) {
    ArrayList<Integer> cisla = new ArrayList<>();
    Random ran = new Random();
    int zaporne = 0;

    for (int i = 0; i<=20; i++)
        cisla.add(ran.nextInt(-30,31));

    cisla.set(0, -cisla.getFirst());

    cisla.add(cisla.get(3));

    cisla.remove(cisla.size()/2);

    for (int i = 0; i<cisla.size();i++)
        if (cisla.get(i).equals(0))
            System.out.println("Nula");
        else if (cisla.get(i)<(Integer) 0)
            zaporne++;

    System.out.printf("pocet zapornych cisel v seznamu: %d", zaporne);
    }
}