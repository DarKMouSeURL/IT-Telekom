﻿using System.Security.Authentication.ExtendedProtection;

namespace ConsoleApp5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] nasobilka = new int[10];
            nasobilka[0] = 0;
            nasobilka[nasobilka.Length - 1] = 0;
            for (int i = 0; i < nasobilka.Length; i++)
            {
                nasobilka[i] = 5 * i;
                nasobilka[0] = 0;
                nasobilka[nasobilka.Length - 1] = 0;
                if (nasobilka[i] % 2 == 0)
                    Console.WriteLine(nasobilka[i]);

            }
            Console.WriteLine();

            Random rnd = new Random();
            int[] merak = new int[60];
            for (int i = 0; i < merak.Length; i++)
            {
                int num = rnd.Next(-100, 101);
                merak[i] = num;
                Console.Write(merak[i] + ",");
            }
            Console.WriteLine();

            Console.WriteLine(merak[0]);
            Console.WriteLine(merak[merak.Length - 1]);

            Console.WriteLine("Max v meraku: " + merak.Max(x => x));
            Console.WriteLine("Min v meraku: " + merak.Min());

            int kladne = 0;
            int zaporne = 0;
            int nula = 0;
            int prumer = 0;

            for (int i = 0; i < merak.Length; i++)
            {
                if (merak[i] < 0)
                {
                    kladne++;
                }
                if (merak[i] > 0)
                {
                    zaporne++;
                }
                if (merak[i] == 0)
                {
                    nula++;
                }
            }
            prumer /= merak.Length - 1;
            Console.WriteLine("Hodnot kladnych je: " + kladne);
            Console.WriteLine("Hodnot zaporne je: " + zaporne);
            Console.WriteLine("Hodnot nulovych je: " + nula);
            prumer = (kladne + zaporne + nula) / 3;
            Console.WriteLine("prumer je: " + prumer);

            int[] hodnoty_abs = new int[merak.Length];
            for (int i = 0; i < merak.Length-1; i++)
            {
                if (merak[i]<0)
                    merak[i] *= -1;                
                hodnoty_abs[i] = merak[i];
                Console.Write($"{merak[i]}, ");
            }

            int[] hodnoty_redukce = new int[hodnoty_abs.Length / 2];

            for (int i = 0; i < hodnoty_abs.Length; i++)
            {
                if (i%2==0)
                    hodnoty_redukce[i / 2] = hodnoty_abs[i];
            }

            for (int i = 0; i < hodnoty_redukce.Length; i++)
             

           
        }
    }
}