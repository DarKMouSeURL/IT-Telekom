﻿namespace ConsoleApp3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Vetveni if-else");
            //if-else
            int vek = 19;
            if (vek > 17)
            { 
                Console.WriteLine($"vek={vek}, je dospely, plnolety");
            }
            else
            { 
                Console.WriteLine($"vek={vek}, NENI pravda ze, je dospely, plnolety");
            }
            Console.WriteLine("----------------");
            /*
            for(int v = 1; v < 99; v++)
            {
                if (v > 17)
                {
                    Console.WriteLine($"vek={v}, je dospely, plnolety");
                }
                else
                {
                    Console.WriteLine($"vek={v}, NENI pravda ze, je dospely, plnolety");
                }
            }
            */

            string vysledek = BudeObed();
            Console.WriteLine(vysledek);

        }

        static string BudeObed()
        {
            string veta = "";
            for (int v = 1; v < 99; v++)
            {
                if (v > 17)
                {
                    //Console.WriteLine($"vek={v}, je dospely, plnolety");
                    veta = "Je plnolety, plnoleta";
                }
                else
                {
                    //Console.WriteLine($"vek={v}, NENI pravda ze, je dospely, plnolety");
                    veta = "NENI PRAVDA ZE, Je plnolety, plnoleta";
                }
            }
            return veta;
        }

    }
}
