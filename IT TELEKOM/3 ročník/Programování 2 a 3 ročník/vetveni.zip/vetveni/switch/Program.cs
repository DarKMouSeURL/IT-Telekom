﻿namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("zadej znamku: ");
            int znamka = int.Parse(Console.ReadLine());
            switch (znamka)
            { 
                case 1: Console.WriteLine("Vyborne"); break;
                case 2: Console.WriteLine("chvalitebne"); break;
                case 3: Console.WriteLine("dobre"); break;
                case 4: Console.WriteLine("dostatecne"); break;
                case 5: Console.WriteLine("nedostatecne"); break;
                default: Console.WriteLine("znamka neni"); break;
            }
            Console.Write("zadej den: ");
            string den = Console.ReadLine().Trim().ToLower();
            switch (den)
            {
                case "pondeli":
                case "utery":
                case "streda":
                case "ctvrtek":
                case "patek":
                    Console.WriteLine("Vsedni den"); break;
                case "sobota":
                case "nedele":
                    Console.WriteLine("Vikend"); break;
                default : Console.WriteLine("neni den"); break;
                 
            }
            Console.Write("zadej cislo: ");
            int cislo = int.Parse(Console.ReadLine());
            switch (cislo%2)
            {
                case 0:Console.WriteLine("Sude"); break;
                case 1:
                case 2: Console.WriteLine("Liche"); break;
            }
            Console.Write("zadej a: ");
            int a = int.Parse(Console.ReadLine());
            Console.Write("zadej b: ");
            int b = int.Parse(Console.ReadLine());
            Console.Write("zadej operaci: ");
            switch (Console.ReadKey());
            {
               
            }
        }
    }
}