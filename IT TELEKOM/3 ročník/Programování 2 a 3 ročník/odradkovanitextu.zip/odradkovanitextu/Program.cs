﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace odradkovanitextu
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string jm1 = "bohuslav";
            int vek1 = 45;
            string poz1 = "tady bude poznamka";
            int plat1 = 12555;

            Console.WriteLine($"{jm1.PadRight(12)}{}")
        }
    }
}
