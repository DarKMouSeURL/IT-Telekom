public enum EProspech {
    VYBORNY{
        @Override
        public String toString(){
            return "Vyborny";
        }
    },
    CHVALITEBNY{
        @Override
        public String toString(){
            return "Chvalitebny";
        }
    },
    DOBRY{
        @Override
        public String toString(){
            return "Dobry";
        }
    },
    DOSTATECNY{
        @Override
        public String toString(){
            return "Dostatecny";
        }
    },
    NEDOSTATECNY(){
            @Override
        public String toString(){
                return "Nedostatecny";
            }
    },
    NEHODNOCEN(){
        @Override
        public String toString() {
            return "Nehodnoceny";
        }
    }
}
