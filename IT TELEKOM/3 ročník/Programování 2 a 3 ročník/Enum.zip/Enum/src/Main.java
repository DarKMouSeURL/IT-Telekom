import java.util.ArrayList;
public class Main {
    public static void main(String[] args) {
        ArrayList<Zak> zaci = new ArrayList<>();
        Zak zak = new Zak("Martin", "M",EProspech.VYBORNY);
        Zak zak1 = new Zak("Perta", "CJ", EProspech.DOBRY);
        Zak zak2 = new Zak("Lukas", "ITCH", EProspech.VYBORNY);
        zaci.add(zak);
        zaci.add(zak1);
        zaci.add(zak2);

        for (Zak z:zaci){
            if (z.getProspech().equals(EProspech.VYBORNY))
                System.out.println(z.toString());
    }
    }
}