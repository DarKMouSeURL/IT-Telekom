public class Zak {
    private String jmeno;
    private String predmet;
    private EProspech prospech;

    public Zak(String jmeno, String predmet, EProspech prospech){
        this.jmeno=jmeno;
        this.predmet=predmet;
        this.prospech=prospech;
    }

    @Override
    public String toString() {
        return jmeno+" - "+predmet+" ("+prospech+")";
    }
    public EProspech getProspech(){return prospech;}
}
