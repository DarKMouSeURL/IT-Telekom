import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Random rn = new Random();
        Scanner cs = new Scanner(System.in);
        int cislohadane = rn.nextInt(1,100), cislouziv, pocetpokusu=0;
        boolean vyhra = false;
        System.out.println("Uhodněte tajné číslo mezi 1 a 99...");
        do {
            System.out.print("Tip: ");
            cislouziv = cs.nextInt();
            pocetpokusu++;
            if (cislouziv == cislohadane){
                System.out.printf("Uhodl jsi číslo!\nPočet pokusů byl %d",pocetpokusu);
                vyhra = true;
            } else if (cislouziv > cislohadane)
                System.out.println("Příliš vysoké číslo! Zkus znova.");
            else
                System.out.println("Příliš málo");
        } while (vyhra==false);
    }
}