import javax.swing.*;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Random rn = new Random();
        System.out.print("Zadej jméno: ");
        String jmeno = sc.nextLine();
        System.out.print("Zadej cenu za 1 dárek: ");
        float cena1 = Float.parseFloat(sc.nextLine());
        System.out.print("Zadej DPH: ");
        float dph = Float.parseFloat(sc.nextLine())/100+1;
        int pocet = rn.nextInt(1,101);

        float cena = cena1*dph*pocet;
        System.out.printf("Celková cena za %d dárků pro osobu %s je %.0f Kč vč. DPH", pocet, jmeno, cena);
    }
}