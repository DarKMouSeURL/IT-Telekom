import org.w3c.dom.ls.LSOutput;
import java.time.LocalDate;
import java.time.temporal.ValueRange;
import java.util.ArrayList;

public class Trida implements IValidace {

    private static ArrayList<Zak> zaci;
    private byte rocnik;
    private Pedagog tridni;

    public Trida(byte rocnik, Pedagog tridni){
        this.rocnik = rocnik;
        this.tridni = tridni;
        zaci = new ArrayList<Zak>();
    }

    @Override
    public String toString() {
        return "Trida{" +
                "zaci=" + zaci +
                ", rocnik=" + rocnik +
                ", tridni='" + tridni + '\'' +
                '}';
    }

    public String vratSeznamZaku(){
        String text = "";
        text+="************Seznam zaku***********"+System.lineSeparator();
        for (Zak z:zaci)
            text+=z.vratInfo()+System.lineSeparator();
        return text;
    }

    public String vratInfo(){
        String text = System.lineSeparator()+"*****************************"+System.lineSeparator();
        text+=String.format("%d. trida(tridni: &s)%n", rocnik, tridni.vratJmeno());
        text+=vratSeznamZaku();
        return text;
    }

    public static String seznam(){
        String text="";
        for (int i = 0; i<Main.zaci.size();i++)
            text+=1+i+". "+Main.zaci.get(i).getPrijmeni()+" "+Main.zaci.get(i).getJmeno()+"\n";
        return text;
    }

    //kap. 11
    public boolean jeZakVeTride(String RodneCislo){
        for (Zak z:zaci){
            if (z.getRodnecislo() == RodneCislo)
                return true;
        }
        return false;
    }

    public String pridejNovehoZaka(String jmeno, String prijmeni, String RodneCislo, LocalDate datum_narozeni, boolean chlapec){
        if(IValidace.rodneCisloKontrola(RodneCislo,chlapec, datum_narozeni)){
            zaci.add(new Zak(jmeno, prijmeni, RodneCislo, datum_narozeni, chlapec, rocnik));
            if (chlapec)
                return String.format("zak %s %s byl pridan do  %d tridy", jmeno, prijmeni, rocnik);
            else
                return String.format("Zakyne %s %s byla pridana do %d tridy", jmeno, prijmeni, rocnik);
        }
        else
            return String.format("Chyba");
    }
    public String odeberZaka(String rodneCislo){
        if (jeZakVeTride(rodneCislo)){
            for (Zak z:zaci)
                if (z.getRodnecislo().equals(rodneCislo)) {
                    zaci.remove(z);
                    return String.format("Zak %s %s byl odstranen z %d. tridy", z.getJmeno(), z.getPrijmeni(), z.getRocnik());
                }
            else{
                zaci.remove(z);
                        return String.format("Zakyne %s %s byla odstranena z %d tridy", z.getJmeno(), z.getPrijmeni(), z.getRocnik());

                }
        }
        return String.format("Chyba");
    }
    public String zvysRocnik(){
        rocnik++;
        for (Zak z:zaci)
            z.setRocnik(rocnik);
        return String.format("Trida se zvysila %d", rocnik);
    }

    public String vratZaka(String rodnecislo){
        for(Zak z:zaci){
            if (z.getRodnecislo().equals(rodnecislo))
                return vratInfo();
        }
        return String.format("Zak neexistuje podle rc");
    }

    public String vratZaka(int index){
        if (jeZakVeTride(zaci.get(index).getRodnecislo()))
            return vratInfo();
        return String.format("Chyba");
    }
    //kap. 15


    public static ArrayList<Zak> getZaci() {
        return zaci;
    }
}
