import java.io.StringReader;
import java.time.LocalDate;

public interface IValidace {
    public static boolean rodneCisloKontrola(String rc, boolean muz, LocalDate dn){
        if (!overFormatRc(rc)){
            System.out.println("Error");
            return false;
        }
        if (!overDelitelnost11(rc)){
            System.out.println("Error");
            return false;
        }
        if (!overMesic(rc, muz, dn)){
            System.out.println("Error");
            return false;
        }
        if (!overRok(rc, dn)){
            System.out.println("Error");
            return false;
        }
        return true;
    }
    private static boolean overFormatRc(String rc){
        if (rc.length()!=11)
            return false;
        if (rc.charAt(6)!='/')
            return false;
        for (int i=0; i<rc.length();i++){
            char aktualniZnak=rc.charAt(i);
            if (!Character.isDigit(aktualniZnak))
                return false;
        }
        return true;
    }
    private static boolean overDelitelnost11(String rc){
        String rcBezLomitka = rc.replace("/", "");
        long rcCislo = Long.parseLong(rcBezLomitka);
        if (rcCislo%11==0)
            return true;
        return false;
    }
    private static boolean overMesic(String rc, boolean muz, LocalDate dn){
        int rcMesic = Integer.parseInt(rc.substring(2,4));
        int dnMesic = dn.getMonth().getValue();
        if (!muz)
            dnMesic+=50;
        if (rcMesic==dnMesic)
            return true;
        else
            return false;
    }
    private static boolean overDen(String rc, LocalDate dn){
        int rcDen=Integer.parseInt(rc.substring(4,6));
        int dnDen=dn.getDayOfMonth();
        if (rcDen==dnDen)
            return true;
        else
            return false;
    }
    private static boolean overRok(String rc, LocalDate dn){
        int rcRok = Integer.parseInt(rc.substring(0,2));
        String dnRokString = String.valueOf(dn.getYear());
        int dnRok = Integer.parseInt(dnRokString.substring(2,4));
        if (rcRok == dnRok)
            return true;
        return false;
    }
}