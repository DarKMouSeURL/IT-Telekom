import java.time.LocalDate;
import java.util.ArrayList;

public class Pedagog extends Osoba{
    Etitul titul;
    ArrayList<EPredmet> aprobace;

    public Pedagog(String jmeno, String prijmeni, String rodneCislo, LocalDate datumNarozeni, Etitul titul){
        super(jmeno, prijmeni, rodneCislo, datumNarozeni);
        this.titul=titul;
        aprobace=new ArrayList<EPredmet>();
    }
    public Etitul getTitul(){return titul;}
    public void setTitul(Etitul titul){this.titul=titul;}

    public void pridejAprobaci(EPredmet predmet){
        if (!aprobace.contains(predmet))
            aprobace.add(predmet);
    }
    public String vratAprobace(){
        String text = "(";
        for (int i = 0; i<aprobace.size();i++){
            text+=aprobace.get(i);
            if (i!=aprobace.size()-1)
                text+=", ";
        }
        text+=")";
        return text;
    }
    public String vratJmeno(){
        if (titul.equals(Etitul.BEZ_TITULU))
            return String.format(" %s %s", jmeno, prijmeni);
        return String.format("%s %s %s", titul, jmeno, prijmeni);
    }
    //kpa. 14
    public String vratInfo(){
        /*String text = "";
        text+=String.format("%s %s\n",vratJmeno(),vratAprobace());
        text+=getDatumNarozeni();
        return text;*/
        return String.format("%s %s (%s), %d, rocnik",jmeno, prijmeni, getDatumNarozeni(), rocnik);
    }

    @Override
    public String toString() {
        return "Pedagog{" +
                "titul=" + titul +
                ", aprobace=" + aprobace +
                ", jmeno="+jmeno+'\''+
                ", prijmeni=" + prijmeni + '\''+
                ", rodneCislo=" + rodneCislo + '\''+
                ", datumNarozeni=" + datumNarozeni+
                '}';
    }
}
