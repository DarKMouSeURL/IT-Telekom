import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.time.temporal.ChronoUnit;

public class Zak extends Osoba {
    private boolean chlapec;
    private byte rocnik;
    private String rodnecislo;
    private LocalDate datumnarozeni;

    public Zak(String jmeno, String prijmeni, String rodnecislo, LocalDate datumnarozeni, boolean chlapec, byte rocnik){
        super(jmeno, prijmeni, rodnecislo, datumnarozeni);
        this.chlapec=chlapec;
        this.rocnik=1;
    }

    public Zak(String jmeno, String prijmeni, String rodnecislo, LocalDate datumnarozeni, boolean chlapec) {
        this(jmeno, prijmeni, rodnecislo, datumnarozeni, chlapec, (byte)1);
    }

    public Zak(){
    }

    @Override
    public String toString() {
        return "Zak{" +
                "jmeno='" + jmeno + '\'' +
                ", prijmeni='" + prijmeni + '\'' +
                ", rodnecislo='" + rodnecislo + '\'' +
                ", chlapec=" + chlapec +
                ", rocnik=" + rocnik +
                ", datumnarozeni=" + datumnarozeni +
                '}';
    }

    public void vypisInfo(){
        String text="";
        text+=String.format("%s %s", jmeno, prijmeni);
        text+="("+datumnarozeni.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM))+"), ";
        text+=rocnik+". rocnik";
        System.out.println(text);
    }

    public String vratInfo(){
        String text="";
        text+=String.format("%s %s", jmeno, prijmeni);
        text+="("+datumnarozeni.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM))+"), ";
        text+=rocnik+". rocnik";
        return text;
    }

    public String VratInfo2(){
        String pohlavi = "divka, ";
        String ro ="Nematuritni rocnik";
        if (chlapec == true)
            pohlavi = "chlapec, ";
        if (rocnik == 4)
            ro = "Maturitni rocnik";

        return "„"+jmeno+" "+prijmeni+" - "+pohlavi+ro+"\"";
    }
/*    public void zmenPrijmeni(String novePrijmeni){
        prijmeni = novePrijmeni;
    }*/

    public void zvysRocnik(){
        rocnik++;
    }

    public String pohlavi(){
        return (chlapec)?"chlapec": "divka";
    }

    public boolean plnoletost(){
        LocalDate dnes = LocalDate.now();
        Period doba = Period.between(datumnarozeni, dnes);
        int vek = (int)doba.get(ChronoUnit.YEARS);
        if(vek>=18)
            return true;
        else
            return false;
    }
    //kapitola 8
    public void setPrijmeni(String prijmeni){
        this.prijmeni=prijmeni;
    }

    public String getPrijmeni(){
        return prijmeni;
    }

    public String getJmeno(){
        return jmeno;
    }

    public boolean isChlapec(){
        return chlapec;
    }

    public void setChlapec(boolean chlapec){
        this.chlapec=chlapec;
    }

    public String getRodnecislo(){
        return rodnecislo;
    }

    public byte getRocnik(){
        return rocnik;
    }

    public void setRocnik(byte rocnik){
        this.rocnik=rocnik;
    }
    //kap 15
    public String toCSV(){
        return String.format("%s;%s;%s;%s;%s;%s;", jmeno, prijmeni, rodnecislo, datumnarozeni, chlapec, rocnik);
    }
}