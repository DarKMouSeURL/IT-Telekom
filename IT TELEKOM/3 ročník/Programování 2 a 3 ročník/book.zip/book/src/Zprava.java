public class Zprava {
    private String uvitaciZprava;

    public String vratUvitaciZpravuSOslovenim(String jmeno) {
        return String.format("{0}, {1}", jmeno, uvitaciZprava);
    }

    public void nastavUvitaciZpravu(String text){
        uvitaciZprava=text;
    }

    public String vratUvitaciZpravu(){
        return uvitaciZprava;
    }

    public void smazUvitaciZpravu(){
        uvitaciZprava="";
    }
}
