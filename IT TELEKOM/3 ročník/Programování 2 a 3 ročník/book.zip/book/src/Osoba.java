import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;

public abstract class Osoba {
    protected String jmeno;
    protected String prijmeni;
    protected String rodneCislo;
    protected LocalDate datumNarozeni;
    protected byte rocnik;

    public String getJmeno() {return jmeno;}

    public String getPrijmeni(){return prijmeni;}
    public void setPrijmeni(String prijmeni) {this.prijmeni=prijmeni;}
    public byte getRocnik(byte rocnik){return rocnik;}
    public String getRodneCislo(){return rodneCislo;}
    public String getDatumNarozeni(){return datumNarozeni.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM));}

    public Osoba(String jmeno, String prijmeni, String rodneCislo, LocalDate datumNarozeni){
        this.jmeno = jmeno;
        this.prijmeni = prijmeni;
        this.rodneCislo = rodneCislo;
        this.datumNarozeni = datumNarozeni;
    }

    public Osoba(){}
}
