public enum Etitul {
/*    MGR,
    ING,
    BC,
    PHDR,
    BEZ_TITULU,*/

/*    MGR{
        @Override
        public String toString(){return "Mgr.";}
    },
    ING{
        @Override
        public String toString(){return "Ing,=.";}
    },
    BC{
        @Override
        public String toString(){return "Bc.";}
    },
    PHDR{
        @Override
        public String toString(){return "Phdr.";}
    },
    BEZ_TITULU{
        @Override
        public String toString(){return "";}
    }*/
    MGR("Mgr."),
    ING("Ing."),
    BC("Bc."),
    PHDR("Phdr."),
    BEZ_TITULU("");
    private String textTitulu;
    private Etitul(String textTitulu){
        this.textTitulu=textTitulu;
    }
    @Override
    public String toString(){
        return textTitulu;
    }
}
