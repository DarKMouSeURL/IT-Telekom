public enum EPredmet {
    PR, CJ, AJ, D, M, ITCH, F, TV, CHE, Z
}
