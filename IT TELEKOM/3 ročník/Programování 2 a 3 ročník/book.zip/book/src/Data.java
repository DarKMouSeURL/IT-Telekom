import java.time.LocalDate;
import java.io.*;
public class Data {
    static public Pedagog p1;
    static public Trida t1;


    static public void nactiTestovaciData(){
        p1=new Pedagog("Gabriela", "Ohmova", "215383/1475", LocalDate.of(1983,3,21), Etitul.MGR);
        p1.pridejAprobaci(EPredmet.M);
        p1.pridejAprobaci(EPredmet.ITCH);

        t1 = new Trida((byte) 2, p1);
    }
    static private File slozka;
    static public void vytvorSlozku() throws Exception{
        slozka = new File(System.getenv("APPDATA")+File.separator+"Evidence skoly");
        if (!slozka.isDirectory())
            slozka.mkdirs();
    }
    static private File souborZaci;
    static public void vytvorSouborZ() throws IOException{
        souborZaci = new File(slozka+File.separator+"zaci.csv");
        if (!souborZaci.exists())
            souborZaci.createNewFile();
    }
    static public String csvZaznamyZ(){
        String csvZaznamy="";
        for (Zak zak : t1.getZaci()){
            csvZaznamy+=zak.toCSV()+"\n";
        }
        return csvZaznamy;
    }
    static public void ulozZakyCSV() throws Exception{
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(souborZaci,false))){
            bw.write(csvZaznamyZ());
            bw.flush();
        }
    }
    static public void nactiZakyCSV() throws IOException{
        try (BufferedReader br = new BufferedReader(new FileReader(souborZaci))){
            String radek;
            while ((radek=br.readLine())!=null){
                String[] pole = radek.split(";");
                String jmen = pole[0];
                String prijm = pole[1];
                String rodneC = pole[2];
                LocalDate datumNar = LocalDate.parse(pole[3]);
                boolean chlap = Boolean.parseBoolean(pole[4]);
                t1.pridejNovehoZaka(jmen,prijm, rodneC,datumNar, chlap);
            }
        }
    }
}
