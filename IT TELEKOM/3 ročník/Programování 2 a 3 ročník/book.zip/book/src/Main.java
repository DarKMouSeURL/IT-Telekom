import javax.xml.datatype.DatatypeFactory;
import java.time.LocalDate;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.ArrayList;

public class Main {
    static ArrayList<Zak> zaci = new ArrayList<>(); //kap. 9
    public static void main(String[] args) {
/*        Zak zak1 = new Zak();
        zak1.jmeno="Patrik";
        zak1.prijmeni="Novotný";
        zak1.rodnecislo="991236/6789";
        LocalDate ld1=LocalDate.of(2000,4,28);
        zak1.datumnarozeni = ld1;
        zak1.chlapec=true;
        zak1.rocnik=1;*/

        LocalDate ld2 = LocalDate.of(2001,Month.MARCH, 28);
        Zak zak2= new Zak("Jana", "Pancáková", "3215456/5125", ld2, false, (byte)2);
        zak2.vypisInfo();
        System.out.println(zak2.vratInfo());
        System.out.println(zak2.toString());
        System.out.println(zak2);
        Zak zak3= new Zak("Jindřich", "Smetana", "32146556/2125", LocalDate.of(2002,12,14), true);

        System.out.println(ld2.format(DateTimeFormatter.ISO_DATE));
        System.out.println(ld2.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL)));
        System.out.println(ld2.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.LONG)));
        System.out.println(ld2.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM)));
        System.out.println(ld2.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT)));

        Zprava zprava = new Zprava();
        zprava.nastavUvitaciZpravu("Hi");
        System.out.println(zprava.vratUvitaciZpravu());
        System.out.println(zprava.vratUvitaciZpravuSOslovenim("Martin"));
        zprava.smazUvitaciZpravu();
        //7. kapitola
        //zak2.zmenPrijmeni("NovePrijmeni");
        System.out.println(zak2.VratInfo2());
        zak2.zvysRocnik();
        //zadani 6. kapitola
        System.out.println(zak2.VratInfo2());
        //7. kapitola
        System.out.println(zak2.pohlavi());
        System.out.println(zak2.plnoletost());
/*        zak2.rocnik=5;
        System.out.println(zak2.rocnik);*/
        //kapitola 8
        System.out.println(zak2.getPrijmeni());
        System.out.println(zak2.isChlapec());

        //kap. 9
        LocalDate ld3 = LocalDate.of(2000,Month.MARCH, 4);
        Zak zak1 = new Zak("Vlasta", "Novotna", "111111/5621", ld2, false, (byte)2);
        zaci.add(zak1);
        zaci.add(zak2);
        for(int i = 0; i<zaci.size(); i++)
            System.out.println(zaci.get(i).vratInfo());
        for(Zak z:zaci)
            System.out.println(z.vratInfo());
        Zak[] zaciPole = new Zak[zaci.size()];
        zaciPole = zaci.toArray(zaciPole);
        //kap. 14
        Pedagog p1= new Pedagog("Gabriela", "Ohmova", "215383/1475", LocalDate.of(1983,3,21), Etitul.MGR);
        p1.pridejAprobaci(EPredmet.M);
        p1.pridejAprobaci(EPredmet.ITCH);
        Pedagog p2 = new Pedagog("Milan", "Javicky", "118587/1475", LocalDate.of(1987,5,11),Etitul.BEZ_TITULU);
        System.out.println(p1.vratJmeno());
        System.out.println(p1.vratJmeno());
        System.out.println(p1.vratInfo());

        //kap. 10
        Trida t1 = new Trida((byte)2,p1);
        System.out.println(t1);
        System.out.println(Trida.seznam());

        //kap. 11
        System.out.println(t1.pridejNovehoZaka("Vlasta", "Vyborna", "987654/3210", LocalDate.of(2002,4,20), false));
        System.out.println(t1.pridejNovehoZaka("Petr", "Poskolak", "123456/1234", LocalDate.of(2002,4,20), true));
        System.out.println(t1.pridejNovehoZaka("Ales", "Premiant", "458745/8569", LocalDate.of(2000, 3, 3), true ));

        System.out.println(t1.vratSeznamZaku());

        System.out.println(t1.pridejNovehoZaka("Antonin", "Novy", "123456/1234", LocalDate.of(2001,4,8), true));
        System.out.println(t1.pridejNovehoZaka("Alena", "Javova", "789457/8569", LocalDate.of(2000,2,25),false));

        System.out.println(t1.vratSeznamZaku());

        System.out.println(t1.odeberZaka("987654/3218"));
        System.out.println(t1.odeberZaka("444444/4444"));
        System.out.println(t1.vratSeznamZaku());

        System.out.println(t1.vratInfo());
        System.out.println(t1.zvysRocnik());
        System.out.println(t1.vratInfo());

        System.out.println(t1.vratZaka(9));

        System.out.println(t1.pridejNovehoZaka("Vlasta", "Vyborna", "115524/5652", LocalDate.of(2011,5,24), false));

        //kap. 15
        Data.nactiTestovaciData();
        try {
            Data.vytvorSlozku();
        }
        catch (Exception e) {
            System.err.println("Slozna nemohla byt vytvorena");
        }
        try {
            Data.vytvorSouborZ();
        }
        catch (Exception e){
            System.err.println("Slozna nemohl byt vytvoren");
        }
        try {
            Data.ulozZakyCSV();
        }
        catch (Exception e){
            System.err.println("Data nelze ulozit"+e.getMessage());
        }
    }
}