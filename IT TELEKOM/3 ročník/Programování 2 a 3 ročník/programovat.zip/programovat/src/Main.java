import java.util.EnumSet;

public class Main {
    public static void main(String[] args) {
        Zak z1 = new Zak("Alis", 3, EnumSet.of(EPredmet.M, EPredmet.PR, EPredmet.TV), new Absence(0));
        Zak z2 = new Zak(z1);
        z2.setJmeno("Eda");
        z2.pridejPredemt(EPredmet.AJ);
        z2.absence.setZameskanych(100);

        System.out.println(z1);
        System.out.println();
        System.out.println(z2);
    }
}