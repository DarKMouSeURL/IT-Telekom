import java.util.Objects;

public class Absence {
    int zameskanych;
    int omluvenych;
    int neomluvenych;

    public Absence(int zameskanych) {
        this.zameskanych = zameskanych;
    }

    public void setZameskanych(int zameskanych) {
        this.zameskanych = zameskanych;
    }

    public void pridejZameskanych(int hodiny){
        this.zameskanych+=hodiny;
    }

    @Override
    public String toString() {
        return "Absence{" +
                "zameskanych=" + zameskanych +
                ", omluvenych=" + omluvenych +
                ", neomluvenych=" + neomluvenych +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Absence absence)) return false;
        return zameskanych == absence.zameskanych && omluvenych == absence.omluvenych && neomluvenych == absence.neomluvenych;
    }

    @Override
    public int hashCode() {
        return Objects.hash(zameskanych, omluvenych, neomluvenych);
    }
}
