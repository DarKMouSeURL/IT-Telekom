public enum EPredmet {
    M, ITCH, CJ, PR, PS, F, AJ, NJ, TV
}
