import java.util.EnumSet;
import java.util.Objects;

public class Zak {
    String jmeno;
    int rocnik;
    EnumSet predmety;
    Absence  absence;

    public Zak(String jmeno, int rocnik, EnumSet predmety, Absence absence) {
        this.jmeno = jmeno;
        this.rocnik = rocnik;
        this.predmety = predmety;
        this.absence = absence;
    }

    public Zak(Zak zz){
        this.jmeno = zz.jmeno;
        this.rocnik = zz.rocnik;
        this.predmety = zz.predmety;
        this.absence = zz.absence;
    }

    public void setJmeno(String jmeno) {
        jmeno = jmeno;
    }

    public void setRocnik(int rocnik) {
        this.rocnik = rocnik;
    }

    public void setPredmety(EnumSet predmety) {
        this.predmety = predmety;
    }

    public void setAbsence(Absence absence) {
        this.absence = absence;
    }

    @Override
    public String toString() {
        return "Zak{" +
                "Jmeno='" + jmeno + '\'' +
                ", rocnik=" + rocnik +
                ", predmety=" + predmety +
                ", absence=" + absence +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Zak zak)) return false;
        return rocnik == zak.rocnik && Objects.equals(jmeno, zak.jmeno) && Objects.equals(predmety, zak.predmety) && Objects.equals(absence, zak.absence);
    }

    @Override
    public int hashCode() {
        return Objects.hash(jmeno, rocnik, predmety, absence);
    }

    public void pridejPredemt(EPredmet predmet){
        predmety.add(predmet);
    }
}
