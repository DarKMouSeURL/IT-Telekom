﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oop__kino__necoo
{
    internal class Kino
    {
        public string nazev;
        public DateTime datumacas;
        public bool pristupny = true;
        public double cena;

        public Kino(string nazev, DateTime datumacas, bool pristupny, double cena)
        {
            this.nazev = nazev;
            this.datumacas = datumacas;
            this.pristupny = pristupny;
            this.cena = cena;
        }

        public Kino(string nazev, bool pristupny)
        {
            this.nazev = nazev;
            this.pristupny = pristupny;
        }

        public override string ToString()
        {
            return string.Format($"{this.GetType()}[nazev: {nazev}, datumCas: {datumacas}, pristupny: {pristupny}, cena: {cena}]");
        }

        public string VratInfo()
        {
            return string.Format($"{nazev} ({pristupny})   ....   {datumacas.Day}. {datumacas.Month}.  {datumacas.Hour}:{datumacas.Minute} ....   cena: {cena}");
        }
    }
}
