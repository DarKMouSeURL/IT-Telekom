﻿
using System.Data;

namespace oop__kino__necoo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Kino> list = new List<Kino>();
            DateTime c = new DateTime(2005,4,12,20,00,00);
            Kino kino1 = new Kino("SLunovrat", c, false, 190);

            Kino kino2 = new Kino("Slunovrat povstal", true);
            //---------------------------------------------------------------------//
            try:
                Console.WriteLine("Nazev filmu: ");
                string unazev = Console.ReadLine();
                Console.WriteLine("Rok:");
                int rok = int.Parse(Console.ReadLine());
                Console.WriteLine("Mesic:");
                int mesic = int.Parse(Console.ReadLine());
                Console.WriteLine("Den:");
                int den = int.Parse(Console.ReadLine());
                Console.WriteLine("Hodina(2):");
                int hodina = int.Parse(Console.ReadLine());
                Console.WriteLine("Minuta(2):");
                int minuta = int.Parse(Console.ReadLine());
                Console.WriteLine("Sekunda(2):");
                int sekunda = int.Parse(Console.ReadLine());
                DateTime v = new DateTime(rok, mesic, den, hodina, minuta, sekunda);
                Console.WriteLine("Je pristupny:");
                string odpoved=Console.ReadLine().ToLower();
                bool odpovedd;
                if (odpoved == "ano" | odpoved == "a")
                    odpovedd = true;
                else
                    odpovedd = false;
                Console.WriteLine("Cena: ");
                int cenovka = int.Parse(Console.ReadLine());

                Kino kino3 = new Kino(unazev, v, odpovedd, cenovka);
                list.Add(kino1);
                list.Add(kino2);
                list.Add(kino3);

            foreach (Kino kino in list)
                Console.WriteLine(kino.ToString());
            foreach (Kino kino in list)
                Console.WriteLine(kino.VratInfo());
        }
    }
}