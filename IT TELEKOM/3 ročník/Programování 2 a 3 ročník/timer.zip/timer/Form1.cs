﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace timer
{
    enum Den
    { 
        Po,Ut,St,Ct,Pa,So,Ne
    }
    public partial class Form1 : Form
    {
        Den den = Den.Po;
        int i = 0;
        int u = 0;
        int y = 0;
        int t = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
            i++;
            label1.Text = i.ToString();
            
        }

        private void btstart_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            timer2.Enabled = true;
            timer3.Enabled = true;
            timer4.Enabled = true;
            timer4.Enabled = true;
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            u++;
            label2.Text = u.ToString();
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            y++;
            label3.Text = y.ToString();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void timer4_Tick(object sender, EventArgs e)
        {
            t++;
            label4.Text = t.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            timer2.Enabled = false;
            timer3.Enabled = false;
            timer4.Enabled = false;
            timer4.Enabled = false;
        }

        private void timer5_Tick(object sender, EventArgs e)
        {
            Random nahoda = new Random();
            int nahcislo = nahoda.Next(0, 7);
            Den losovani = (Den)nahcislo;
            label5.Text = losovani.ToString();
            if (losovani == Den.Ne)
            {
                timer2.Enabled = false;
            }
        }
    }
}
