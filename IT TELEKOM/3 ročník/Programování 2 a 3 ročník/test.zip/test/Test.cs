﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3Cb_pisemka
{
    static internal class Test
    {

        public static void OtestovaniZnaku(string znak)
        {
            bool charJeOk = char.TryParse(znak, out char z);

            if (charJeOk)
                Console.WriteLine($"- {z} -");
            else
                Console.WriteLine("Chyba");
        }



        public static void OtestovaniZnamky(string znamka)
        {
            try
            {
                int z = int.Parse(znamka);


                if (z < 1 || z > 5)
                    throw new FormatException();
             }

            catch (FormatException)
            {
                Console.WriteLine("Nejedná se o validní hodnotu známky 1-5");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void Zapis(string nazevSouboru, string text)
        {
            StreamWriter sw = null;
            using (sw = new StreamWriter(nazevSouboru, true, Encoding.UTF8))
            {
                sw.WriteLine(text);
                sw.Flush();
            }
        }
    }
}
