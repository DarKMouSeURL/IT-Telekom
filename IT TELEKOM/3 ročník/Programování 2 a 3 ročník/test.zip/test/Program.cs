﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3Cb_pisemka
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Test.OtestovaniZnaku("0");

            Test.OtestovaniZnamky("7");

            try
            {
                Test.Zapis("zvirata.txt", "pes");
            }
            catch (Exception)
            {
                Console.WriteLine("Chyba zápisu");
            }

            Console.ReadLine();
        }
    }
}
