﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
namespace odzacatku
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int c = 0;
            Console.Write("zvol prvni cislo: ");
            string prvniCislo=Console.ReadLine();
            Console.Write("zvol DRUHE cislo: ");
            string druheCislo = Console.ReadLine();

            Sum(prvniCislo, druheCislo, ref c);

            Console.WriteLine($"soucet cisel {prvniCislo} + {druheCislo} je {c}");
            Console.Read();
        }

        private static bool Sum(string a, string b, ref int c) {
            int x, y;
            if (int.TryParse(a, out x) && int.TryParse(b, out y))
            {
                c= x+y;
                return true;
            }
            return false;
        }
    }
}
