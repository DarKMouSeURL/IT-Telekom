﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjektHadaniCisel
{
    public partial class Form1 : Form
    {

        public int cisloTajne = new Random().Next(20);
        public int pocetpokusu = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //kod pro pokus klik....
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //int cisloTajne = 19;
            //int cisloTajne = new Random().Next(20);
            //this.cisloTajne = new Random().Next(20);


            string hornimezstr = textBoxhornimez.Text;
            int hornimez = Convert.ToInt32(hornimezstr);
            this.cisloTajne = new Random().Next(hornimez);
            label1.Text =  cisloTajne.ToString();
            buttonAkceHra.Enabled = true;
            labelPP.Text = "0";
            this.pocetpokusu = 0;

        }

        private void buttonAkceHra_Click(object sender, EventArgs e)
        {
            string cisloZadaneStr = textBoxZadatCislo.Text;
            int cisloZadane = Convert.ToInt32(cisloZadaneStr);
            this.pocetpokusu = this.pocetpokusu + 1;
            labelPP.Text = this.pocetpokusu.ToString();

            if (cisloZadane == this.cisloTajne)
            {
                labelPrubehHry.BackColor = Color.Lime;
                //Console.WriteLine("Vyhra!!! Konec hry...");
                labelPrubehHry.Text = "Příště takové štěstí nebudeš mít...";
                buttonAkceHra.Enabled = false;

                labelnapoveda.Text = "napoveda...";
                textBoxnapoveda.Text = "napoveda....";
            }
            else
            {
                labelPrubehHry.BackColor = Color.Red;
                //Console.WriteLine("Prohra! Pokracuj...");
                labelPrubehHry.Text = "HA! Vedle...";
                //this.pocetpokusu = this.pocetpokusu + 1;
                //labelPP.Text = this.pocetpokusu.ToString();
                if (cisloZadane > this.cisloTajne)
                {
                    labelnapoveda.Text = "to je moc";
                    labelnapoveda.BackColor = Color.AliceBlue;
                    textBoxnapoveda.Text = "to je moc";
                    textBoxnapoveda.BackColor = Color.MediumPurple;
                }
                else 
                {
                    labelnapoveda.Text = "to je zase malo";
                    labelnapoveda.BackColor = Color.Cornsilk;
                    textBoxnapoveda.Text = "to je zase malo";
                    textBoxnapoveda.BackColor = Color.LightGoldenrodYellow;
                }
            }
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }

        private void textBoxZadatCislo_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxnapoveda_TextChanged(object sender, EventArgs e)
        {
           

            
        }

        private void buttonlevy_MouseEnter(object sender, EventArgs e)
        {
            buttonlevy.Visible = false;
            buttonpravy.Visible = true;
        }

        private void buttonpravy_MouseEnter(object sender, EventArgs e)
        {
            buttonlevy.Visible = true;
            buttonpravy.Visible=false;
        }
    }
}
