﻿namespace ProjektHadaniCisel
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonAkceHra = new System.Windows.Forms.Button();
            this.textBoxZadatCislo = new System.Windows.Forms.TextBox();
            this.labelPrubehHry = new System.Windows.Forms.Label();
            this.labelnapoveda = new System.Windows.Forms.Label();
            this.textBoxnapoveda = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.labelPP = new System.Windows.Forms.Label();
            this.buttonlevy = new System.Windows.Forms.Button();
            this.buttonpravy = new System.Windows.Forms.Button();
            this.textBoxhornimez = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button1.Location = new System.Drawing.Point(50, 150);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(262, 80);
            this.button1.TabIndex = 0;
            this.button1.Text = "Nova hra";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(1, 1);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(23, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "?";
            this.label1.Visible = false;
            // 
            // buttonAkceHra
            // 
            this.buttonAkceHra.BackColor = System.Drawing.Color.Navy;
            this.buttonAkceHra.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonAkceHra.Location = new System.Drawing.Point(637, 150);
            this.buttonAkceHra.Name = "buttonAkceHra";
            this.buttonAkceHra.Size = new System.Drawing.Size(352, 80);
            this.buttonAkceHra.TabIndex = 2;
            this.buttonAkceHra.Text = "Akce";
            this.buttonAkceHra.UseVisualStyleBackColor = false;
            this.buttonAkceHra.Click += new System.EventHandler(this.buttonAkceHra_Click);
            // 
            // textBoxZadatCislo
            // 
            this.textBoxZadatCislo.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBoxZadatCislo.Location = new System.Drawing.Point(497, 291);
            this.textBoxZadatCislo.Name = "textBoxZadatCislo";
            this.textBoxZadatCislo.Size = new System.Drawing.Size(303, 38);
            this.textBoxZadatCislo.TabIndex = 3;
            this.textBoxZadatCislo.Text = "sem zadej cislo";
            this.textBoxZadatCislo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxZadatCislo.WordWrap = false;
            this.textBoxZadatCislo.TextChanged += new System.EventHandler(this.textBoxZadatCislo_TextChanged);
            // 
            // labelPrubehHry
            // 
            this.labelPrubehHry.AutoSize = true;
            this.labelPrubehHry.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelPrubehHry.Location = new System.Drawing.Point(245, 565);
            this.labelPrubehHry.Name = "labelPrubehHry";
            this.labelPrubehHry.Size = new System.Drawing.Size(50, 39);
            this.labelPrubehHry.TabIndex = 4;
            this.labelPrubehHry.Text = "---";
            // 
            // labelnapoveda
            // 
            this.labelnapoveda.AutoSize = true;
            this.labelnapoveda.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelnapoveda.Location = new System.Drawing.Point(629, 520);
            this.labelnapoveda.Name = "labelnapoveda";
            this.labelnapoveda.Size = new System.Drawing.Size(139, 46);
            this.labelnapoveda.TabIndex = 5;
            this.labelnapoveda.Text = "help....";
            // 
            // textBoxnapoveda
            // 
            this.textBoxnapoveda.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBoxnapoveda.Location = new System.Drawing.Point(577, 414);
            this.textBoxnapoveda.Name = "textBoxnapoveda";
            this.textBoxnapoveda.ReadOnly = true;
            this.textBoxnapoveda.Size = new System.Drawing.Size(262, 53);
            this.textBoxnapoveda.TabIndex = 6;
            this.textBoxnapoveda.Text = "help...";
            this.textBoxnapoveda.TextChanged += new System.EventHandler(this.textBoxnapoveda_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(12, 291);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(279, 31);
            this.label2.TabIndex = 7;
            this.label2.Text = "pocet hokusu pokusu:";
            // 
            // labelPP
            // 
            this.labelPP.AutoSize = true;
            this.labelPP.BackColor = System.Drawing.Color.MediumOrchid;
            this.labelPP.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelPP.Location = new System.Drawing.Point(281, 280);
            this.labelPP.Name = "labelPP";
            this.labelPP.Size = new System.Drawing.Size(43, 46);
            this.labelPP.TabIndex = 8;
            this.labelPP.Text = "0";
            // 
            // buttonlevy
            // 
            this.buttonlevy.BackColor = System.Drawing.Color.Red;
            this.buttonlevy.Location = new System.Drawing.Point(217, 649);
            this.buttonlevy.Name = "buttonlevy";
            this.buttonlevy.Size = new System.Drawing.Size(292, 135);
            this.buttonlevy.TabIndex = 9;
            this.buttonlevy.UseVisualStyleBackColor = false;
            this.buttonlevy.MouseEnter += new System.EventHandler(this.buttonlevy_MouseEnter);
            // 
            // buttonpravy
            // 
            this.buttonpravy.BackColor = System.Drawing.Color.Blue;
            this.buttonpravy.Location = new System.Drawing.Point(754, 649);
            this.buttonpravy.Name = "buttonpravy";
            this.buttonpravy.Size = new System.Drawing.Size(314, 135);
            this.buttonpravy.TabIndex = 10;
            this.buttonpravy.UseVisualStyleBackColor = false;
            this.buttonpravy.Visible = false;
            this.buttonpravy.MouseEnter += new System.EventHandler(this.buttonpravy_MouseEnter);
            // 
            // textBoxhornimez
            // 
            this.textBoxhornimez.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBoxhornimez.Location = new System.Drawing.Point(48, 439);
            this.textBoxhornimez.Name = "textBoxhornimez";
            this.textBoxhornimez.Size = new System.Drawing.Size(125, 53);
            this.textBoxhornimez.TabIndex = 11;
            this.textBoxhornimez.Text = "100";
            this.textBoxhornimez.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(44, 493);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(132, 31);
            this.label3.TabIndex = 12;
            this.label3.Text = "horni mez";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGray;
            this.ClientSize = new System.Drawing.Size(1293, 850);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBoxhornimez);
            this.Controls.Add(this.buttonpravy);
            this.Controls.Add(this.buttonlevy);
            this.Controls.Add(this.labelPP);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxnapoveda);
            this.Controls.Add(this.labelnapoveda);
            this.Controls.Add(this.labelPrubehHry);
            this.Controls.Add(this.textBoxZadatCislo);
            this.Controls.Add(this.buttonAkceHra);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Hra hadani cisel";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonAkceHra;
        private System.Windows.Forms.TextBox textBoxZadatCislo;
        private System.Windows.Forms.Label labelPrubehHry;
        private System.Windows.Forms.Label labelnapoveda;
        private System.Windows.Forms.TextBox textBoxnapoveda;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label labelPP;
        private System.Windows.Forms.Button buttonlevy;
        private System.Windows.Forms.Button buttonpravy;
        private System.Windows.Forms.TextBox textBoxhornimez;
        private System.Windows.Forms.Label label3;
    }
}

