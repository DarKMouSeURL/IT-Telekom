﻿namespace ConsoleApp3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random random = new Random();
            int tajnecislo = random.Next(1,100);
            Console.Write("Tipni si číslo(celé): ");
            int hadanecislo = int.Parse(Console.ReadLine());
            int pocetpokusu = 1;

            if (hadanecislo == tajnecislo)
            {
                Console.WriteLine("Na první pokus, frajer!");
                Console.WriteLine("Uhodl jsi to na první pokusu!");
            }
            else
            {
                while (true)
                {
                    if (hadanecislo > tajnecislo)
                        Console.WriteLine("Tajné číslo je menší!");
                    else if (hadanecislo < tajnecislo)
                        Console.WriteLine("Tajné číslo je větší!");
                    else
                    {
                        Console.WriteLine("Uhodl jsi to!");
                        Console.WriteLine($"Uhodl jsi to na {pocetpokusu}. pokus!");
                        break;
                    }
                    Console.Write("tipni si znovu cislo: ");
                    hadanecislo = int.Parse(Console.ReadLine());
                    pocetpokusu++;
                }
            }
        }
    }
}