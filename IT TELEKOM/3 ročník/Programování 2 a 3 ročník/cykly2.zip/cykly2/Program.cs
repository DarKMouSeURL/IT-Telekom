﻿namespace cykkly
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*
            int min = 0;
            int max = 10;
            Random neco = new Random();
            int los = neco.Next(min, max + 1);
            */
            int cislo = -21;
            while (cislo < 0)
            {
                cislo++;
                Console.WriteLine(cislo);
            }

            int cislo2 = -21;
            while (cislo2 < -1)
            {
                cislo2++;
                Console.WriteLine(cislo2);
            }
            /*
            int cislo3 = int.Parse(Console.ReadLine());
            int cislo4 = int.Parse(Console.ReadLine());
            int n = cislo4;
            
            do
            {
                int vysledek = cislo4 - cislo3 - cislo3 - cislo3;
                Console.WriteLine(vysledek);
            } while (false);
            */

            int nasobilka = 6;
            int b = 10;
            while (b>0)
            {
                int g = nasobilka * b;
                Console.Write($"{g} ");
                --b;
            }
            Console.WriteLine("zadej vetu, kdyz end konec programu");
            string veta = Console.ReadLine();
            while (veta != "end")
            {
                Console.WriteLine("zadej vetu, kdyz end konec programu");
                veta = Console.ReadLine();
            }
            Console.WriteLine("///////////////////////////////////////////////////////");
            int pokus = 1;
            int pocetcisel = 0;
            int los = 4;
            while (los%17!=0)
            {
                int min = -100;
                int max = 100;
                Random neco = new Random();
                los = neco.Next(min, max + 1);
                Console.WriteLine(los);
                pokus++;
                pocetcisel++;
                Console.WriteLine(los);
            }
        }
    }
}