﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3Cb_uzivRozhrani
{
    static class Data
    {
        static List<double> castky = new List<double>();

        public static string Vloz(double castka)
        {
            castky.Add(castka);
            return "Byla vložena čáska " + castka;
        }

        public static string Vyber(double castka)
        {
            if (castky.Contains(castka))
                {
                castky.Remove(castka);
                return "Byla vybrána čáska " + castka;
            }

            return "Částka v seznamu není";
        }
    }
}
