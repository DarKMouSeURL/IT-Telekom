﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3Cb_uzivRozhrani
{
    static class UzivRozhrani
    {
        public static void Run()
        {
            Console.WriteLine("--- Vítejte v Programu ---");
            string prikaz = "";
            do
            {
                Console.Write("\r\nCommand: ");
                prikaz = Console.ReadLine().Trim().ToUpper();
                RozcestnikPrikazu(prikaz);

            } while (!prikaz.Equals("EXIT"));
        }

        private static void RozcestnikPrikazu(string prikaz)
        {
            switch (prikaz)
            {
                case "VYBER": VYBERCommand(); break;
                case "VLOZ": VLOZCommand(); break;
                case "EXIT": Console.WriteLine("Program bude nyní ukončen"); break;
                default: Console.WriteLine("Příkaz neexistuje"); break;
            }
        }

        private static void VYBERCommand()
        {
            Console.WriteLine("Metoda vybírá částku ze seznamu");
            try
            {
                //vstup
                Console.Write("Zadej částku: ");
                double castka = double.Parse(Console.ReadLine());
                //výstup
                Console.WriteLine(Data.Vyber(castka));
            }
            catch (Exception e)
            {
                Console.WriteLine("Chyba v částce: " + e.Message);
            }

        }

        private static void VLOZCommand()
        {
            Console.WriteLine("Metoda vkládá novou částku do seznamu");
            try
            {
                //vstup
                Console.Write("Zadej částku: ");
                double castka = double.Parse(Console.ReadLine());
                //výstup
                Console.WriteLine(Data.Vloz(castka));
            }
            catch (Exception e)
            {
                Console.WriteLine("Chyba v částce: "+e.Message);
            }
        }
    }
    }
