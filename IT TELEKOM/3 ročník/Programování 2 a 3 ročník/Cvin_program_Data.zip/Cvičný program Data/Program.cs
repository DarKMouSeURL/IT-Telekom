﻿// See https://aka.ms/new-console-template for more information
using _3Cb_uzivRozhrani;

UzivRozhrani.Run();
