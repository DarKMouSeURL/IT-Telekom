﻿namespace ConsoleApp7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*
            int[] nasobilka = new int[10];
            for (int i = 0; i < nasobilka.Length; i++)
            {
                nasobilka[i] = i * 5;
                nasobilka[0] = 0;
                nasobilka[nasobilka.Length - 1] = 0;
                if (nasobilka[i] % 2 == 0)
                {
                    Console.Write(nasobilka[i] + " ");
                }
            }
            Console.WriteLine("");

            int[] merak = new int[60];
            Random rnd = new Random();            

            for (int i = 0; i < merak.Length; i++)
            {
                int num = rnd.Next(-100, 100);
                merak[i] = num;
                Console.Write(merak[i] + ", ");
            }
            Console.WriteLine();
            Console.WriteLine("Prvni hodnota " + merak[0]);
            Console.WriteLine("Posledni hodnota " + merak[merak.Length - 1]);
            */

//1.Vytvořte seznam celých čísel s názvem cisla a uložte do něho na začátku hodnoty 10,18,15,-5

//2.Do tohoto seznamu nalosujte navíc dalších 100 čísel od -20 do 20

//3.Vytvořte samostatnou metodu VypisSeznam – pro výpis položek seznamu vedle sebe

//4.Poslední prvek nahraďte(přepište) číslem 20

//5.Na konec seznamu přidejte prvek -20

//6.První prvek nahraďte(přepište) číslem 20

//7.Na začátek seznamu přidejte prvek -20

//8.Vymažte první výskyt čísla 20 ze seznamu

//9.Vymažte všechny výskyty čísla 0 ze seznamu

//10.Vymažte všechny výskyty záporných dvouciferných čísel
//Pozor, prvky se postupně umazávají a hodnoty na indexech se posouvají!

//11.Vymažte prvek, který je aktuálně na indexu č. 4

//12.Prohoďte mezi sebou první 2 prvky seznamu(použijte pomocnou proměnnou pom)

//13.Prohoďte mezi sebou první 2 prvky seznamu(použijte již hotové metody indexovaného seznamu)

//14.Prvek z indexu 3 přemístěte na konec seznamu

//15.Předposlední prvek seznamu přemístěte na začátek seznamu

//16.Vymažte každý 5.prvek(počínaje prvkem na indexu 4) Pozor, prvky se postupně umazávají a hodnoty na indexech se posouvají!

//17.Vypište číslo indexu, na kterém leží 1.hodnota 10, pokud v seznamu hodnota není, napište NENALEZENO

//18.Vypište aritmetický průměr hodnot v seznamu - na 3 desetinná místa

//19.Vypište , kolik hodnot v poli je nezáporných
//20.Vytvořte pole s názvem cisla2 a uložte do něj hodnoty ze seznamu cisla
            
            List<int> cisla = new List<int>() {10,18,15,-5};
            Random nahoda = new Random();
            for (int i = 0; i < 100; i++)
            {
                int number = nahoda.Next(-20,20);
                cisla.Add(number);
            }

            cisla[cisla.Count - 1] = 20;
            cisla.Add(-20);
            cisla[0] = 20;
            cisla.Insert(0, -20);
            cisla.Remove(20);
            while (cisla.Contains(0))
                cisla.Remove(0);
            for (int i = 0; i < cisla.Count; i++)
            {
                if (cisla[i] < -9)
                {
                    cisla.RemoveAt(i);
                    i--;
                }
                
            }
            cisla.RemoveAt(4);
            
            int pom = cisla[0];
            cisla[0] = cisla[1];
            cisla[1] = pom;

            cisla.Insert(0, cisla[1]);
            cisla.RemoveAt(2);
            VypisSeznam(cisla);
            Console.WriteLine();

            cisla.Append(cisla[2]);
            cisla.RemoveAt(2);

            cisla.Insert(0,cisla[cisla.Count - 2]);
            cisla.RemoveAt(cisla.Count-2);

            for (int i = 4; i < cisla.Count; i+=5)
            {
                cisla.RemoveAt(i);
                i--;
            }
            if (cisla.IndexOf(10) == -1)
                Console.WriteLine("nenalezeno");
            else
                Console.WriteLine("index hodnoty 10: "+cisla.IndexOf(10));

            Console.WriteLine(Math.Round(cisla.Average(),3));

            int za = 0;
            for (int i = 0; i < cisla.Count; i++)
            {
                if (!(cisla[i]<=0))
                {
                    int za = 
                }

            }
            VypisSeznam(cisla);
        }
        static void VypisSeznam(List<int> seznam)
        {
            foreach (int cislo in seznam)
                Console.Write(cislo + ", ");            
        }
    }
}