﻿namespace ConsoleApp1samostatne
{
    internal class Program
    {
        static void Main()
        {
            Console.WriteLine("Hello, World!");

            //for (int i=0; i<5; i=i+1)
            //for (int i = 0; i < 5; )
            //for (; ; )
            //for (int i = 0; i < 7; i = i + 1)
            //for (int i = -2; i < 7; i = i + 1)
            //for (int i = -2; i < 7; i = i + 3)
            //for (int i = -2; i < 7; i++)
            //for (int i = -2; i < 7; ++i)
            for (int i = -2; i < 7; i+=1)
            {
                Console.WriteLine($"{i} - je parametr cyklu");
                //Console.WriteLine($"nekonecny cyklus");
                Console.WriteLine("-----------");
            }
            Console.WriteLine("----------------------");

            //operatory aritmeticke  + - * / 
            int konstanta = 100;
            for(int cislo = 1; cislo < 11; cislo++)
            {
                int soucet = konstanta + cislo;
                Console.WriteLine($"{konstanta} + {cislo} = {soucet}");

                int rozdil = konstanta - cislo;
                Console.WriteLine($"{konstanta} - {cislo} = {rozdil}");

                int soucin = konstanta * cislo;
                Console.WriteLine($"{konstanta} * {cislo} = {soucin}");

                int podil = konstanta / cislo;
                Console.WriteLine($"{konstanta} / {cislo} = {podil}");


                Console.WriteLine("---");
            }
            Console.ReadLine();

        }
    }
}
