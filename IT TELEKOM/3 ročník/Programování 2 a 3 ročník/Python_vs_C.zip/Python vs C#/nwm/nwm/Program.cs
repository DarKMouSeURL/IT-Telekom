﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace nwm
{
    internal class Program
    {
        static void Main(string[] args)
        {
                                                pozdravit("dobry", "den");
          pozdravit("obry", "en");
            if (true)
            {
                pozdravit("dobry", "den");
            }
            else
            {
                pozdravit("f", "g");
            }
            int i = 0;
            while (i < 5)
            {
                Console.WriteLine(i);
                pozdravit("D", "s");
                i += 1;
            }
        }
        static void pozdravit(string slovo1, string slovo2)
        {
                   Console.WriteLine("*****************************************");
                           Console.WriteLine("*                                       *");
       Console.WriteLine("*      " + slovo1 +" "+ slovo2  +"           *");
   Console.WriteLine("*                                       *");
                                                                                                                                                                                                                                                  Console.WriteLine("*****************************************");
        }
    }
}
