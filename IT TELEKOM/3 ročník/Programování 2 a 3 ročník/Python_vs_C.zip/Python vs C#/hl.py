def pozdravit(slovo1, slovo2):
    print("*****************************************")
    print("*                                       *")
    print(f"*             {slovo1}    {slovo2}              *")
    print("*                                       *")
    print("*****************************************")

pozdravit("dobry", "den")

