﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsAppkostka
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void panel1_Click(object sender, EventArgs e)
        {
            /*
            button1.Visible = false;
            button2.Visible = false;
            button3.Visible = false;
            button4.Visible = false;
            button5.Visible = false;
            button6.Visible = false;
            button7.Visible = false;
            */
            //int hod = 6;
            Smazat();
            Random lz = new Random();
            int hod = lz.Next(6) + 1;
            Zobbrazit(hod);
        }

        private void Smazat()
        {
            button1.Visible = false;
            button2.Visible = false;
            button3.Visible = false;
            button4.Visible = false;
            button5.Visible = false;
            button6.Visible = false;
            button7.Visible = false;

        }

        private void Zobbrazit(int hod)
        {
            if (hod == 1)
            {
                button7.Visible = true;
            }
            if (hod == 2)
            {
                button1.Visible = true;
                button6.Visible = true;
            }
            if (hod == 3)
            {
                button1.Visible = true;
                button6.Visible = true;
                button7.Visible = true;
            }
            if (hod == 4)
            {
                button1.Visible = true;
                button6.Visible = true;
                button3.Visible = true;
                button4.Visible = true;
            }
            if (hod == 5)
            {
                button1.Visible = true;
                button6.Visible = true;
                button3.Visible = true;
                button4.Visible = true;
                button7.Visible = true;
            }
            if (hod == 6)
            {
                button1.Visible = true;
                button6.Visible = true;
                button3.Visible = true;
                button4.Visible = true;
                button2.Visible = true;
                button5.Visible = true;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Smazat();
            Random lz = new Random();
            int hod = lz.Next(6) + 1;
            int hod2 = lz.Next(6) + 1;
            textBox1.Text = hod2.ToString();
            Zobbrazit(hod);

            if (hod == hod2)
            {
                this.BackColor = Color.RoyalBlue;
            }
            else
            {
                this.BackColor = Color.MistyRose;
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;

        }
    }
}