﻿namespace ConsoleApp1
{
    internal class Program
    { 
        static void Main()
        {
            //print("Hello, World!")
            Console.WriteLine("Hello, World!");
            /*
            # sekvence prikazu
            x = 10
            y = 20
            z = x + y
            print(z)
            */
            Sekvence();
            Sekvence();
            //cislo1 = int(input("zadej cislo1="))
            //print(f"Bylo zadano cislo {cislo1}")
            Console.Write("Zadej cislo1=");
            string cislo1Str = Console.ReadLine();
            int cislo1 = Convert.ToInt32(cislo1Str);
            Console.WriteLine($"Je zadano: {cislo1}");
            Sekvence(cislo1);
            //zadat cislo2....
            Console.Write("Zadej cislo2=");
            string cislo2Str = Console.ReadLine();
            int cislo2 = Convert.ToInt32(cislo2Str);
            //a zavolat Sekcence(cislo1, cislo2);
            Sekvence(cislo1, cislo2);

            Console.WriteLine("Stiskni Enter...");
            Console.ReadLine();
        }
        static void Sekvence()
        {
            Console.WriteLine("Funkce=Metoda Sekvence()");
            int x = 10;
            int y = 20;
            int z = x + y;
            Console.WriteLine(z);
            //print(f"{x} + {y} = {z}")
            Console.WriteLine($"{x} + {y} = {z}");
            z = x - y;
            Console.WriteLine($"{x} - {y} = {z}");
            z = x * y;
            Console.WriteLine($"{x} * {y} = {z}");
            z = x / y;
            Console.WriteLine($"{x} / {y} = {z}");
            Console.WriteLine("---------------");
        }
        static void Sekvence(int cislo)   //pretizena metoda,   overload method
        {
            Console.WriteLine("Funkce=Metoda Sekvence(int cislo)");
            int x = 10;
            //int y = 20;
            int z = x + cislo;
            Console.WriteLine(z);
            Console.WriteLine($"{x} + {cislo} = {z}");
            z = x - cislo;
            Console.WriteLine($"{x} - {cislo} = {z}");
            z = x * cislo;
            Console.WriteLine($"{x} * {cislo} = {z}");
            z = x / cislo;
            Console.WriteLine($"{x} / {cislo} = {z}");
            Console.WriteLine("---------------");
        }
        static void Sekvence(int cislo, int x)   //pretizena metoda,   overload method
        {
            Console.WriteLine("Funkce=Metoda Sekvence(int cislo, int x)");
            //int x = 10;
            //int y = 20;
            int z = x + cislo;
            Console.WriteLine(z);
            Console.WriteLine($"{x} + {cislo} = {z}");
            z = x - cislo;
            Console.WriteLine($"{x} - {cislo} = {z}");
            z = x * cislo;
            Console.WriteLine($"{x} * {cislo} = {z}");
            z = x / cislo;
            Console.WriteLine($"{x} / {cislo} = {z}");
            Console.WriteLine("---------------");
        }
    }
}
