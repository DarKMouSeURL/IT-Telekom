﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Windowsudalosti
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_MouseEnter(object sender, EventArgs e)
        {
            this.BackColor = Color.Red;
            this.Text = "nastala udalost";
        }
        private void Form1_MouseLeave(object sender, EventArgs e)
        {
            this.BackColor = Color.RoyalBlue;
            this.Text = "nastala jina udalost";
        }
        private void button_Click(object sender, EventArgs e)
        {
            MessageBox.Show("kliknul jsi na tlacitko", "mimoradna zprava");
        }
        private void button_MouseEnter(object sender, EventArgs e)
        {
            this.BackColor = Color.Red;
            this.Text = "nastala udalost";

        }
        private void button_TextChanged(object sender, EventArgs e)
        {
            button.BackColor = Color.Gold;
            this.Text = "nastalo text change";
        }
        private void button2_MouseEnter(object sender, EventArgs e)
        {
            button2.BackColor = Color.Fuchsia;
            MessageBox.Show("mouse enter");
            button.Text = "zmena textu buttonu, aktivace text change";
        }
        private int pocet = 0;
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            pocet = pocet + 1;
            //MessageBox.Show("udalost text change");
            this.Text = pocet.ToString();
            label1.Text = pocet.ToString();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            //MessageBox.Show("stopka");
            label1.Text = this.pocet.ToString();
        }

        private void label1_MouseEnter(object sender, EventArgs e)
        {
        }

        private void label1_MouseClick(object sender, MouseEventArgs e)
        {
            this.pocet = 0;
            label1.Text = this.pocet.ToString();

        }
    }
}
