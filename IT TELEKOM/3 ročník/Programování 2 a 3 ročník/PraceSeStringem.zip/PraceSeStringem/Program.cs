﻿// See https://aka.ms/new-console-template for more information
using _3Cb_praceSeStringem;

Console.WriteLine(UpravaTextu.OdstranMezery("Ahoj, 123, :-), jak se máš? "));
Console.WriteLine(UpravaTextu.OdstranSamohlasky("Ahoj, 123, :-), jak se máš? "));

Console.WriteLine(UpravaTextu.VratVysekTextu("Ahoj, 123, :-), jak se máš? ",1,4));
Console.WriteLine(UpravaTextu.OverPalindrom("Jelenovi pivo nelej"));
Console.WriteLine(UpravaTextu.GenerujHeslo(10, true, true));


