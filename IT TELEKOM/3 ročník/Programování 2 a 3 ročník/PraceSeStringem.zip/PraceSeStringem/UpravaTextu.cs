﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3Cb_praceSeStringem
{
    static class UpravaTextu
    {
        public static string OdstranMezery(string text)
        {
            StringBuilder sb = new StringBuilder();
            foreach (char znak in text)
            {
                if (znak != ' ')
                    sb.Append(znak);   
            }
            return sb.ToString();
        }

        public static string OdstranSamohlasky(string text)
        {
            const string SAMOHLASKY = "aeiouAEIOU";

            StringBuilder sb = new StringBuilder();
            foreach (char znak in text)
            {
                if (!SAMOHLASKY.Contains(znak)) //je pravda, že se v řetězci SAMOHLASKY tento znak nevyskytuje?
                    sb.Append(znak);
            }
            return sb.ToString();
        }

        public static string VratVysekTextu(string text, int _od, int _do)
        {
            return text.Substring(_od - 1, _do); //uživatel počítá od 1, proto musí u _od dát -1
                                                  //k druhé mezi musím myslet na přidání +1, tedy 
                                                  //-1 + 1 -> proměnnou _do neměním
        }

        public static bool OverPalindrom(string text)
        {
            text = OdstranMezery(text).ToLower();

            char[] charArray = text.ToCharArray();
            Array.Reverse(charArray);
            string text2 = new string(charArray);
          
            if (text.Equals(text2))
                return true;

            return false;           
        }

        public static string GenerujHeslo(int pocetZnaku, bool specZnaky, bool cisla)
        {
            Random nahoda = new Random();
            StringBuilder sb = new StringBuilder();

            do
            {
                int gCislo = nahoda.Next(0,128);

                if (('a' <= gCislo && gCislo <= 'z') || ('A' <= gCislo && gCislo <= 'Z'))
                    sb.Append((char)gCislo);

                if (cisla)
                    if ('1' <= gCislo && gCislo <= '9')
                        sb.Append((char)gCislo);

                if (specZnaky)
                    if ((33 <= gCislo && gCislo <= 47) || (91 <= gCislo && gCislo <= 96) || (124 <= gCislo && gCislo <= 126))
                        sb.Append((char)gCislo);

            } while (sb.Length != pocetZnaku);

            return sb.ToString();
        }


        public static string PrevedNaVelkaPismena(string text)
        {
            return text.ToUpper();
        }

        
    }
}
