﻿namespace trojuhlenik
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int a = 3;
            int b = 4;
            int c = 5;

            if (a + b > c && b + c > a && c + a > b)
            {
                Console.WriteLine("True");
                if (a == b && b == c)
                    Console.WriteLine("Rovnostrany");
                else if ((a != b || b != c || a != c) && (a == b || b == c || a == c))
                {
                    Console.WriteLine("Rovnoramenny");
                    if (((a * a + b * b )== c * c) || ((a * a + c * c )== b * b) || ((c * c + b * b )== a * a))
                        Console.WriteLine("Pravouhly");
                }
                else
                    Console.WriteLine("obecny");
                    if (((a * a + b * b) == c * c) || ((a * a + c * c) == b * b) || ((c * c + b * b) == a * a))

            }
            else
                Console.WriteLine("Co to je za trojuhelnik!?");
        }
    }
}