﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace nwm2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("aaa");
            int m =Vynasobit(100, 5);
            Console.WriteLine(m);
            Console.WriteLine(Vydelit(9,5));
        }
        /*
        def vynasobit(a, b):
            soucin = a* b
            return soucin
        */
        static int Vynasobit(int a, int b)
        {
            int soucin = a * b;
            return soucin;
        }
        static double Vydelit(double aa, double bb)
        {
            double podil = aa / bb;
            return podil;
        }

    }
}
