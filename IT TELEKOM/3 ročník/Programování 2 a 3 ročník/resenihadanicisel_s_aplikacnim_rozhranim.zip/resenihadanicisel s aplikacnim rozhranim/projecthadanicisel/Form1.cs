﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projecthadanicisel
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Red;
            this.Text = "pokuse";
            textBox1.Text = "heheha";
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            this.BackColor = button2.BackColor ;
            textBox1.Text = "huaaagh";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int cislotajne = new Random().Next(1,48);
            textBox1.Text = cislotajne.ToString();
        }
    }
}
