﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pretypovani
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool alfa = false;

            //cislo = -9000000000;

            //string x = (int)cislo;

            string hodnota = "2,15";

            double y = Convert.ToDouble(hodnota);

            char z = 'i';

            int zz = z;
            
            int vek = 0;

            float vzorek = 2.22f;

            int zkracenyvzorek = 
        }
    }
}
