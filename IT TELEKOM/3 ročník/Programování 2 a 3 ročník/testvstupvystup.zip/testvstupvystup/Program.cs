﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //př 1.
            Double cena = 50;
            int pocet_ks = 7;
            Console.WriteLine($"Cena celkem za {pocet_ks}\n{cena * pocet_ks}");

            //př. 2
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.Write("Nákup:");
            Console.ResetColor();
            Console.WriteLine("\tmléko\n\tMáslo\n\tRýže");

            //př. 3
            Console.Write(@"Termín ""verbum"" znaméná ");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("sloveso");
            Console.ResetColor();
        }
    }
}
