﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace oop__neco
{
    internal class Auto
    {
        public string znacka = "";
        public int najetoKm = 0;
        public int rokVyroby = DateTime.Now.Year;
        public DateTime? datumTK = null;

        public Auto(string znacka, int najetoKm, int rokVyroby, DateTime datumTK)
        { 
            this.datumTK = datumTK;
            this.rokVyroby = rokVyroby;
            this.znacka = znacka;
            this.najetoKm = najetoKm;
        }
        public Auto(string znacka)
        {
            this.znacka = znacka;
        }

        public override string ToString()
        {
            return string.Format($"znacka: {znacka}, najeto {najetoKm} Km, rok vyroby {rokVyroby}, Datum TK {datumTK}");
        }
        public string VypisInfo()
        {
            Console.WriteLine($"znacka: {znacka}, najeto {najetoKm} Km.");
            return null;
            //nepouzivat
        }
        public string VratInfo()
        {
            return string.Format($"znacka: {znacka}, najeto {najetoKm} Km.");
        }
    }
}
