﻿namespace oop__neco
{
    internal class Program
    {
        static void Main(string[] args)
        {
            DateTime datumCas = new DateTime(2016, 7, 15);
            Auto a = new Auto("mercedes", 125, 2005, datumCas);
            Console.WriteLine(a.ToString());

            a.VypisInfo(); //nepouzivat

            Console.WriteLine(a.VratInfo());

        }
    }
}