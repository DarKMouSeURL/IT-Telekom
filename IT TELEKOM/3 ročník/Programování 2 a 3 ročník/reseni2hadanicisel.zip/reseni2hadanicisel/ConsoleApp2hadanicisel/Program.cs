﻿using System;

internal class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("hra hadani cisel");
        Console.WriteLine("zadej cislo od 0 do 19: ");

        //int cislotajne = 12;

        int cislotajne = new Random().Next(20);   //od 0 do 19
        Console.WriteLine(cislotajne);
        Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");


        while (true)
        {
            Console.WriteLine();

            Console.Write("zadej cislo od 0 do 19: ");

            string klavesnice = Console.ReadLine();
            int cislozadane = Convert.ToInt32(klavesnice);

            if (cislotajne == cislozadane)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.BackgroundColor = ConsoleColor.DarkMagenta;

                Console.WriteLine("Vyhral jsi! Frajer");

                Console.ForegroundColor = ConsoleColor.Gray;
                Console.BackgroundColor = ConsoleColor.Black;
                //Console.Beep(440, 1000); //440 komorni a
                //Console.Beep(100, 1000);
                Pipnoutvyhra();
                break;
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.BackgroundColor = ConsoleColor.Yellow;

                Console.WriteLine("Prohral jsi! Zkus znova");

                Console.ForegroundColor = ConsoleColor.Gray;
                Console.BackgroundColor = ConsoleColor.Black;
                if (cislotajne > cislozadane)
                {
                    Console.WriteLine("More pridaj");
                }
                else
                {
                    Console.WriteLine("To je zas moc");
                }
                Pipnoutprohra();    
            }
        }
        Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");

        Console.WriteLine();
        Console.WriteLine("Zkus znova - stikni enter");
        Console.ReadLine();
    }

    static void Pipnoutvyhra()
    {
        Console.Beep(500, 100);
        Console.Beep(600, 200);
        Console.Beep(700, 300);
        Console.Beep(800, 400);
        Console.Beep(900, 500);
        Console.Beep(1000, 600);
        Console.Beep(1100, 700);
        Console.Beep(1200, 800);
        Console.Beep(1300, 900);
        Console.Beep(1400, 1000);
        Console.Beep(1700, 1100);
    }


    static void Pipnoutprohra()
    {
    Console.Beep(1000, 200);
    Console.Beep(800, 200);
    System.Threading.Thread.Sleep(1000); //uspat program 1s.
    Console.Beep(600, 200);
    Console.Beep(400, 200);
    Console.Beep(200, 400);
    }

}