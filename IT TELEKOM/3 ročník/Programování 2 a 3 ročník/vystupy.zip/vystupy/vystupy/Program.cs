﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace vystupy
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Alfa\tBeta\nGama\tDelta");

            double vaha = 20;
            Console.WriteLine($"Váha: {vaha} Kg");

            string titul = "Mgr.";
            string jmeno = "Petr";
            string prijmeni = "Matějka";
            byte vek = 18;
            Console.WriteLine($"Jméno:\t{titul} {jmeno} {prijmeni}\nVěk:\t{vek} let");

            Console.WriteLine(@"Na tabuli stála věta: ""Zpětné lomítko \ Lze zapsat pomocí Alt + Q""");

            Console.BackgroundColor = ConsoleColor.Red;
            Console.Write("R");
            Console.BackgroundColor = ConsoleColor.Green;
            Console.Write("G");
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.WriteLine("B");
            Console.ResetColor();

            Console.Write(@"Ve slově """);
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("Algoritmus");
            Console.ResetColor();
            Console.Write(@""" se píše ");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("měkké í");
            Console.ResetColor();
            Console.WriteLine("!");

            Console.WriteLine("prirad x(pis des. carku ,): ");
            double x = double.Parse(Console.ReadLine());
            double y = 5 * x + 3;
            Console.WriteLine(y);

            int a = 5;
            int b = 10;
            int pom = a;
            a = b;
            b = pom;
        }
    }
}
