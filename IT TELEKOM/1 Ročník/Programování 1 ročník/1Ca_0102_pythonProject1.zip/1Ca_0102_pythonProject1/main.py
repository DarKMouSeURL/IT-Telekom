print("dobry den")
print("druhy radek")
import turtle
turtle.shape("turtle")
turtle.forward(300)
#turtle.left(90)
turtle.right(135)
turtle.forward(100)



input()
