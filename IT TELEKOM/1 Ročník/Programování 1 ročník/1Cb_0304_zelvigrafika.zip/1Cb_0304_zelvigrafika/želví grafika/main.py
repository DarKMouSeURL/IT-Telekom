import turtle

def promZelva():
    #turtle.shape("turtle")
    turtle.forward(200)
    turtle.left(90)
    turtle.hideturtle()
    turtle.forward(100)
    #turtle.color("purple")
    turtle.pencolor("red")
    turtle.penup()
    turtle.goto(-30, 50)
    turtle.showturtle()
    turtle.pendown()
    turtle.forward(300)
    turtle.left(90)
    turtle.speed(1)
    turtle.forward(300)
    turtle.width(10)
    turtle.back(300)
    turtle.clear()

promZelva()   #volani program zelva == spusteno


input()