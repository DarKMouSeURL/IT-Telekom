import turtle

def programZelva():
    turtle.shape("turtle")
    #turtle.shape("square")
    #turtle.shape("circle")
    turtle.forward(200)
    turtle.left(90)
    turtle.ht()
    turtle.forward(100)
    turtle.penup()
    turtle.goto(-30, 50)
    turtle.showturtle()
    turtle.pendown()
    turtle.speed(1)       #1 nejpomaleji
    turtle.forward(300)
    #turtle.color("red")
    turtle.pencolor("red")
    turtle.left(90)
    turtle.forward(150)
    turtle.width(10)
    turtle.back(300)
    turtle.clear()




programZelva()   #volani programZelva tj. spusteni

input()