"""
def odecist(x,y):
    rozdil = x-y
    return rozdil
"""
