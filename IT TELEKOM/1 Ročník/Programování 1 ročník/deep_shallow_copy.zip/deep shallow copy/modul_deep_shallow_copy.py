import matika
"""
for c in range(2):
    x=int(input("zadej x: "))
    y=int(input("zadej y: "))
    print(f"{x} - {y} = {matika.odecist(x,y)}")

cislo1 = 123
cislo2 = 222

if cislo1 != cislo2:
    print("cislo1 je mensi rovno nez cislo2")
else:
    print("NENI PRAVDA ZE cislo1 je mensi rovno nez cislo2")
"""
s1=[]
import random
for r in range(12):
    x=random.randint(1,1000)
    print(f"Nahodne cislo je {x}.")
    s1.append(x)
for t in range(12):
    print(s1[t])
#shallow copy
"""
s2=[]
s2.append(s1)
print(s2)
"""
#deep copy
s2=[]
for n in range(12):
    s2.append(s1[n])
print(s2)
s3=["ne", "mozna", "hahaha", "56545", "bit", "pneumonoultramicroscopicsilicovolcanoconiosis"]
s3.append("naIndex5")
jmeno=input("jmeno: ")
s3.append(jmeno)
len(s3)
for e in range(len(s3)):
    print(s3[e])
