﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3Cb_Accounts
{
    static class Storage
    {
        //statický seznam pro ukládání objektů typu User
        static List<User> accounts = new List<User>();

        //metoda pro přidání Usera do seznamu (2parametrická)
        static public void AddAccount(string name, string password)
        {
            if (!AccountExist(name))
                accounts.Add(new User(name, password));
        }
            //metoda pro přidání admina do seznamu (4parametrická)
            static public void AddAccount(string name, string password, bool webServer, bool postServer)
            {
            if (!AccountExist(name))
            {
                Admin aNew = new Admin(name, password, webServer, postServer);
                accounts.Add(aNew);
            }
            }
            //metoda zjistí, zda už existuje účet stejného jména
            static private bool AccountExist(string name)
            {
                foreach (var x in accounts)
                {
                    if (x.Name.Equals(name))
                        return true;
                }
                return false;
            }
            //vrácení tostingu všech Accaunts ze seznamu (pro potřeby výpisu)
            static public string GetAccounts()           
            {            
                StringBuilder sb = new StringBuilder();
                foreach (var x in accounts)
                    sb.Append(x.ToString() + "\n");
                return sb.ToString();
            }


        static public void ChangeAllUserPasswordToDefault(string defaultPass)
        {
            foreach (var account in accounts)
            {
                if (account is User && !(account is Admin))
                    account.Password = defaultPass;
            }
        }

        static public User? GetAccount(string searchName)
        {
            foreach (var acc in accounts)
            {
                if (acc.Name.Equals(searchName))
                    return acc;
            }
            return null;
        }


    }
}
