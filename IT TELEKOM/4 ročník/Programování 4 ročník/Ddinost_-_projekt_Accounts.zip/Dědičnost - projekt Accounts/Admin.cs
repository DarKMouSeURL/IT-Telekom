﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3Cb_Accounts
{
    internal class Admin:User
    {
        bool webServer;
        bool postServer;

        public Admin(string name, string password, bool webServer, bool postServer)
            : base(name, password)
        {
            this.webServer = webServer;
            this.postServer = postServer;
        }

        public override string ToString()
        {
            return base.ToString() + $"[webServer: {webServer}, postServer: {postServer}]";
        }


    }
}
