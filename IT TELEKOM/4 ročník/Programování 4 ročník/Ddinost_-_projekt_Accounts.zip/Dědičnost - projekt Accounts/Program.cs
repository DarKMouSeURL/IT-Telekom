﻿// See https://aka.ms/new-console-template for more information

using _3Cb_Accounts;

Storage.AddAccount("martin", "123");
Storage.AddAccount("mirek", "321");
Storage.AddAccount("david", "12345", true, true);
Storage.AddAccount("eliska", "54321", false, false);

Console.WriteLine(Storage.GetAccounts());

//Ověřte, že nepůjde vytvořít účet už existujícího jména
Storage.AddAccount("david", "451542456");

//Změň heslo u martin (bude fungovat jen když bude login)
User accAct = Storage.GetAccount("martin");
if (accAct != null)
{
    accAct.LoginAccount("martin", "123");
    accAct.ChangePassword("123", "1234");
    accAct.Logout();
}

//Změň u eliska, aby mohla být postServer (funguje ikdyž není login)
//Vypíšeme, jestli proběhly změny
//Zkusíme hromadně změnit uživatelům heslo na "TelskolTheBestPASSEver"

Console.WriteLine(Storage.GetAccounts());
