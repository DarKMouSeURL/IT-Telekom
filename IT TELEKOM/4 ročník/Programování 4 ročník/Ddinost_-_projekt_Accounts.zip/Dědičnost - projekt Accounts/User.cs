﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3Cb_Accounts
{
    internal class User
    {
        string name;
        string password;
        bool login;

        public string Name { get{return name; } }
        public string Password { set { password = value; } }

        public User(string name, string password)
        {
            this.name = name;
            this.password = password;
            this.login = false;
        }

        public override string ToString()
        {
            return $"{this.GetType().Name} [name: {name}, password: {password}, login: {login}]";
        }

        //Přihlášení
        public bool LoginAccount(string nameInput, string passwordInput)
        {
            if (name.Equals(nameInput) && password.Equals(passwordInput))
            {
                return login = true;
            }
            return false;
        }

        //Odhlášení
        public void Logout()
        {
            login = false;
        }

        //Změna hesla
        public bool ChangePassword(string passwordOld, string passwordNew)
        {
            if (password.Equals(passwordOld) && login)
            {
                password = passwordNew;
                return true;
            }
            return false;
        }



    }
}
