﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2C_knihaMetody
{
    internal class Kniha
    {
        string nazev;
        string autor;
        double cena;
        int pocetSkladem;

        static double dph = 10;

        //1. Vytvořte 4-parametrický konstruktor pro vytvoření nové knihy

        public Kniha(string nazev, string autor, double cena, int pocetSkladem)
        {
            this.nazev = nazev;
            this.autor = autor;
            this.cena = cena;
            this.pocetSkladem = pocetSkladem;
        }


        //2. Metoda upraví základní cenu knihy na polovinu

        public void PolovinaZaklCeny()
        {
            cena = cena / 2;
        }

        //3. Metoda vrátí cenu knihy s DPH

        public double CenasDPH()
        {
            double cenasDph = cena + cena/100*dph;
            Math.Round(cenasDph, 2);
            return cenasDph;
        }

        //4. Metodá VratInfo vrátí informaci o knize ve formě: 
        //"Kniha džunglí (Rudyard Kipling): cena 268 Kč vč. dph"

        public string VratInfo()
        {
            return String.Format($"{nazev} ({autor}): cena {CenasDPH()} Kč vč. dph");
        }


        //5. Metoda vrátí celkovou cenu, kterou zaplatí zákazník za požadovaný počet výtisků knihy

        public double CenaZaPocetKs(int pocet)
        {
            return pocet * CenasDPH();
        }


        //6. Metoda vrátí informaci, kolik ks knih jsme schopni koupit za daný obnos v peněžence
        //Pokud daný počet není skladem, vypíše se pouze množství knih dané skladovými zásobami

        public int KolikKnihKoupim(double maxCastka)
        {
            if (cena == 0)
                return -1;

            int pocet = (int)(maxCastka / CenasDPH()); //celočíselné dělení pomocí přetypování výsledku
                                                       //přetypování odřízne desetinnou část
            if (pocetSkladem >= pocet)
                return pocet;

            return pocetSkladem;
        }


        //7. Metoda vrátí textovou informaci:
        //Skladem
        //Není skladem
        //Poslední 3 kusy (pokud ks na skladě je 5 a méně, napíše danou informaci s číslem)
        public string InfoKs()
        {
            if (pocetSkladem > 5)
                return "Skladem";

            if (pocetSkladem <= 0)
                return "Není skladem";

            string slovo = "kusů";
            switch (pocetSkladem)
            {
                case 5: 
                    slovo = "kusů"; break;
                case 4: 
                case 3: 
                case 2: 
                    slovo = "kusy"; break;
                case 1:
                    slovo = "kus"; break;
            }
            return $"Poslední {pocetSkladem} {slovo} skladem!";

        }

        //8. Metoda přidá daný počet kusů do pocetSkladem
        public void pridejKs(int ks)
        {
            pocetSkladem += ks;
        }


    }
}
