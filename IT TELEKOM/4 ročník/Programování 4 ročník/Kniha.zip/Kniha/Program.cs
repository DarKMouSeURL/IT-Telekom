﻿// See https://aka.ms/new-console-template for more information

using _2C_knihaMetody;

Kniha kn1 = new Kniha("Kniha džunglí", "Rudyard Kipling", 200, 1);
kn1.PolovinaZaklCeny();
Console.WriteLine(kn1.CenasDPH());
Console.WriteLine(kn1.VratInfo());
Console.WriteLine(kn1.CenaZaPocetKs(10));
Console.WriteLine(kn1.KolikKnihKoupim(300));
Console.WriteLine(kn1.InfoKs());
kn1.pridejKs(3);

Kniha kn2 = new Kniha("To", "Stephan King", 890, 7);
Console.WriteLine(kn2.VratInfo());




Console.ReadLine();
