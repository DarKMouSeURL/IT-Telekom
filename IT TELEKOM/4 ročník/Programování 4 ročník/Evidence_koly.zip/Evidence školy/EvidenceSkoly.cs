﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2C_evidSkolyMetody
{
    internal class EvidenceSkoly
    {
        int pocetPed = 25;
        int pocetNeped = 20;
        double mzdaPed = 39000;
        double mzdaNeped = 26000;

        //1.	Metoda změní mzdy pro pedagogické i nepedagogické pracovníky o určitý počet procent
        //(pro každou kategorii můžou být jiná procenta)
        public void ZvysMzdyOProc(double procPed, double procNeped)
        {
            mzdaPed += mzdaPed / 100 * procPed;
            mzdaNeped += mzdaNeped / 100 * procNeped;
        }

        //2.	Metoda spočítá předpokládané měsíční náklady na mzdy pro všechny pracovníky dohromady
        public double MesicniNakladyMzdy()        
        { 
            return  mzdaPed*pocetPed + mzdaNeped * pocetNeped;            
        }

        //3.	Metoda spočítá předpokládané roční náklady na mzdy
        public double RocniNakladyMzdy()
        {
            return MesicniNakladyMzdy() * 12;
        }

        //4.	Metoda na základě zadaného ročního rozpočtu vyhodnotí, zda bude nebo nebude mít škola na platy svých zaměstnanců.
        public bool MamNaPlaty(double rozpocet)
        {
            if (RocniNakladyMzdy() <= rozpocet)
                return true;
            
            return false;
        }

        //5.	Metoda přidá pedagogického pracovníka
        public void PridejPedagoga()
        {
            pocetPed++;
        }

        //6.	Metoda vrátí informace o všech vnitřních proměnných.
        public override string ToString()
        {
            return $"pocetPed: {pocetPed}, pocetNeped: {pocetNeped}, mzdaPed: {mzdaPed} Kč, mzdaNeped: {mzdaNeped} Kč";
        }

    }
}
