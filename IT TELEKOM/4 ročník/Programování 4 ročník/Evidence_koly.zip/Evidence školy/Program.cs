﻿// See https://aka.ms/new-console-template for more information

using _2C_evidSkolyMetody;

EvidenceSkoly es = new EvidenceSkoly();
Console.WriteLine(es);
es.ZvysMzdyOProc(5, 7);
es.PridejPedagoga();
Console.WriteLine(es);
Console.WriteLine($"Měsíční náklady: {es.MesicniNakladyMzdy()} Kč");
Console.WriteLine($"Roční náklady: {es.RocniNakladyMzdy()} Kč");
Console.WriteLine(es.MamNaPlaty(19000000));