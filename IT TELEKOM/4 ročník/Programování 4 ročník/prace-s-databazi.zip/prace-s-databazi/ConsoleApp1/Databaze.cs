﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1{
    internal class Databaze{
        public static void ZapisData(string sqlPrikaz, params SqlParameter[] parametery)
        {
            using (SqlConnection connection = new SqlConnection()) {
                using (SqlCommand command = new SqlCommand()) { 
                    connection.Open();
                    command.CommandText = sqlPrikaz;
                    //command.Parameters = parametery;
                    connection.Close();
                }
            }
        }
        }
    }
}
