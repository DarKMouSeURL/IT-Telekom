﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1{
    internal class Program{
        static void Main(string[] args) {
            int hlid = 3;
            string sqlPrikaz = @"UPDATE Barva SET 
                               Nazev = @nazev, Kod = @kod 
                               WHERE id = @id";

            Databaze.ZapisData(sqlPrikaz, new SqlParameter("@id", hlid), new SqlParameter("@kod", kod),);
            
        }
    }
}
