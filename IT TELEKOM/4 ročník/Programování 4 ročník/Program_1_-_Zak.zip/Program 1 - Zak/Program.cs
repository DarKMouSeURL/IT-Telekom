﻿// See https://aka.ms/new-console-template for more information
using _2CGetSet;

Console.WriteLine("Hello, World!");

Zak z1 = new Zak();

//způsob pomocí metod
z1.SetJmeno("Milan");
Console.WriteLine(z1.GetJmeno());

//způsob pomocí getter a setter
z1.Prijmeni = "Novák";
Console.WriteLine(z1.Prijmeni);

z1.Bydliste = "Novohradská 12, Brno";
Console.WriteLine(z1.Bydliste);