﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2CGetSet
{
    internal class Zak
    {
        string jmeno; //číst, zapisovat

        string prijmeni; //číst, zapisovat
        public string Prijmeni { get { return prijmeni; } set { prijmeni = value; } }

        public string Bydliste { get; set; }

        double prumer; //číst
        public double Prumer {get {return prumer;} }

        string heslo; //nechci číst ani zapisovat - modifikátor přístupu private
                      //je volitelný

         
        public string GetJmeno()
        {
            return jmeno;
        }

        public void SetJmeno(string noveJmeno)
        {
            jmeno = noveJmeno;
        }

    }
}
