﻿namespace WinFormsApp3checksbox
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            checkBox1 = new CheckBox();
            CBjecervena = new CheckBox();
            buttoncervena = new Button();
            buttonzelena = new Button();
            SuspendLayout();
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.BackColor = Color.Yellow;
            checkBox1.Checked = true;
            checkBox1.CheckState = CheckState.Checked;
            checkBox1.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 238);
            checkBox1.Location = new Point(87, 52);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(164, 29);
            checkBox1.TabIndex = 0;
            checkBox1.Text = "Venku je hezky";
            checkBox1.UseVisualStyleBackColor = false;
            checkBox1.CheckedChanged += checkBox1_CheckedChanged;
            // 
            // CBjecervena
            // 
            CBjecervena.AutoSize = true;
            CBjecervena.BackColor = Color.Red;
            CBjecervena.Checked = true;
            CBjecervena.CheckState = CheckState.Checked;
            CBjecervena.Location = new Point(87, 120);
            CBjecervena.Name = "CBjecervena";
            CBjecervena.Size = new Size(88, 19);
            CBjecervena.TabIndex = 1;
            CBjecervena.Text = "sviticervena";
            CBjecervena.UseVisualStyleBackColor = false;
            CBjecervena.CheckedChanged += CBjecervena_CheckedChanged;
            // 
            // buttoncervena
            // 
            buttoncervena.BackColor = Color.Red;
            buttoncervena.Location = new Point(553, 42);
            buttoncervena.Name = "buttoncervena";
            buttoncervena.Size = new Size(100, 100);
            buttoncervena.TabIndex = 2;
            buttoncervena.UseVisualStyleBackColor = false;
            buttoncervena.Click += buttoncervena_Click;
            // 
            // buttonzelena
            // 
            buttonzelena.BackColor = Color.Black;
            buttonzelena.Location = new Point(553, 148);
            buttonzelena.Name = "buttonzelena";
            buttonzelena.Size = new Size(100, 100);
            buttonzelena.TabIndex = 3;
            buttonzelena.UseVisualStyleBackColor = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(buttonzelena);
            Controls.Add(buttoncervena);
            Controls.Add(CBjecervena);
            Controls.Add(checkBox1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private CheckBox checkBox1;
        private CheckBox CBjecervena;
        private Button buttoncervena;
        private Button buttonzelena;
    }
}
