namespace WinFormsApp3checksbox
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.checkBox1.BackColor = Color.LightBlue;
            this.checkBox1.Text = "Neslysl";
            //this.checkBox1.Checked = false;
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            //if (checkBox1.Checked == true)
            if (checkBox1.Checked)
            {
                checkBox1.Text = "venku je hezky";
                MessageBox.Show("Je pravda ze je venku hezky");
            }
            else
            {
                checkBox1.Text = "venku neni hezky";
                MessageBox.Show("Neni pravda ze je venku hezky");

            }
        }

        private void CBjecervena_CheckedChanged(object sender, EventArgs e)
        {
            if (CBjecervena.Checked)
            {
                //checked == true;
                this.CBjecervena.Text = "sviti cervena";
                this.CBjecervena.BackColor = Color.Red;

                this.buttonzelena.BackColor = Color.Black;
                this.buttoncervena.BackColor = Color.Red;
            }
            else
            {
                this.CBjecervena.Text = "neni pravda ze sviti cervene";
                this.CBjecervena.BackColor = Color.Lime;

                this.buttonzelena.BackColor = Color.Lime;
                this.buttoncervena.BackColor = Color.Black;
            }

        }

        private void buttoncervena_Click(object sender, EventArgs e)
        {

        }
    }
}
