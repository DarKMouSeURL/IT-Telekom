namespace WinFormsApp3_checkBox
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.checkBox1.BackColor = Color.LightBlue;
            this.checkBox1.Text = "Nesmysl";
            this.checkBox1.Checked = false;
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                checkBox1.Text = "Venku je hezky";
                MessageBox.Show("Je pravda, ze je venku hezky");
            }
            else
            {
                checkBox1.Text = "Venku neni hezky";
                MessageBox.Show("Neni pravda, ze je venku hezky");
            }
        }

        private void cbJeCervena_CheckedChanged(object sender, EventArgs e)
        {
            if (cbJeCervena.Checked)
            {
                //checked == true
                this.cbJeCervena.Text = "Sviti cervena";
                this.cbJeCervena.BackColor = Color.Red;

                this.btnZelena.BackColor = Color.Black;
                this.btnCervena.BackColor = Color.Red;

            }
            else
            {
                //checked == false
                this.cbJeCervena.Text = "Neni pravda, ze neni cervena";
                this.cbJeCervena.BackColor = Color.Lime;

                this.btnZelena.BackColor = Color.Lime;
                this.btnCervena.BackColor = Color.Black;

            }
        }
    }
}
