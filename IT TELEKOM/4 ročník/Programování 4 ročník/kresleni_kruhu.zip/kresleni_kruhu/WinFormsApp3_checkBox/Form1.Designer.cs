﻿namespace WinFormsApp3_checkBox
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            checkBox1 = new CheckBox();
            cbJeCervena = new CheckBox();
            btnCervena = new Button();
            btnZelena = new Button();
            SuspendLayout();
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.BackColor = Color.Yellow;
            checkBox1.Checked = true;
            checkBox1.CheckState = CheckState.Checked;
            checkBox1.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            checkBox1.Location = new Point(71, 67);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(164, 29);
            checkBox1.TabIndex = 0;
            checkBox1.Text = "Venku je hezky";
            checkBox1.UseVisualStyleBackColor = false;
            checkBox1.CheckedChanged += checkBox1_CheckedChanged;
            // 
            // cbJeCervena
            // 
            cbJeCervena.AutoSize = true;
            cbJeCervena.BackColor = Color.Red;
            cbJeCervena.Checked = true;
            cbJeCervena.CheckState = CheckState.Checked;
            cbJeCervena.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            cbJeCervena.Location = new Point(71, 123);
            cbJeCervena.Name = "cbJeCervena";
            cbJeCervena.Size = new Size(144, 29);
            cbJeCervena.TabIndex = 1;
            cbJeCervena.Text = "Sviti cervena";
            cbJeCervena.UseVisualStyleBackColor = false;
            cbJeCervena.CheckedChanged += cbJeCervena_CheckedChanged;
            // 
            // btnCervena
            // 
            btnCervena.BackColor = Color.Red;
            btnCervena.Location = new Point(405, 89);
            btnCervena.Name = "btnCervena";
            btnCervena.Size = new Size(100, 100);
            btnCervena.TabIndex = 2;
            btnCervena.UseVisualStyleBackColor = false;
            // 
            // btnZelena
            // 
            btnZelena.BackColor = Color.Black;
            btnZelena.Location = new Point(405, 195);
            btnZelena.Name = "btnZelena";
            btnZelena.Size = new Size(100, 100);
            btnZelena.TabIndex = 3;
            btnZelena.UseVisualStyleBackColor = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnZelena);
            Controls.Add(btnCervena);
            Controls.Add(cbJeCervena);
            Controls.Add(checkBox1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private CheckBox checkBox1;
        private CheckBox cbJeCervena;
        private Button btnCervena;
        private Button btnZelena;
    }
}
