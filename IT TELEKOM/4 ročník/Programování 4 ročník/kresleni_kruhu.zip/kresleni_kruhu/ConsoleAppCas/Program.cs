﻿namespace ConsoleAppCas
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hodiny, minuty, sekundy...");

            for (int i = 0; i < 3; i++)
            {       
                //vstupy
                int cas = 0;
                do {
                    Console.Write("Zadej cas ve vterinach: ");
                    cas = Convert.ToInt32(Console.ReadLine());
                } while (cas < 0);

                //zpracovani
                int hod = cas / 3600;
                int zbytek = cas % 3600;
                int min = zbytek / 60;
                int sec = zbytek % 60;

                //vystupy
                Console.WriteLine($"hodin={hod} minut={min} sekund={sec}");
            }

            Console.WriteLine("Konec programu");
        }
    }
}
