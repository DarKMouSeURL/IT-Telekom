using static System.Windows.Forms.AxHost;

namespace WinFormsAppTridaKruh
{
    public partial class Form1 : Form
    {
        //datove slozky tj. clenske promenne
        private Kruh kruh1 = null;
        private Kruh kruh2 = null;
        private Kruh kruh3 = null;

        //konstruktor
        public Form1()
        {
            InitializeComponent();
        }

        //metody
        private void btnKruh1_Click(object sender, EventArgs e)
        {
            this.kruh1 = new Kruh();
            this.panel1.Refresh();
        }
        private void btnKruh2_Click(object sender, EventArgs e)
        {
            this.kruh2 = new Kruh();
            this.panel1.Refresh();
        }
        private void btnKruh3_Click(object sender, EventArgs e)
        {
            this.kruh3 = new Kruh();
            this.panel1.Refresh();
        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            if (this.kruh1 != null)
            {
                //this.kruh1.NakreslitSe(e.Graphics);
                if (this.checkBox1.Checked)
                    this.kruh1.NakreslitObvod(e.Graphics);
                else
                    this.kruh1.NakreslitObsah(e.Graphics);
            }
            if (this.kruh2 != null)
            {
                if (this.checkBox1.Checked)
                    this.kruh2.NakreslitObvod(e.Graphics);
                else
                    this.kruh2.NakreslitObsah(e.Graphics);
            }
            if (this.kruh3 != null)
            {
                if (this.checkBox1.Checked)
                    this.kruh3.NakreslitObvod(e.Graphics);
                else
                    this.kruh3.NakreslitObsah(e.Graphics);
            }
        }
        private void btnXY_Click(object sender, EventArgs e)
        {
            this.kruh1.x = 20;

            this.kruh2.x = 300;
            this.kruh2.y = 350;

            this.panel1.Refresh();
        }
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            //MessageBox.Show("Zmena z true na false...");
            this.panel1.Refresh();
        }
    }

}
