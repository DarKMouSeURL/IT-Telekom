﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsAppTridaKruh
{
    public class Kruh
    {
        //datove slozky tj. clenske promenne
        public int prumer = 150;
        public Color barva = Color.Magenta;
        public int x = 200;
        public int y = 50;
        public static Random lz = new Random();

        //implicitni bezparam. konstruktor

        //metody
        public void NakreslitObsah(Graphics papir)
        {
            int r = Kruh.lz.Next(256);
            int g = Kruh.lz.Next(256);
            int b = Kruh.lz.Next(256);
            Color barva = Color.FromArgb(r, g, b);
            Brush stetec = new SolidBrush(barva);
            //Brush stetec2 = new SolidBrush(this.barva);
            papir.FillEllipse(stetec, this.x, this.y, this.prumer, this.prumer);
        }
        public void NakreslitObvod(Graphics papir)
        {
            int r = Kruh.lz.Next(256);
            int g = Kruh.lz.Next(256);
            int b = Kruh.lz.Next(256);
            Color barva = Color.FromArgb(r, g, b);
            //Pen pero = new Pen(this.barva, 5);
            Pen pero = new Pen(barva, 5);
            //papir.FillEllipse(stetec, this.x, this.y, this.prumer, this.prumer);
            papir.DrawEllipse(pero, this.x, this.y, this.prumer, this.prumer);
        }


    }
}
