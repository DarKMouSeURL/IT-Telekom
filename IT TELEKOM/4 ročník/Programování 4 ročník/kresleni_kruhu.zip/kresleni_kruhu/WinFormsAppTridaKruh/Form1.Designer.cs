﻿namespace WinFormsAppTridaKruh
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            btnKruh1 = new Button();
            btnKruh3 = new Button();
            btnKruh2 = new Button();
            btnXY = new Button();
            checkBox1 = new CheckBox();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(255, 255, 192);
            panel1.Location = new Point(318, 12);
            panel1.Name = "panel1";
            panel1.Size = new Size(646, 457);
            panel1.TabIndex = 0;
            panel1.Paint += panel1_Paint;
            // 
            // btnKruh1
            // 
            btnKruh1.Location = new Point(12, 12);
            btnKruh1.Name = "btnKruh1";
            btnKruh1.Size = new Size(210, 75);
            btnKruh1.TabIndex = 1;
            btnKruh1.Text = "kruh1...";
            btnKruh1.UseVisualStyleBackColor = true;
            btnKruh1.Click += btnKruh1_Click;
            // 
            // btnKruh3
            // 
            btnKruh3.Location = new Point(12, 174);
            btnKruh3.Name = "btnKruh3";
            btnKruh3.Size = new Size(210, 75);
            btnKruh3.TabIndex = 2;
            btnKruh3.Text = "kruh3...";
            btnKruh3.UseVisualStyleBackColor = true;
            btnKruh3.Click += btnKruh3_Click;
            // 
            // btnKruh2
            // 
            btnKruh2.Location = new Point(12, 93);
            btnKruh2.Name = "btnKruh2";
            btnKruh2.Size = new Size(210, 75);
            btnKruh2.TabIndex = 3;
            btnKruh2.Text = "kruh2...";
            btnKruh2.UseVisualStyleBackColor = true;
            btnKruh2.Click += btnKruh2_Click;
            // 
            // btnXY
            // 
            btnXY.Location = new Point(12, 331);
            btnXY.Name = "btnXY";
            btnXY.Size = new Size(210, 114);
            btnXY.TabIndex = 4;
            btnXY.Text = "this.x a this.y";
            btnXY.UseVisualStyleBackColor = true;
            btnXY.Click += btnXY_Click;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Location = new Point(12, 270);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(289, 36);
            checkBox1.TabIndex = 5;
            checkBox1.Text = "chci kreslit obvod kruhu";
            checkBox1.UseVisualStyleBackColor = true;
            checkBox1.CheckedChanged += checkBox1_CheckedChanged;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(976, 481);
            Controls.Add(checkBox1);
            Controls.Add(btnXY);
            Controls.Add(btnKruh2);
            Controls.Add(btnKruh3);
            Controls.Add(btnKruh1);
            Controls.Add(panel1);
            Font = new Font("Segoe UI", 18F);
            Margin = new Padding(6);
            Name = "Form1";
            Text = "Kruznice...";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Button btnKruh1;
        private Button btnKruh3;
        private Button btnKruh2;
        private Button btnXY;
        private CheckBox checkBox1;
    }
}
