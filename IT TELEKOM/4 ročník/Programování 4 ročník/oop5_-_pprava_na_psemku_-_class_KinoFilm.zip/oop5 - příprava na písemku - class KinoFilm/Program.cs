﻿using static System.Net.Mime.MediaTypeNames;
using System;
using System.Security.Cryptography.X509Certificates;
using System.Drawing;

namespace _2C_Auto
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*
            Auto a1 = new Auto("ABC123");
            Console.WriteLine(a1);  //Console.WriteLine(a1.ToString());
            Console.WriteLine(a1.VratInfo());
            //a1.VypisInfo(); - není vhodné používat metodu, co rovnou vypisuje na consoli

            Auto a2 = new Auto("FGH358", 1551, 2003, new DateTime(2023, 5, 20));
            Console.WriteLine(a2);  //Console.WriteLine(a1.ToString());
            Console.WriteLine(a2.VratInfo());
            //a2.VypisInfo();
            */

            List<KinoFilm> filmy = new List<KinoFilm>();
            filmy.Add(new KinoFilm("John Wick", new DateTime(2024, 3, 13, 20, 0,0),false, 199));
            filmy.Add(new KinoFilm("Warcraft 2", true));

            Console.WriteLine("Zadej nový film:");
            try
            {
                Console.Write("\tNázev: ");
                string nazev = Console.ReadLine().Trim();

                Boolean pris = true;
                Console.Write("\tPřístupný (a/n): ");
                if (Console.ReadLine().Trim().ToLower().Equals("n"))
                    pris = false;

                Console.Write("\tCena: ");
                double cena = double.Parse(Console.ReadLine().Trim());

                Console.WriteLine("\tKdy se promítá:");
                Console.Write("\t\tDen: ");
                int den = int.Parse(Console.ReadLine().Trim());
                Console.Write("\t\tMěsíc: ");
                int mesic = int.Parse(Console.ReadLine().Trim());
                Console.Write("\t\tRok: ");
                int rok = int.Parse(Console.ReadLine().Trim());
                Console.Write("\t\tHodiny: ");
                int hod = int.Parse(Console.ReadLine().Trim());
                Console.Write("\t\tMinuty: ");
                int min = int.Parse(Console.ReadLine().Trim());

                DateTime doba = new DateTime(rok, mesic, den, hod, min, 0);

                KinoFilm kf = new KinoFilm(nazev, doba, pris, cena);
                filmy.Add(kf);

            }
            catch (Exception e)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(e.Message);
                Console.ResetColor();            
            }

            //výpis informací
            Console.WriteLine();
            foreach (KinoFilm kf in filmy)
            { 
                Console.WriteLine(kf.ToString());            
            }

            Console.WriteLine();
            foreach (KinoFilm kf in filmy)
            {
                Console.WriteLine(kf.VratInfo());
            }
        }
    }

    class KinoFilm
    {
        string nazev;
        DateTime datumCas;
        bool pristupny = true;
        double cena;
        
        public KinoFilm(string nazev, DateTime datumCas, bool pristupny, double cena)
        {
            this.nazev = nazev;
            this.datumCas = datumCas;
            this.pristupny = pristupny;
            this.cena = cena;
        }

        public KinoFilm(string nazev, bool pristupny)
        {
            this.nazev = nazev;  
            this.pristupny = pristupny;  
        }


        public override string ToString()
        {
            return $"{this.GetType().Name} [nazev: {nazev}, datumCas: {datumCas}, pristupny: {pristupny}, cena: {cena}]";
        }


        public string VratInfo() //vrací něco, musí mít určeno, co opřesně (pomocí return)
        {
            string pristup = "";
            if (!pristupny)
                pristup = "(N)";
            return $"{nazev} {pristup}	...	{datumCas.Day}. {datumCas.Month}.  {datumCas.ToShortTimeString()}	...	cena: {cena} Kč";
        }
    }
}