﻿// See https://aka.ms/new-console-template for more information
using _2C_zavody;

ConsoleInterface.Run();


