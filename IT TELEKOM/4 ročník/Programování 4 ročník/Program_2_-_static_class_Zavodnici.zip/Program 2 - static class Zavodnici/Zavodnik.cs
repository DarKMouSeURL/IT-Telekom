﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2C_zavody
{
    internal class Zavodnik
    {
        string jmeno;
        int cislo;
        char skupina;

        public int Cislo { get { return cislo; } }
        public string Jmeno { get { return jmeno; } }

        public Zavodnik(string jmeno, int cislo, char skupina)
        {
            this.jmeno = jmeno;
            this.cislo = cislo;
            this.skupina = skupina;
        }

        public override string ToString()
        {
            //2 - Petr (sk. A)
            return $"{cislo} - {jmeno}(sk. {skupina})";
        }
    }
}
