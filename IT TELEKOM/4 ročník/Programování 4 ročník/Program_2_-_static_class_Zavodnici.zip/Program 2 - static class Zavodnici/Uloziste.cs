﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace _2C_zavody
{
    static class Uloziste
    {
        static private List<Zavodnik> zavodnici = new List<Zavodnik>();

        static private bool ZavodnikExistuje(int cisloZavodnika)
        {
            foreach (Zavodnik z in zavodnici)
            {
                if (z.Cislo == cisloZavodnika)
                    return true;
            }
            return false;
        }

        static public bool PridejZavodnika(string jmeno, int cislo, char skupina)
        {
            //zde probíhá validace a kontrola správnosti dat před tvorbou samotného objektu
            try
            {
                if (ZavodnikExistuje(cislo))
                    return false;
             
                Zavodnik z = new Zavodnik(jmeno, cislo, skupina);
                zavodnici.Add(z);
                return true;

            }
            catch (Exception)
            {
                return false;
            }            
        }

        //metoda SmazZavodnika dle cisla, 
        //v případě smazaní se vrátí text "Závodnik Aleš byl smazán"
        //"Závodník neexistuje
        public static string SmazZavodnika(int cislo)
        {
            for (int i = 0; i < zavodnici.Count; i++)
            {
                if (zavodnici[i].Cislo == cislo)
                {
                    string jmeno = zavodnici[i].Jmeno;
                    zavodnici.RemoveAt(i);
                    return $"Závodnik {jmeno} byl smazán";
                }
            }
            return $"Závodník s číslem {cislo} neexistuje";
        }

        public static string VratZavodniky()
        {
            StringBuilder sb= new StringBuilder();
            foreach(Zavodnik z in zavodnici) 
               { sb.Append(z);
                sb.Append("\n");
            
            }
            return sb.ToString();
        }

     
        
    }
}
