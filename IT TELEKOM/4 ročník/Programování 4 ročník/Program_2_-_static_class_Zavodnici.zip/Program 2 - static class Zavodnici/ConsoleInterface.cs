﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace _2C_zavody
{
    static class ConsoleInterface
    {
        public static void Run()        
        {
            Console.WriteLine("Vítejte v programu závodníci");
            string prikaz;
            do
            {
                Console.WriteLine();
                Console.Write("Příkaz: ");
                prikaz = Console.ReadLine().Trim().ToLower();
                RozcestnikPrikazu(prikaz);

            } while (!prikaz.Equals("exit"));

            Console.WriteLine("Konce programu");
            Console.ReadLine();
        }

        static private void RozcestnikPrikazu(string prikaz)
        {
            //new, del, show, help, exit
            switch (prikaz)
            {
                case "new": NewPrikaz();  break;
                case "del": DelPrikaz(); break;
                case "show": Console.WriteLine(Uloziste.VratZavodniky()); break;
                case "help": HelpPrikaz(); break;
                case "exit": Console.WriteLine("Teď se vykonává příkaz exit.."); break;
                default: Console.WriteLine("Příka neexistuje, pokračujte příkazem help"); break;

            }
        }

        static private void NewPrikaz()
        {
            try
            {
                //VSTUPY
                Console.WriteLine("NOVÝ ZÁVODNÍK");
                Console.Write("Jméno: ");
                string jm = Console.ReadLine();
                Console.Write("Číslo: ");
                int cis = int.Parse(Console.ReadLine().Trim());
                Console.Write("Skupina: ");
                char sk = char.Parse(Console.ReadLine().ToUpper());

                //ZAVOLÁNÍ METODY PRIDEJZAVODNIKA, VE KTERÉ JE I KONSTRUKTOR A HLÍDÁNÍ, ZDA ČÍSLO ZÁVODNÍKA JIŽ JE POUŽITO
                bool vysledekOperace = Uloziste.PridejZavodnika(jm, cis, sk);

                //VÝSTUP - ZDA SE POVEDLO ZÁVODNÍKA VYTVOŘIT
                if (vysledekOperace) //vrací true nebo false
                    Console.WriteLine($"Závodník {jm} byl v pořádku vytvořen");
                else
                    Console.WriteLine($"Závodník {jm} nebyl vytvořen - závodník s daným číslem již existuje!");
            }
            catch (Exception)
            {
                Console.WriteLine($"Závodník nebyl vytvořen - chyba na vstupu, opakujte akci!");
            }
        }


        static private void DelPrikaz()
        {
            try
            {
                //VSTUPY
                Console.WriteLine("SMAŽ ZÁVODNÍKA");
                Console.Write("Číslo: ");
                int cis = int.Parse(Console.ReadLine().Trim());

                //ZAVOLÁNÍ METODY SMAZ ZAVODNIKA, KTERÁ MI ROVNOU VRACÍ I TEXTOVÝ VÝSLEDEK OPERACE
                Console.WriteLine(Uloziste.SmazZavodnika(cis));
            }
            catch (Exception)
            {
                Console.WriteLine($"Závodník nebyl smazán - chyba na vstupu, opakujte akci!");
            }
        }


        static private void HelpPrikaz()
        {
            Console.WriteLine("Seznam příkazů:");
            Console.WriteLine("new - vytvoření nového závodníka");
            Console.WriteLine("del - smazání závodníka dle čísla");
            Console.WriteLine("show - ukáže aktuální závodníky");
            Console.WriteLine("help - nápověda");
            Console.WriteLine("end - ukončení programu");
        }




    }
}
