﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;

namespace _3D_uzivRozhrani
{
    static internal class Uloziste
    {
        static List<int> seznam = new List<int>();

        public static void DefaultData(int pocet, int min, int max)
        {
            Random nahoda = new Random();
            for (int i = 0; i < pocet; i++)
            {
                seznam.Add(nahoda.Next(min, max + 1));
            }        
        }

        public static void PridejCislo(int cislo)
        {
            seznam.Add(cislo);
        }

        public static int OdeberCislo(int cislo)
        {
            //while (seznam.Contains(cislo))
            //{
            //    seznam.Remove(cislo);
            //}
            int pocet = 0;
            for (int i = 0; i < seznam.Count; i++)
            {
                if (seznam[i] == cislo)
                {
                    seznam.RemoveAt(i);
                    i--;
                    pocet++;
                }
            }
            return pocet;
        }

        public static string VratCisla()
        {
            StringBuilder sb = new StringBuilder();

            foreach (int x in seznam)
            {
                sb.Append(x+" ");
            }

            return sb.ToString();   
        }


    }
}
