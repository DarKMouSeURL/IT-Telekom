﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3D_uzivRozhrani
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Uloziste.DefaultData(50, -10, 10);
            UzivRozhraniConsole.Run();
            
        }
    }
}
