﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3D_uzivRozhrani
{
    static internal class UzivRozhraniConsole
    {
        static public void Run()
        {
            Console.WriteLine("Program běží");

            string prikaz;

            do
            {
                Console.WriteLine();
                Console.Write("Příkaz: ");
                prikaz = Console.ReadLine().Trim().ToLower();
                RozcestnikPrikazu(prikaz);

            } while (!prikaz.Equals("end"));

            Console.ReadLine();
        }

        static private void RozcestnikPrikazu(string prikaz)
        {
            //new, del, show, end, help

            switch (prikaz)
            {
                case "new": NewPrikaz() ; break;
                case "del": DelPrikaz(); break;
                case "show": Console.WriteLine(Uloziste.VratCisla()); break;
                case "end": Console.WriteLine("Program bude ukončen"); break;
                case "help": HelpPrikaz(); break;
                default: Console.WriteLine("Příkaz neexistuje, pokračujte příkazem help"); break;                    
            }
        }

        static private void NewPrikaz()
        {
            try
            {
               
                Console.Write("Zadej novou hodnotu: ");
                int hodnota = int.Parse(Console.ReadLine());
                Uloziste.PridejCislo(hodnota);
            }
            catch (Exception)
            {
                Console.WriteLine("Chyba na vstupu - příkaz nebyl proveden");
            }
            
        }

        static private void DelPrikaz()
        {
            try
            {
                Console.Write("Zadej mazanou hodnotu: ");
                int hodnota = int.Parse(Console.ReadLine());
                int pocet = Uloziste.OdeberCislo(hodnota);
                Console.WriteLine($"Bylo odebráno celkem {pocet} čísel");
            }
            catch (Exception)
            {
                Console.WriteLine("Chyba na vstupu - příkaz nebyl proveden");
            }
        }

        static private void HelpPrikaz()
        {
            Console.WriteLine("Seznam příkazů:");
            Console.WriteLine("new - nová hodnota");
            Console.WriteLine("del - smaže všechny výskyty čísla v seznamu");
            Console.WriteLine("show - ukáže aktuální hodnoty v seznamu");
            Console.WriteLine("help - nápověda");
            Console.WriteLine("end - ukončení programu");            
        }
    }
}
