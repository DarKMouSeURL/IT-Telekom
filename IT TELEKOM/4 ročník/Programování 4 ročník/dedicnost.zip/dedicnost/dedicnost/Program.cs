﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace dedicnost
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Animal> animals = new List<Animal>();
            //animal animal = new animal();
            Cat cat = new Cat();
            Dog dog = new Dog();
            Duck duck = new Duck();

            animals.Add(cat);
            animals.Add(dog);
            animals.Add(duck);

            Object obj = new Object();
            foreach (Animal animal in animals)
                animal.Speak();
            
        }

    }
}
