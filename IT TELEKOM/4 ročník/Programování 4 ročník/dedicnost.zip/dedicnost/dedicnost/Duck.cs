﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dedicnost
{
    internal class Duck : Animal
    {
        int featherCount;
        public override void Speak() { Console.WriteLine("QUACK!"); }
    }
}
