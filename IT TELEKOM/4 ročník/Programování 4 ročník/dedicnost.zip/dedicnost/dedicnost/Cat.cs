﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dedicnost
{
    public class Cat : Animal
    {
        public int livesCount;
        public override void Speak() {
            Console.WriteLine("Meow");
        }
    }
}
