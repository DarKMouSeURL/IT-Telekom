﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dedicnost
{
    public abstract class Animal
    {
        public string color;

        public void Move() { }
        public abstract void Speak();
    }

}
