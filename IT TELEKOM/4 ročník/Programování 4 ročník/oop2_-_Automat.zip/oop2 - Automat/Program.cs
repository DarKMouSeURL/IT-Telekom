﻿// See https://aka.ms/new-console-template for more information
using _2C_OOP2;

Console.WriteLine("Hello, World!");

//třída
//Automat
//- string znacka
//- int pocetNapoju
//- bool vraci

//Tříparametrický konstruktor
//Dvouparametrický konstruktor, defaultně bude nastavovat vraci = true

//Metoda pro výpis ToString: 
//"Automat [znacka: delongi, pocetnapoju: 12, vraci: true]"

//DEFAULT DATA
Automat a1 = new Automat("Bosch", 10);
Automat a2 = new Automat("SilverCrest", 8, false);
Automat a3 = new Automat("Siemens", 20);

//VSTUPY
Console.WriteLine("---- Vytvoření nového automatu na pití ---");
Console.Write("Značka: ");
string zn = Console.ReadLine();
Console.Write("Počet nápojů: ");
int po = int.Parse(Console.ReadLine());
Console.Write("Vrací automat peníze? (a/n): ");
bool vraci = true;
if (Console.ReadLine().ToLower().Trim().Equals("n"))
    vraci = false;
Automat a4= new Automat(zn, po, vraci);

//VÝSTUPY
Console.WriteLine();
Console.WriteLine(a1.ToString());
Console.WriteLine(a2); //ToString se volá implicitně v rámci Console.WriteLine, není třeba jej psát
Console.WriteLine(a3);
Console.WriteLine(a4);