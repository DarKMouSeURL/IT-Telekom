﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2C_OOP2
{
    internal class Automat
    {
        //třída Automat
        public string znacka;
        public int pocetNapoju;
        public bool vraci = true; 

        //Tříparametrický konstruktor
        public Automat(string znacka, int pocetNapoju, bool vraci)
        {
            this.znacka = znacka;
            this.pocetNapoju = pocetNapoju;
            this.vraci = vraci;
        }

        //Dvouparametrický konstruktor, defaultně bude nastavovat vraci = true
        public Automat(string znacka, int pocetNapoju)
        {
            this.znacka = znacka;
            this.pocetNapoju = pocetNapoju;
        }

        //"Automat [znacka: delongi, pocetnapoju: 12, vraci: true]"
        public override string ToString()
        {
            return String.Format($"{this.GetType().Name} [znacka: {znacka}, pocetnapoju: {pocetNapoju}, vraci: {vraci}]");
        }
    }
}
