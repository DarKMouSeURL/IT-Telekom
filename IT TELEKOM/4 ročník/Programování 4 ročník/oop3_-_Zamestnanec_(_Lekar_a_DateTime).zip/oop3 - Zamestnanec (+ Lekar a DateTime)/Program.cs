﻿// See https://aka.ms/new-console-template for more information

using _2C_OOP3;

DateTime dt1 = new DateTime(1988, 12, 24);
Lekar l1 = new Lekar("Mudr. Vlasta Tichá", "987456321", "Porubská 5, Ostrava");
Zamestnanec z1 = new Zamestnanec("Martin", 15, false,dt1,l1);
Console.WriteLine(z1);

Zamestnanec z2 = new Zamestnanec("Petra", 6, true, new DateTime(2000, 2, 5),l1);
Console.WriteLine(z2);
