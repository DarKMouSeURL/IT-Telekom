﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2C_OOP3
{
    internal class Zamestnanec
    {
        //jméno, datum narození, zdravotní omezení, odpracovaných let, 
        //ošetřující lékař

        public string jmeno;
        public int odpracovanychLet;
        public bool zdravotniOmezeni;
        public DateTime datumNarozeni;
        public Lekar osetrujiciLekar;

        public Zamestnanec(string jmeno, int odpracovanychLet, bool zdravotniOmezeni, DateTime datumNarozeni, Lekar osetrujiciLekar)
        {
            this.jmeno = jmeno;
            this.odpracovanychLet = odpracovanychLet;
            this.zdravotniOmezeni = zdravotniOmezeni;
            this.datumNarozeni = datumNarozeni;
            this.osetrujiciLekar = osetrujiciLekar;
        }

        public override string ToString()
        {
            //požadován text ve formátu:
            //jméno: Petr, odpracováno: 5 let, zdravotní omezení : ano/ne

            //string omezeniText = "ne";
            //if (zdravotniOmezeni)
            //    omezeniText = "ano";
            string omezeniText = zdravotniOmezeni ? "ano" : "ne";

            return $"jméno: {jmeno}, odpracováno: {odpracovanychLet} let, zdravotní omezení : {omezeniText}, datum narození: {datumNarozeni.ToShortDateString()}, ošetřující lékař: {osetrujiciLekar.jmeno}";
        }
    }
}
