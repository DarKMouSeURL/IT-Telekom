﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2CGetSet
{
    internal class Ucet
    {
        //vlastnosti:
        //log - get (její stav bude měněn na základě metod)
        //jmeno - get (nebude možné jej měnit)
        //heslo - (cokoli budeme dělat pouze pomocí metod)
        //mail - get, set

        //metody:
        //0) Konstruktor
        //1) Login - na základě jména a hesla se zalogujete nebo nikoli
        //2) Logout - odlugujeme se
        //3) UkazDelkuHesla - ukáže řetězec * dle délky hesla
        //4) ZmenHeslo - po potvrzení starého hesla můžeme nastavit heslo nové
        //               uživatel musí být během změny přihlášen
        //5) ToString - vrací obsah všech proměnných


        private bool log = false;
        public bool Log { get { return log; }  }

        private string jmeno;
        public string Jmeno { get { return jmeno; } }

        private string heslo;

        private string mail;
        public string Mail { get { return mail; } set { mail = value; } }

        //0) Konstruktor
        public Ucet(string jmeno, string heslo, string mail)
        {
            this.jmeno = jmeno;
            this.heslo = heslo;
            this.mail = mail; //Mail = mail
        }

        //1) Login - na základě jména a hesla se zalogujete nebo nikoli
        public void Login(string zadaneJmeno, string zadaneHeslo)
        {
            if (jmeno.Equals(zadaneJmeno) && heslo.Equals(zadaneHeslo))
            { 
                log = true;
                return;             
            }
            log = false;            
        }

        public void Logout()
        {
            log = false;
        }


    }
}
