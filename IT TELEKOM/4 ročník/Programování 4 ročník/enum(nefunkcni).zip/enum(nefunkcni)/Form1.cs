namespace _2C_timerOk
{
    enum Den
    {
        Po,Ut,St,Ct,Pa,So,Ne
    }


    public partial class Form1 : Form
    {
        //�lensk� (glob�ln�) prom�nn�
        int cislo = 0;
        Den den = Den.Po;
        

        public Form1()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {       
            //tick nahrazuje cyklus!       
            cislo++;
            label1.Text=cislo.ToString();

            if (cislo == 500)
            {
                timer1.Enabled = false;
                cislo = 0;
            }
        }

        private void bStart_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true; //zapnut�
        }

        private void bStartDny_Click(object sender, EventArgs e)
        {
            timer2.Enabled = true;
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            Random nahoda = new Random();

            int nahCislo = nahoda.Next(0, 7);
            Den losovanyDen = (Den)nahCislo;
            label2.Text = losovanyDen.ToString();

            if (losovanyDen == Den.Ne)
                timer2.Enabled = false;
        }
    }
}