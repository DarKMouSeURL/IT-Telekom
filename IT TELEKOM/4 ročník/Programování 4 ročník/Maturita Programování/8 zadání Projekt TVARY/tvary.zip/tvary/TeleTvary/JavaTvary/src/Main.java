import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Tvar[] poleTvaru = new Tvar[6];

        Scanner sc = new Scanner(System.in);

        System.out.println("VSTUPY");

        System.out.println("Zadejte šířku pro obdelnik 1: ");
        int sirka = Integer.parseInt(sc.nextLine());
        System.out.println("Zadejte výšku pro obdelnik 1: ");
        int vyska = Integer.parseInt(sc.nextLine());




        Obdelnik ob1 = new Obdelnik(sirka, vyska);
        Obdelnik ob2 =  new Obdelnik(10,3);
        poleTvaru[0] = ob1;
        poleTvaru[1] = ob2;

        System.out.print("Zadejte šířku pro ctverec 1: ");
        sirka = Integer.parseInt(sc.nextLine());

        Ctverec c1 = new Ctverec(sirka);
        Ctverec c2 = new Ctverec(3);
        poleTvaru[2] = c1;
        poleTvaru[3] = c2;

        System.out.print("Zadejte šířku pro kruh 1: ");
        sirka = Integer.parseInt(sc.nextLine());

        Kruh o1 = new Kruh(sirka);
        Kruh o2 =  new Kruh(8);
        poleTvaru[4] = o1;
        poleTvaru[5] = o2;

        System.out.println("\n Zpracovaní a výstupy");

        for (Tvar t : poleTvaru)
        {
            System.out.println("Metoda ToString() pro => " + t.toString());
            System.out.println("Obvod je " + t.VypocitatObvod());
            System.out.println("Obvod je " + t.VypocitatObsah());
            t.Nakreslit();


        }




    }
}


