﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TeleTvar;
using TeleTvary;

namespace TeleForm
{
    public partial class Form1 : Form
    {

        List<Tvar> tvary = new List<Tvar>();
        public Form1()
        {
            InitializeComponent();
        }

        private void ButtonBarva_Click(object sender, EventArgs e)
        {
            colorDialog1.ShowDialog();
            LabelBarva.BackColor = colorDialog1.Color;
        }

        private void ButtonObdelnik_Click(object sender, EventArgs e)
        {
            int sirka = (int)numericUpDownSirka.Value;
            int vyska = (int)numericUpDownVyska.Value;
            int x  = (int)numericUpDownX.Value;
            int y = (int)numericUpDownY.Value;
            Color barva = colorDialog1.Color;
            Obdelnik o = new Obdelnik(sirka,vyska,x,y,barva);
            tvary.Add(o);
            NactiData();
        }

        private void ButtonCtverec_Click(object sender, EventArgs e)
        {
            int sirka = (int)numericUpDownSirka.Value;
            int x = (int)numericUpDownX.Value;
            int y = (int)numericUpDownY.Value;
            Color barva = colorDialog1.Color;
            Ctverec c = new Ctverec(sirka,  x, y, barva);
            tvary.Add(c);
            NactiData();
        }

        private void ButtonKruh_Click(object sender, EventArgs e)
        {
            int sirka = (int)numericUpDownSirka.Value;
            int x = (int)numericUpDownX.Value;
            int y = (int)numericUpDownY.Value;
            Color barva = colorDialog1.Color;
            Kruh k  = new Kruh(sirka, x, y, barva);
            tvary.Add(k);
            NactiData();
        }

        private void NactiData()
        {
            listBox1.DataSource = null;
            listBox1.DataSource = tvary;
            Panel.Refresh();
        }

        private void Panel_Paint(object sender, PaintEventArgs e)
        {
            foreach (Tvar tvar in tvary)
            {
                tvar.NakreslitGUI(e.Graphics);
            }
        }

        private void ButtonVypocitatObvod_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItems.Count > 0)
            {
                LabelObvod.Text = (listBox1.SelectedItem as Tvar).VypocitatObvod().ToString();

            }
        }

        private void ButtonVypocitatObsah_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItems.Count > 0)
            {
                LabelObsah.Text = (listBox1.SelectedItem as Tvar).VypocitatObsah().ToString();

            }
        }

        private void ButtonNahoru_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItems.Count > 0)
            {
                (listBox1.SelectedItem as Tvar).Nahoru();
                NactiData();

            }
        }

        private void ButtonDolu_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItems.Count > 0)
            {
                (listBox1.SelectedItem as Tvar).Dolu();
                NactiData();

            }
        }

        private void ButtonDoprava_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItems.Count > 0)
            {
                (listBox1.SelectedItem as Tvar).Doprava();
                NactiData();

            }
        }

        private void ButtonDoleva_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItems.Count > 0)
            {
                (listBox1.SelectedItem as Tvar).Doleva();
                NactiData();

            }
        }

        private void ButtonZvetsit_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItems.Count > 0)
            {
                (listBox1.SelectedItem as Tvar).Zvetsit();
                NactiData();

            }
        }

        private void ButtonZmensit_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItems.Count > 0)
            {
                (listBox1.SelectedItem as Tvar).Zmensit();
                NactiData();

            }
        }
    }
}
