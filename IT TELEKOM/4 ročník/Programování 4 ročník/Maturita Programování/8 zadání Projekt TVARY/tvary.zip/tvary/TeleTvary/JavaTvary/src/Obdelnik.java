public class Obdelnik extends Tvar{
    public Obdelnik()
    {

    }

    public Obdelnik (int sirka, int vyska)
    {
        super(sirka, vyska);
    }
    @Override
    public  void Nakreslit()
    {
        for (int i = 0; i < vyska; i++)
        {
            for(int j = 0; j < sirka; j++)
            {
                System.out.print("■ ");
            }
            System.out.println();
        }
    }
    @Override
    public  double VypocitatObsah()
    {
        return sirka*vyska;
    }
    @Override
    public  double VypocitatObvod()
    {
        return 2 * sirka + 2 * vyska;
    }
    @Override
    public  String toString()
    {
        return "Obdelnik " + super.toString();
    }
}

