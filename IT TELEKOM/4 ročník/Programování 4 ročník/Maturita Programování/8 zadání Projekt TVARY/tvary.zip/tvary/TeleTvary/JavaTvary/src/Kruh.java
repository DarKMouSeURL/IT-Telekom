
public class Kruh extends Tvar
{
        public Kruh()
            {
            }

        public Kruh (int sirka)
            {
                super(sirka, sirka);
            }
            @Override
            public  void Nakreslit()
            {
                System.out.println("Kruh není jednoduché v konzoli nakraslit");
            }
            @Override
            public  double VypocitatObsah()
            {
                return Math.PI * Math.pow((sirka/2), 2);
            }
            @Override
            public double VypocitatObvod()
            {
                return Math.PI * sirka;
            }
            @Override
            public String toString()
            {
                return "kruh " + super.toString();
            }
        }



