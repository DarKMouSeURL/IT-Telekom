﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TeleTvar;

namespace TeleTvary
{
    public class Obdelnik : Tvar
    {

        public Obdelnik() 
        {
            
        }

        public Obdelnik (int sirka, int vyska) : base(sirka, vyska)
        {
        }

        public Obdelnik(int sirka, int vyska, int x, int y, Color barva) : base(sirka, vyska,x,y, barva)
        {
        }

        public override void Nakreslit()
        {
            for (int i = 0; i < vyska; i++)
            {
                for(int j = 0; j < sirka; j++)
                {
                    Console.Write("■ ");
                }
                Console.WriteLine();
            }
        }

        public override void NakreslitGUI(Graphics papir)
        {
            SolidBrush stetec = new SolidBrush(barva);
            papir.FillRectangle(stetec, x, y, sirka, vyska);
        }

        public override double VypocitatObsah()
        {
            return sirka*vyska;
        }

        public override double VypocitatObvod()
        {
            return 2 * sirka + 2 * vyska;
        }

        public override string ToString()
        {
            return "Obdelnik " + base.ToString();
        }
    }
}
