
        public abstract class Tvar
        {
            protected int sirka;
            protected int vyska;

            public Tvar()
            {

            }

            public Tvar(int sirka)
            {
                this.sirka = sirka;
            }
            public Tvar(int sirka, int vyska)
            {
                this.sirka = sirka;
                this.vyska = vyska;
            }
            @Override
            public   String toString()
        {
            return "(sirka" + sirka + ", vyska=" + vyska + ")";
        }

            public abstract void Nakreslit();





            public abstract double VypocitatObvod();





            public abstract double VypocitatObsah();



        }



