﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeleTvar
{
     public abstract class Tvar
    {
       protected int sirka;
       protected int vyska;
        protected int x;
        protected int y;
        protected Color barva;

        public Tvar()
        {

        }

        public Tvar(int sirka)
        {
            this.sirka = sirka;
        }
        public Tvar(int sirka, int vyska)
        {
            this.sirka = sirka;
            this.vyska = vyska;
        }
        public Tvar(int sirka, int vyska, int x, int y, Color barva)
        {
            this.sirka = sirka;
            this.vyska = vyska;
            this.x = x;
            this.y = y;
            this.barva = barva;
        }


        public  override string ToString()
        {
            return "(sirka" + sirka + ", vyska=" + vyska + ")";
        }

        public abstract void Nakreslit();


        public abstract void NakreslitGUI(Graphics papir);


        public abstract double VypocitatObvod();





        public abstract double VypocitatObsah();
        
        public void Nahoru()
        {
            y -= 10;
        }
        public void Dolu()
        {
            y += 10;
        }

        public void Doprava()
        {
            x += 10;
        }
        public void Doleva()
        {
            x -= 10;
        }

        public void Zmensit()
        {
            if (sirka > 20  && vyska > 20)
            {
                sirka /= 2;
                vyska /= 2; 
            }
        }

        public void Zvetsit()
        {
            sirka *= 2;
            vyska *= 2;
        }


    }
}
