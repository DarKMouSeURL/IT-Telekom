public class Ctverec extends Obdelnik{

    public Ctverec()
    {
    }


    public Ctverec(int sirka)
    {
        super(sirka, sirka);
    }
    @Override
    public  String toString()
    {
        return "ctverec je specialní -> " + super.toString();
    }
}



