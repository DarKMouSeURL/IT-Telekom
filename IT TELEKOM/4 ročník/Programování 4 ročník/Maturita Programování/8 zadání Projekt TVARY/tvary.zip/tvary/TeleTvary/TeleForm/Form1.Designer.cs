﻿namespace TeleForm
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.numericUpDownX = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownY = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownVyska = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownSirka = new System.Windows.Forms.NumericUpDown();
            this.LabelX = new System.Windows.Forms.Label();
            this.LabelY = new System.Windows.Forms.Label();
            this.LabelSirka = new System.Windows.Forms.Label();
            this.LabelVyska = new System.Windows.Forms.Label();
            this.ButtonBarva = new System.Windows.Forms.Button();
            this.ButtonObdelnik = new System.Windows.Forms.Button();
            this.ButtonCtverec = new System.Windows.Forms.Button();
            this.ButtonKruh = new System.Windows.Forms.Button();
            this.GroupBoxOvladani = new System.Windows.Forms.GroupBox();
            this.ButtonZmensit = new System.Windows.Forms.Button();
            this.ButtonZvetsit = new System.Windows.Forms.Button();
            this.ButtonDoleva = new System.Windows.Forms.Button();
            this.ButtonDolu = new System.Windows.Forms.Button();
            this.ButtonDoprava = new System.Windows.Forms.Button();
            this.ButtonNahoru = new System.Windows.Forms.Button();
            this.ButtonVypocitatObvod = new System.Windows.Forms.Button();
            this.ButtonVypocitatObsah = new System.Windows.Forms.Button();
            this.LabelObsah = new System.Windows.Forms.Label();
            this.LabelObvod = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.LabelBarva = new System.Windows.Forms.Label();
            this.Panel = new System.Windows.Forms.Panel();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownVyska)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSirka)).BeginInit();
            this.GroupBoxOvladani.SuspendLayout();
            this.SuspendLayout();
            // 
            // numericUpDownX
            // 
            this.numericUpDownX.Location = new System.Drawing.Point(26, 79);
            this.numericUpDownX.Maximum = new decimal(new int[] {
            800,
            0,
            0,
            0});
            this.numericUpDownX.Name = "numericUpDownX";
            this.numericUpDownX.Size = new System.Drawing.Size(120, 20);
            this.numericUpDownX.TabIndex = 0;
            // 
            // numericUpDownY
            // 
            this.numericUpDownY.Location = new System.Drawing.Point(26, 152);
            this.numericUpDownY.Maximum = new decimal(new int[] {
            800,
            0,
            0,
            0});
            this.numericUpDownY.Name = "numericUpDownY";
            this.numericUpDownY.Size = new System.Drawing.Size(120, 20);
            this.numericUpDownY.TabIndex = 1;
            // 
            // numericUpDownVyska
            // 
            this.numericUpDownVyska.Location = new System.Drawing.Point(236, 152);
            this.numericUpDownVyska.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownVyska.Name = "numericUpDownVyska";
            this.numericUpDownVyska.Size = new System.Drawing.Size(120, 20);
            this.numericUpDownVyska.TabIndex = 3;
            this.numericUpDownVyska.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // numericUpDownSirka
            // 
            this.numericUpDownSirka.Location = new System.Drawing.Point(236, 79);
            this.numericUpDownSirka.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownSirka.Name = "numericUpDownSirka";
            this.numericUpDownSirka.Size = new System.Drawing.Size(120, 20);
            this.numericUpDownSirka.TabIndex = 2;
            this.numericUpDownSirka.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // LabelX
            // 
            this.LabelX.AutoSize = true;
            this.LabelX.Location = new System.Drawing.Point(23, 59);
            this.LabelX.Name = "LabelX";
            this.LabelX.Size = new System.Drawing.Size(49, 13);
            this.LabelX.TabIndex = 4;
            this.LabelX.Text = "Pozice X";
            // 
            // LabelY
            // 
            this.LabelY.AutoSize = true;
            this.LabelY.Location = new System.Drawing.Point(23, 136);
            this.LabelY.Name = "LabelY";
            this.LabelY.Size = new System.Drawing.Size(49, 13);
            this.LabelY.TabIndex = 5;
            this.LabelY.Text = "Pozice Y";
            // 
            // LabelSirka
            // 
            this.LabelSirka.AutoSize = true;
            this.LabelSirka.Location = new System.Drawing.Point(233, 59);
            this.LabelSirka.Name = "LabelSirka";
            this.LabelSirka.Size = new System.Drawing.Size(34, 13);
            this.LabelSirka.TabIndex = 6;
            this.LabelSirka.Text = "Šířka";
            // 
            // LabelVyska
            // 
            this.LabelVyska.AutoSize = true;
            this.LabelVyska.Location = new System.Drawing.Point(233, 136);
            this.LabelVyska.Name = "LabelVyska";
            this.LabelVyska.Size = new System.Drawing.Size(36, 13);
            this.LabelVyska.TabIndex = 7;
            this.LabelVyska.Text = "Výška";
            // 
            // ButtonBarva
            // 
            this.ButtonBarva.Location = new System.Drawing.Point(26, 219);
            this.ButtonBarva.Name = "ButtonBarva";
            this.ButtonBarva.Size = new System.Drawing.Size(120, 38);
            this.ButtonBarva.TabIndex = 8;
            this.ButtonBarva.Text = "Barva";
            this.ButtonBarva.UseVisualStyleBackColor = true;
            this.ButtonBarva.Click += new System.EventHandler(this.ButtonBarva_Click);
            // 
            // ButtonObdelnik
            // 
            this.ButtonObdelnik.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.ButtonObdelnik.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonObdelnik.ForeColor = System.Drawing.Color.Black;
            this.ButtonObdelnik.Location = new System.Drawing.Point(236, 219);
            this.ButtonObdelnik.Name = "ButtonObdelnik";
            this.ButtonObdelnik.Size = new System.Drawing.Size(120, 38);
            this.ButtonObdelnik.TabIndex = 9;
            this.ButtonObdelnik.Text = "Obdelník";
            this.ButtonObdelnik.UseVisualStyleBackColor = false;
            this.ButtonObdelnik.Click += new System.EventHandler(this.ButtonObdelnik_Click);
            // 
            // ButtonCtverec
            // 
            this.ButtonCtverec.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ButtonCtverec.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonCtverec.Location = new System.Drawing.Point(236, 277);
            this.ButtonCtverec.Name = "ButtonCtverec";
            this.ButtonCtverec.Size = new System.Drawing.Size(120, 38);
            this.ButtonCtverec.TabIndex = 10;
            this.ButtonCtverec.Text = "Čtverec";
            this.ButtonCtverec.UseVisualStyleBackColor = false;
            this.ButtonCtverec.Click += new System.EventHandler(this.ButtonCtverec_Click);
            // 
            // ButtonKruh
            // 
            this.ButtonKruh.BackColor = System.Drawing.Color.Red;
            this.ButtonKruh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonKruh.Location = new System.Drawing.Point(236, 331);
            this.ButtonKruh.Name = "ButtonKruh";
            this.ButtonKruh.Size = new System.Drawing.Size(120, 38);
            this.ButtonKruh.TabIndex = 11;
            this.ButtonKruh.Text = "Kruh";
            this.ButtonKruh.UseVisualStyleBackColor = false;
            this.ButtonKruh.Click += new System.EventHandler(this.ButtonKruh_Click);
            // 
            // GroupBoxOvladani
            // 
            this.GroupBoxOvladani.Controls.Add(this.ButtonZmensit);
            this.GroupBoxOvladani.Controls.Add(this.ButtonZvetsit);
            this.GroupBoxOvladani.Controls.Add(this.ButtonDoleva);
            this.GroupBoxOvladani.Controls.Add(this.ButtonDolu);
            this.GroupBoxOvladani.Controls.Add(this.ButtonDoprava);
            this.GroupBoxOvladani.Controls.Add(this.ButtonNahoru);
            this.GroupBoxOvladani.Location = new System.Drawing.Point(26, 398);
            this.GroupBoxOvladani.Name = "GroupBoxOvladani";
            this.GroupBoxOvladani.Size = new System.Drawing.Size(330, 166);
            this.GroupBoxOvladani.TabIndex = 12;
            this.GroupBoxOvladani.TabStop = false;
            this.GroupBoxOvladani.Text = "Ovládání";
            // 
            // ButtonZmensit
            // 
            this.ButtonZmensit.Location = new System.Drawing.Point(249, 73);
            this.ButtonZmensit.Name = "ButtonZmensit";
            this.ButtonZmensit.Size = new System.Drawing.Size(75, 32);
            this.ButtonZmensit.TabIndex = 5;
            this.ButtonZmensit.Text = "Zmenšit";
            this.ButtonZmensit.UseVisualStyleBackColor = true;
            this.ButtonZmensit.Click += new System.EventHandler(this.ButtonZmensit_Click);
            // 
            // ButtonZvetsit
            // 
            this.ButtonZvetsit.Location = new System.Drawing.Point(249, 19);
            this.ButtonZvetsit.Name = "ButtonZvetsit";
            this.ButtonZvetsit.Size = new System.Drawing.Size(75, 32);
            this.ButtonZvetsit.TabIndex = 4;
            this.ButtonZvetsit.Text = "Zvětšít";
            this.ButtonZvetsit.UseVisualStyleBackColor = true;
            this.ButtonZvetsit.Click += new System.EventHandler(this.ButtonZvetsit_Click);
            // 
            // ButtonDoleva
            // 
            this.ButtonDoleva.Location = new System.Drawing.Point(7, 52);
            this.ButtonDoleva.Name = "ButtonDoleva";
            this.ButtonDoleva.Size = new System.Drawing.Size(75, 32);
            this.ButtonDoleva.TabIndex = 3;
            this.ButtonDoleva.Text = "←";
            this.ButtonDoleva.UseVisualStyleBackColor = true;
            this.ButtonDoleva.Click += new System.EventHandler(this.ButtonDoleva_Click);
            // 
            // ButtonDolu
            // 
            this.ButtonDolu.Location = new System.Drawing.Point(81, 90);
            this.ButtonDolu.Name = "ButtonDolu";
            this.ButtonDolu.Size = new System.Drawing.Size(75, 32);
            this.ButtonDolu.TabIndex = 2;
            this.ButtonDolu.Text = "↓";
            this.ButtonDolu.UseVisualStyleBackColor = true;
            this.ButtonDolu.Click += new System.EventHandler(this.ButtonDolu_Click);
            // 
            // ButtonDoprava
            // 
            this.ButtonDoprava.Location = new System.Drawing.Point(151, 52);
            this.ButtonDoprava.Name = "ButtonDoprava";
            this.ButtonDoprava.Size = new System.Drawing.Size(75, 32);
            this.ButtonDoprava.TabIndex = 1;
            this.ButtonDoprava.Text = "→";
            this.ButtonDoprava.UseVisualStyleBackColor = true;
            this.ButtonDoprava.Click += new System.EventHandler(this.ButtonDoprava_Click);
            // 
            // ButtonNahoru
            // 
            this.ButtonNahoru.Location = new System.Drawing.Point(81, 19);
            this.ButtonNahoru.Name = "ButtonNahoru";
            this.ButtonNahoru.Size = new System.Drawing.Size(75, 32);
            this.ButtonNahoru.TabIndex = 0;
            this.ButtonNahoru.Text = "↑";
            this.ButtonNahoru.UseVisualStyleBackColor = true;
            this.ButtonNahoru.Click += new System.EventHandler(this.ButtonNahoru_Click);
            // 
            // ButtonVypocitatObvod
            // 
            this.ButtonVypocitatObvod.Location = new System.Drawing.Point(26, 712);
            this.ButtonVypocitatObvod.Name = "ButtonVypocitatObvod";
            this.ButtonVypocitatObvod.Size = new System.Drawing.Size(104, 40);
            this.ButtonVypocitatObvod.TabIndex = 13;
            this.ButtonVypocitatObvod.Text = "Vypočítat Obvod";
            this.ButtonVypocitatObvod.UseVisualStyleBackColor = true;
            this.ButtonVypocitatObvod.Click += new System.EventHandler(this.ButtonVypocitatObvod_Click);
            // 
            // ButtonVypocitatObsah
            // 
            this.ButtonVypocitatObsah.Location = new System.Drawing.Point(26, 783);
            this.ButtonVypocitatObsah.Name = "ButtonVypocitatObsah";
            this.ButtonVypocitatObsah.Size = new System.Drawing.Size(104, 40);
            this.ButtonVypocitatObsah.TabIndex = 14;
            this.ButtonVypocitatObsah.Text = "Vypočítat Obsah";
            this.ButtonVypocitatObsah.UseVisualStyleBackColor = true;
            this.ButtonVypocitatObsah.Click += new System.EventHandler(this.ButtonVypocitatObsah_Click);
            // 
            // LabelObsah
            // 
            this.LabelObsah.BackColor = System.Drawing.SystemColors.ControlLight;
            this.LabelObsah.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LabelObsah.Location = new System.Drawing.Point(227, 783);
            this.LabelObsah.Name = "LabelObsah";
            this.LabelObsah.Size = new System.Drawing.Size(129, 40);
            this.LabelObsah.TabIndex = 16;
            this.LabelObsah.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LabelObvod
            // 
            this.LabelObvod.BackColor = System.Drawing.SystemColors.ControlLight;
            this.LabelObvod.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LabelObvod.Location = new System.Drawing.Point(227, 712);
            this.LabelObvod.Name = "LabelObvod";
            this.LabelObvod.Size = new System.Drawing.Size(129, 40);
            this.LabelObvod.TabIndex = 17;
            this.LabelObvod.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(26, 588);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(330, 95);
            this.listBox1.TabIndex = 18;
            // 
            // LabelBarva
            // 
            this.LabelBarva.BackColor = System.Drawing.Color.Black;
            this.LabelBarva.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LabelBarva.Location = new System.Drawing.Point(168, 219);
            this.LabelBarva.Name = "LabelBarva";
            this.LabelBarva.Size = new System.Drawing.Size(48, 38);
            this.LabelBarva.TabIndex = 19;
            this.LabelBarva.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Panel
            // 
            this.Panel.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Panel.Dock = System.Windows.Forms.DockStyle.Right;
            this.Panel.ForeColor = System.Drawing.Color.Black;
            this.Panel.Location = new System.Drawing.Point(432, 0);
            this.Panel.Name = "Panel";
            this.Panel.Size = new System.Drawing.Size(848, 833);
            this.Panel.TabIndex = 20;
            this.Panel.Paint += new System.Windows.Forms.PaintEventHandler(this.Panel_Paint);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1280, 833);
            this.Controls.Add(this.Panel);
            this.Controls.Add(this.LabelBarva);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.LabelObvod);
            this.Controls.Add(this.LabelObsah);
            this.Controls.Add(this.ButtonVypocitatObsah);
            this.Controls.Add(this.ButtonVypocitatObvod);
            this.Controls.Add(this.GroupBoxOvladani);
            this.Controls.Add(this.ButtonKruh);
            this.Controls.Add(this.ButtonCtverec);
            this.Controls.Add(this.ButtonObdelnik);
            this.Controls.Add(this.ButtonBarva);
            this.Controls.Add(this.LabelVyska);
            this.Controls.Add(this.LabelSirka);
            this.Controls.Add(this.LabelY);
            this.Controls.Add(this.LabelX);
            this.Controls.Add(this.numericUpDownVyska);
            this.Controls.Add(this.numericUpDownSirka);
            this.Controls.Add(this.numericUpDownY);
            this.Controls.Add(this.numericUpDownX);
            this.MaximumSize = new System.Drawing.Size(1296, 872);
            this.MinimumSize = new System.Drawing.Size(1296, 872);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownVyska)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSirka)).EndInit();
            this.GroupBoxOvladani.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown numericUpDownX;
        private System.Windows.Forms.NumericUpDown numericUpDownY;
        private System.Windows.Forms.NumericUpDown numericUpDownVyska;
        private System.Windows.Forms.NumericUpDown numericUpDownSirka;
        private System.Windows.Forms.Label LabelX;
        private System.Windows.Forms.Label LabelY;
        private System.Windows.Forms.Label LabelSirka;
        private System.Windows.Forms.Label LabelVyska;
        private System.Windows.Forms.Button ButtonBarva;
        private System.Windows.Forms.Button ButtonObdelnik;
        private System.Windows.Forms.Button ButtonCtverec;
        private System.Windows.Forms.Button ButtonKruh;
        private System.Windows.Forms.GroupBox GroupBoxOvladani;
        private System.Windows.Forms.Button ButtonDoleva;
        private System.Windows.Forms.Button ButtonDolu;
        private System.Windows.Forms.Button ButtonDoprava;
        private System.Windows.Forms.Button ButtonNahoru;
        private System.Windows.Forms.Button ButtonZmensit;
        private System.Windows.Forms.Button ButtonZvetsit;
        private System.Windows.Forms.Button ButtonVypocitatObvod;
        private System.Windows.Forms.Button ButtonVypocitatObsah;
        private System.Windows.Forms.Label LabelObsah;
        private System.Windows.Forms.Label LabelObvod;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label LabelBarva;
        private System.Windows.Forms.Panel Panel;
        private System.Windows.Forms.ColorDialog colorDialog1;
    }
}

