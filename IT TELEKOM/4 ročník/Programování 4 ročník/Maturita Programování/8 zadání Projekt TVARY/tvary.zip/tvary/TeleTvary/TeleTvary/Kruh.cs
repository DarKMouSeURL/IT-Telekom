﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TeleTvar;

namespace TeleTvary
{
    public class Kruh : Tvar
    {
        public Kruh() 
        {
        }

        public Kruh (int sirka) : base(sirka, sirka)
        {

        }

        public Kruh(int sirka, int x, int y, Color barva) : base(sirka, sirka,x,y,barva)
        {

        }

        public override void NakreslitGUI(Graphics papir)
        {
            SolidBrush stetec = new SolidBrush(barva);
            papir.FillEllipse(stetec, x, y, sirka, vyska);
        }

        public override void Nakreslit()
        {
            Console.WriteLine("Kruh není jednoduché v konzoli nakraslit");
        }

        public override double VypocitatObsah()
        {
            return Math.PI * Math.Pow((sirka/2), 2);
        }

        public override double VypocitatObvod()
        {
            return Math.PI * sirka;
        }

        public override string ToString()
        {
            return "kruh " + base.ToString();
        }
    }
}
