﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TeleTvar;
using TeleTvary;

namespace TeleConsole
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Tvar[] poleTvaru = new Tvar[6];

            Console.WriteLine("VSTUPY");

            Console.Write("Zadejte šířku pro obdelnik 1: ");
            int sirka = int.Parse(Console.ReadLine());
            Console.Write("Zadejte výšku pro obdelnik 1: ");
            int vyska = int.Parse(Console.ReadLine());




            Obdelnik ob1 = new Obdelnik(sirka, vyska);
            Obdelnik ob2 =  new Obdelnik(10,1);
            poleTvaru[0] = ob1;
            poleTvaru[1] = ob2;

            Console.Write("Zadejte šířku pro ctverec 1: ");
            sirka = int.Parse(Console.ReadLine());

            Ctverec c1 = new Ctverec(sirka);
            Ctverec c2 = new Ctverec(3);
            poleTvaru[2] = c1;
            poleTvaru[3] = c2;

            Console.Write("Zadejte šířku pro kruh 1: ");
            sirka = int.Parse(Console.ReadLine());

            Kruh o1 = new Kruh(sirka);
            Kruh o2 =  new Kruh(8);
            poleTvaru[4] = o1;
            poleTvaru[5] = o2;

            Console.WriteLine("\n Zpracovaní a výstupy");

            foreach (Tvar t in poleTvaru)
            {
                Console.WriteLine("Metoda ToString() pro => " + t.ToString());
                Console.WriteLine("Obvod je " + t.VypocitatObvod());
                Console.WriteLine("Obvod je " + t.VypocitatObsah());
                t.Nakreslit();


            }



          
        }
    }
}
