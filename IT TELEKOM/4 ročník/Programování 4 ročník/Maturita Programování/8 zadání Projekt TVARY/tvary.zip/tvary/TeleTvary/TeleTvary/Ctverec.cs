﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeleTvary
{
    public class Ctverec : Obdelnik
    {
        bool jeVeFormu = false;
        public Ctverec()
        {
        }


        public Ctverec(int sirka) : base(sirka, sirka)
        {
        }

        public Ctverec(int sirka, int x, int y, Color barva) : base(sirka, sirka, x, y, barva)
        {
            jeVeFormu = true;
        }

        public override string ToString()
            
        {
            if (jeVeFormu)
            {
                return $"ctverec (sirka={ sirka}, vyska = {vyska})";
            }

            return "ctverec je specialní -> " + base.ToString();
        }
    }
}
