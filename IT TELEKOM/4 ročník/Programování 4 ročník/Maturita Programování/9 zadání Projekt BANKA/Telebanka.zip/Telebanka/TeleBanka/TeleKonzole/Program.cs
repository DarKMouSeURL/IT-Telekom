﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TeleKnihovna;

namespace TeleKonzole
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Ucet> ucty = new List<Ucet>();

            Ucet u = new Ucet("11111", "Petr", 2000);
            kontokorentniUcet k = new kontokorentniUcet("22222", "Jana", 5000, 2000);
            Sporiciucet s = new Sporiciucet("33333", "Eva", 3000, 2.2);

            ucty.Add(k);
            ucty.Add(s);
            ucty.Add(u);

            foreach (Ucet item in ucty)
            {
                Console.WriteLine(item.ToString());
            }
        }
    }
}
