﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace TeleKnihovna
{
    public class Ucet
    {
        private const int KODBANKY = 1234;
        protected string cislo;
        protected string majitel;
        protected double zustatek;

        public Ucet (string cislo, string majitel, double zustatek ) 
        {
            this.cislo = cislo;
            this.majitel = majitel;
            this.zustatek = zustatek;
        }

        public Ucet (string cislo, string majitel)
        {
            this.cislo = cislo;
            this.majitel = majitel;
        }

        public string Vlozit ( double castka)
        {
            zustatek +=  castka;
            return "Na účet" + VratCisloUctuCele() + "byla vložena částka" + castka + "." + VratAktualniZustatek();
        }

        public virtual string Vybrat(double castka)
        {
            if (castka <= zustatek)
            {
                zustatek -= castka;
                return "Z účtu "+ VratCisloUctuCele() + "byla vybrána částka " + castka + "." + VratAktualniZustatek();
            }
            return "Nedostatek prostředků na účtu " + VratCisloUctuCele() + ", transakce nebyla dokončena. Aktúální zůstatek je: " + zustatek + "Kč";
        }

        protected string VratCisloUctuCele()
        {
            return cislo + "/" + KODBANKY;
        }
        
        public override string ToString()
        {
            return "Účet [" + VratCisloUctuCele() + " majitel:" + majitel + ",zůstatek: " + zustatek + "Kč]"; 
        }

        protected string VratAktualniZustatek()
        {
            return "Aktúální zůstatek je: " + zustatek + "Kč";
        }

        public Ucet()
        { }
    }
}
