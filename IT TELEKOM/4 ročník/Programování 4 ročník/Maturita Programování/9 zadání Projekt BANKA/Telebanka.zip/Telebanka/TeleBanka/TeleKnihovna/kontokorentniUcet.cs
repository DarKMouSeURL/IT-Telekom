﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace TeleKnihovna
{
    public class kontokorentniUcet:Ucet
    {
       private double limit;

        public kontokorentniUcet (string cislo, string majitel, double limit):base (cislo, majitel)
        {
            this.limit = limit;
        }

        public kontokorentniUcet (string cislo, string majitel, double zustatek, double limit):base (cislo,majitel,zustatek)
            { 
            this.limit = limit; 
        }

        public override string Vybrat(double castka)
        {
            if (castka <= (zustatek + limit)) 
            {
                zustatek -= castka;
                return "Z účtu " + VratCisloUctuCele() + "byla vybrána částka " + castka + "." + VratAktualniZustatek();
            }
            return "Nedostatek prostředků na účtu " + VratCisloUctuCele() + ", transakce nebyla dokončena. Aktúální zůstatek je: " + zustatek + "Kč";
        }

        public override string ToString()
        {
            return "Účet [" + VratCisloUctuCele() + " majitel:" + majitel + ",zůstatek: " + zustatek + "Kč]";
        }
    }
}
