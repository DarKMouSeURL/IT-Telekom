﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeleKnihovna
{
    public class Sporiciucet:Ucet
    {
        private double urokovaSazba;

       public  Sporiciucet (string cislo,string majitel, double urokovaSazba) : base(cislo,majitel)
        {
           
            this.urokovaSazba = urokovaSazba;
        }

        public Sporiciucet (string cislo, string majitel, double zustatek, double urokovaSazba): base(cislo,majitel,zustatek) 
        { this.urokovaSazba =  urokovaSazba;    
        
        }

        public string PripsatUrok()
        {
            zustatek += (zustatek * urokovaSazba) / 100;
            return "Na účet " + VratCisloUctuCele() + " byl připsán úrok " + urokovaSazba + "%." + VratAktualniZustatek();
        }

        public override string ToString()
        {
            return "Spořící účet [" + VratCisloUctuCele() + ", majitel: " + majitel + ", zůstatek: " + zustatek +", úroková sazba: " + urokovaSazba + " %]";
        }   
    }
}
