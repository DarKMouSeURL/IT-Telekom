﻿using Knihovna;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace TeleObchod
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("-----------------------");
            //Console.WriteLine("VÝPIS BAREV");
            //Console.WriteLine("-----------------------");

            //foreach (Barva b in Barva.NactiVse())
            //{
            //    Console.WriteLine(b);
            //}

            //Console.WriteLine("-----------------------");
            //Console.WriteLine("VÝPIS VELIKOSTÍ");
            //Console.WriteLine("-----------------------");

            //foreach (Velikost v in Velikost.NactiVse())
            //{
            //    Console.WriteLine(v);
            //}

            Produkt.NactiVse().Last().Smaz();

            Console.WriteLine("-----------------------");
            Console.WriteLine("VÝPIS PRODUKTŮ");
            Console.WriteLine("-----------------------");

            foreach (Produkt p in Produkt.NactiVse()) {
                Console.WriteLine($"{p.Id} | {p.Nazev} | {p.Velikost} | {p.Barva} | {p.Cena} Kč");
            }
        }
    }
}
