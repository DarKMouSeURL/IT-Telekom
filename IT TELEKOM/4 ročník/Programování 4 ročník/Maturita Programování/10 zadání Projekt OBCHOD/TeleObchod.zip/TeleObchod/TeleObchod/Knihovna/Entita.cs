﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Knihovna
{
    public abstract class Entita
    {
        public int Id { get; protected set; }
        public string Nazev { get; set; }

        protected Entita(string nazev)
        {
            Nazev = nazev;
        }

        protected Entita(int id, string nazev)
        {
            Id = id;
            Nazev = nazev;
        }

        public override string ToString() { 
            return Nazev;
        }
    }
}
