﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Knihovna
{
    internal class Databaze
    {
        private static readonly string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=Obchod;Integrated Security=True;";

        internal static DataTable NactiData(string sqlPrikaz, params SqlParameter[] parametry)
        {
            DataTable dt = new DataTable();

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlDataAdapter dataAdapter = new SqlDataAdapter(sqlPrikaz, conn))
                {
                    dataAdapter.SelectCommand.Parameters.AddRange(parametry);
                    dataAdapter.Fill(dt);
                }
            }
            return dt;
        }

        internal static void ZapisData(string sqlPrikaz, params SqlParameter[] parametry)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(sqlPrikaz, conn))
                {
                    conn.Open();
                    command.Parameters.AddRange(parametry);
                    command.ExecuteNonQuery();
                    conn.Close();
                }
            }
        }

    }
}
