﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Knihovna
{
    internal static class Uloziste
    {
        private static string ZiskejCestu(string soubor)
        {
            return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Data", soubor);
        }

        internal static string[] NactiRadky(string soubor)
        {
            string cesta = ZiskejCestu(soubor);
            if (!File.Exists(cesta)) { 
                return Array.Empty<string>();
            }
            return File.ReadAllLines(cesta);
        }

        internal static void UlozRadky(string soubor, List<string> radky) 
        {
            string cesta = ZiskejCestu(soubor);
            File.WriteAllLines(cesta, radky);
        }
    }
}
