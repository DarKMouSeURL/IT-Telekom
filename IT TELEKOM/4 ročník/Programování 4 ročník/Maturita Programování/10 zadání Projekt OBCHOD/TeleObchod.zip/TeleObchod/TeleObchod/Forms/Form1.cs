﻿using Knihovna;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Forms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            NactiData();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void listBoxProdukty_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBoxProdukty.SelectedItems.Count > 0) { 
                Produkt produkt = listBoxProdukty.SelectedItem as Produkt;

                label1.Text = produkt.Id.ToString();
                label2.Text = produkt.Nazev;
                label3.Text = produkt.Barva;
                label4.Text = produkt.Velikost;
                label5.Text = produkt.Cena + " Kč";
                label6.BackColor = ColorTranslator.FromHtml(produkt.KodBarvy);
            }
        }

        private void buttonNovyProdukt_Click(object sender, EventArgs e)
        {

          using(Form2 frm = new Form2())
                {
                frm.ShowDialog();
                }
            NactiData();
        }

        private void buttonUpravitProdukt_Click(object sender, EventArgs e)
        {
            if (listBoxProdukty.SelectedItems.Count > 0)
            {
                Produkt vybranyProdukt = listBoxProdukty.SelectedItem as Produkt;

                using (Form2 frm = new Form2(vybranyProdukt))
                {
                    frm.ShowDialog();
                }
                NactiData();
            }
        }

        private void NactiData()
        {
            listBoxProdukty.DataSource = null;
            listBoxProdukty.DataSource = Produkt.NactiVse();
        }

        private void buttonSmazatProdukt_Click(object sender, EventArgs e)
        {
            if (listBoxProdukty.SelectedItems.Count > 0)
            {

                if (MessageBox.Show("Opravdu si přejete smazat záznam?", "Smazání záznamu", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    Produkt vybranyProdukt = listBoxProdukty.SelectedItem as Produkt;
                    vybranyProdukt.Smaz();
                    NactiData();
                }
            }
        }
    }
}
