﻿using Knihovna;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Forms
{
    public partial class Form2 : Form
    {

        public Produkt Produkt { get; set; }

        public Form2 ()
        {
            InitializeComponent ();
            NactiData();
        }
    
        public Form2(Produkt produkt)
        {
            InitializeComponent();
            Produkt = produkt;
            NactiData();

            comboBoxBarva.DataSource = Barva.NactiVse();
            comboBoxVelikost.DataSource = Velikost.NactiVse();

            textBoxID.Text = Produkt.Id.ToString ();
            textBoxNazev.Text = Produkt.Nazev;
            numericUpDownCena.Value= Produkt.Cena;
            comboBoxBarva.Text = Produkt.Barva;
            comboBoxVelikost.Text = Produkt.Velikost;

           
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void buttonUlozit_Click(object sender, EventArgs e)
        {
            string nazev = textBoxNazev.Text;
            decimal cena = numericUpDownCena.Value;
            string velikost = comboBoxVelikost.Text;
            string barva = (comboBoxBarva.SelectedItem as Barva).Nazev;
            string kodBarvy = (comboBoxBarva.SelectedItem as Barva).Kod;

            if (this.Produkt is null)
            {
                this.Produkt = new Produkt (nazev,cena, velikost, barva, kodBarvy);
            }
            else
            {
                this.Produkt.Nazev = nazev;
                this.Produkt.Cena = cena;
                this.Produkt.Velikost = velikost;
                this.Produkt.Barva = barva;
                this.Produkt.KodBarvy = kodBarvy;
            }
            this.Produkt.Uloz();
            this.Close();
        }

        private void NactiData()
        {
            comboBoxBarva.DataSource = Barva.NactiVse();
            comboBoxVelikost.DataSource = Velikost.NactiVse();
        }
    }
}


