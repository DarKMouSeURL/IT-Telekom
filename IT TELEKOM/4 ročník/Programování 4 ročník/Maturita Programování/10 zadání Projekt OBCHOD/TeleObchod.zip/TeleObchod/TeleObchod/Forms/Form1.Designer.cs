﻿namespace Forms
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonNovyProdukt = new System.Windows.Forms.Button();
            this.buttonUpravitProdukt = new System.Windows.Forms.Button();
            this.buttonSmazatProdukt = new System.Windows.Forms.Button();
            this.listBoxProdukty = new System.Windows.Forms.ListBox();
            this.labelProdukty = new System.Windows.Forms.Label();
            this.labelId = new System.Windows.Forms.Label();
            this.labelNazev = new System.Windows.Forms.Label();
            this.labelBarva = new System.Windows.Forms.Label();
            this.labelVelikost = new System.Windows.Forms.Label();
            this.labelCena = new System.Windows.Forms.Label();
            this.groupBoxDetailyProduktu = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBoxDetailyProduktu.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonNovyProdukt
            // 
            this.buttonNovyProdukt.BackColor = System.Drawing.Color.ForestGreen;
            this.buttonNovyProdukt.Location = new System.Drawing.Point(29, 32);
            this.buttonNovyProdukt.Name = "buttonNovyProdukt";
            this.buttonNovyProdukt.Size = new System.Drawing.Size(132, 47);
            this.buttonNovyProdukt.TabIndex = 0;
            this.buttonNovyProdukt.Text = "Nový produkt";
            this.buttonNovyProdukt.UseVisualStyleBackColor = false;
            this.buttonNovyProdukt.Click += new System.EventHandler(this.buttonNovyProdukt_Click);
            // 
            // buttonUpravitProdukt
            // 
            this.buttonUpravitProdukt.BackColor = System.Drawing.Color.Gold;
            this.buttonUpravitProdukt.Location = new System.Drawing.Point(167, 32);
            this.buttonUpravitProdukt.Name = "buttonUpravitProdukt";
            this.buttonUpravitProdukt.Size = new System.Drawing.Size(132, 47);
            this.buttonUpravitProdukt.TabIndex = 1;
            this.buttonUpravitProdukt.Text = "Upravit produkt";
            this.buttonUpravitProdukt.UseVisualStyleBackColor = false;
            this.buttonUpravitProdukt.Click += new System.EventHandler(this.buttonUpravitProdukt_Click);
            // 
            // buttonSmazatProdukt
            // 
            this.buttonSmazatProdukt.BackColor = System.Drawing.Color.IndianRed;
            this.buttonSmazatProdukt.Location = new System.Drawing.Point(305, 32);
            this.buttonSmazatProdukt.Name = "buttonSmazatProdukt";
            this.buttonSmazatProdukt.Size = new System.Drawing.Size(132, 47);
            this.buttonSmazatProdukt.TabIndex = 2;
            this.buttonSmazatProdukt.Text = "Smazat produkt";
            this.buttonSmazatProdukt.UseVisualStyleBackColor = false;
            this.buttonSmazatProdukt.Click += new System.EventHandler(this.buttonSmazatProdukt_Click);
            // 
            // listBoxProdukty
            // 
            this.listBoxProdukty.FormattingEnabled = true;
            this.listBoxProdukty.Location = new System.Drawing.Point(29, 147);
            this.listBoxProdukty.Name = "listBoxProdukty";
            this.listBoxProdukty.Size = new System.Drawing.Size(236, 394);
            this.listBoxProdukty.TabIndex = 3;
            this.listBoxProdukty.SelectedIndexChanged += new System.EventHandler(this.listBoxProdukty_SelectedIndexChanged);
            // 
            // labelProdukty
            // 
            this.labelProdukty.AutoSize = true;
            this.labelProdukty.Location = new System.Drawing.Point(26, 131);
            this.labelProdukty.Name = "labelProdukty";
            this.labelProdukty.Size = new System.Drawing.Size(49, 13);
            this.labelProdukty.TabIndex = 4;
            this.labelProdukty.Text = "Produkty";
            // 
            // labelId
            // 
            this.labelId.AutoSize = true;
            this.labelId.Location = new System.Drawing.Point(6, 59);
            this.labelId.Name = "labelId";
            this.labelId.Size = new System.Drawing.Size(18, 13);
            this.labelId.TabIndex = 5;
            this.labelId.Text = "ID";
            // 
            // labelNazev
            // 
            this.labelNazev.AutoSize = true;
            this.labelNazev.Location = new System.Drawing.Point(6, 94);
            this.labelNazev.Name = "labelNazev";
            this.labelNazev.Size = new System.Drawing.Size(38, 13);
            this.labelNazev.TabIndex = 6;
            this.labelNazev.Text = "Název";
            // 
            // labelBarva
            // 
            this.labelBarva.AutoSize = true;
            this.labelBarva.Location = new System.Drawing.Point(6, 132);
            this.labelBarva.Name = "labelBarva";
            this.labelBarva.Size = new System.Drawing.Size(35, 13);
            this.labelBarva.TabIndex = 7;
            this.labelBarva.Text = "Barva";
            // 
            // labelVelikost
            // 
            this.labelVelikost.AutoSize = true;
            this.labelVelikost.Location = new System.Drawing.Point(6, 172);
            this.labelVelikost.Name = "labelVelikost";
            this.labelVelikost.Size = new System.Drawing.Size(44, 13);
            this.labelVelikost.TabIndex = 8;
            this.labelVelikost.Text = "Velikost";
            // 
            // labelCena
            // 
            this.labelCena.AutoSize = true;
            this.labelCena.Location = new System.Drawing.Point(6, 210);
            this.labelCena.Name = "labelCena";
            this.labelCena.Size = new System.Drawing.Size(32, 13);
            this.labelCena.TabIndex = 9;
            this.labelCena.Text = "Cena";
            // 
            // groupBoxDetailyProduktu
            // 
            this.groupBoxDetailyProduktu.Controls.Add(this.label6);
            this.groupBoxDetailyProduktu.Controls.Add(this.label5);
            this.groupBoxDetailyProduktu.Controls.Add(this.label4);
            this.groupBoxDetailyProduktu.Controls.Add(this.label3);
            this.groupBoxDetailyProduktu.Controls.Add(this.label2);
            this.groupBoxDetailyProduktu.Controls.Add(this.label1);
            this.groupBoxDetailyProduktu.Controls.Add(this.labelCena);
            this.groupBoxDetailyProduktu.Controls.Add(this.labelId);
            this.groupBoxDetailyProduktu.Controls.Add(this.labelVelikost);
            this.groupBoxDetailyProduktu.Controls.Add(this.labelBarva);
            this.groupBoxDetailyProduktu.Controls.Add(this.labelNazev);
            this.groupBoxDetailyProduktu.Location = new System.Drawing.Point(334, 147);
            this.groupBoxDetailyProduktu.Name = "groupBoxDetailyProduktu";
            this.groupBoxDetailyProduktu.Size = new System.Drawing.Size(236, 394);
            this.groupBoxDetailyProduktu.TabIndex = 10;
            this.groupBoxDetailyProduktu.TabStop = false;
            this.groupBoxDetailyProduktu.Text = "Detaily produktu";
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.SystemColors.Control;
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label6.Location = new System.Drawing.Point(6, 252);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(224, 130);
            this.label6.TabIndex = 15;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.SystemColors.Control;
            this.label5.Location = new System.Drawing.Point(50, 210);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(180, 25);
            this.label5.TabIndex = 14;
            this.label5.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.SystemColors.Control;
            this.label4.Location = new System.Drawing.Point(50, 172);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(180, 25);
            this.label4.TabIndex = 13;
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.Control;
            this.label3.Location = new System.Drawing.Point(50, 132);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(180, 25);
            this.label3.TabIndex = 12;
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.SystemColors.Control;
            this.label2.Location = new System.Drawing.Point(50, 94);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(180, 25);
            this.label2.TabIndex = 11;
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(50, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(180, 25);
            this.label1.TabIndex = 10;
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(632, 572);
            this.Controls.Add(this.groupBoxDetailyProduktu);
            this.Controls.Add(this.labelProdukty);
            this.Controls.Add(this.listBoxProdukty);
            this.Controls.Add(this.buttonSmazatProdukt);
            this.Controls.Add(this.buttonUpravitProdukt);
            this.Controls.Add(this.buttonNovyProdukt);
            this.MaximumSize = new System.Drawing.Size(648, 611);
            this.MinimumSize = new System.Drawing.Size(648, 611);
            this.Name = "Form1";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Obchod";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBoxDetailyProduktu.ResumeLayout(false);
            this.groupBoxDetailyProduktu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonNovyProdukt;
        private System.Windows.Forms.Button buttonUpravitProdukt;
        private System.Windows.Forms.Button buttonSmazatProdukt;
        private System.Windows.Forms.ListBox listBoxProdukty;
        private System.Windows.Forms.Label labelProdukty;
        private System.Windows.Forms.Label labelId;
        private System.Windows.Forms.Label labelNazev;
        private System.Windows.Forms.Label labelBarva;
        private System.Windows.Forms.Label labelVelikost;
        private System.Windows.Forms.Label labelCena;
        private System.Windows.Forms.GroupBox groupBoxDetailyProduktu;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}

