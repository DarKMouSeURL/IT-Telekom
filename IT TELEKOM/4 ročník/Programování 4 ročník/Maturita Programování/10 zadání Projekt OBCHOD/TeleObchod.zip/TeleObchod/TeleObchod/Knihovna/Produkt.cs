﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Knihovna
{
    public class Produkt : Entita
    {
        public decimal Cena { get; set; }
        public string Velikost { get; set; }
        public string Barva { get; set; }
        public string KodBarvy { get; set; }

        public Produkt(string nazev, decimal cena, string velikost, string barva, string kodBarvy) : base(nazev)
        {
            Cena = cena;
            Velikost = velikost;
            Barva = barva;
            KodBarvy = kodBarvy;
        }

        private Produkt(int id, string nazev, decimal cena, string velikost, string barva, string kodBarvy) : base(id, nazev)
        {
            Cena = cena;
            Velikost = velikost;
            Barva = barva;
            KodBarvy = kodBarvy;
        }

        public void Uloz() {
            List<Produkt> produkty = NactiVse();

            if (Id == 0) 
            {
                this.Id = VypocitejNoveId(produkty);
                produkty.Add(this);
            }
            else
            {
                Aktualizuj(produkty);
            }
            PrevedNaCsv(produkty);
        }

        private void Aktualizuj(List<Produkt> produkty)
        {
            for(int i = 0; i < produkty.Count; i++)
            {
                if(produkty[i].Id == this.Id)
                {
                    produkty[i] = this;
                    break;
                }
            }
        }

        public void Smaz()
        {
            List<Produkt> produkty = NactiVse();

            for (int i = 0; i < produkty.Count; i++)
            {
                if (produkty[i].Id == this.Id)
                {
                    produkty.RemoveAt(i);
                    PrevedNaCsv(produkty);
                    break;
                }
            }
        }

        public static List<Produkt> NactiVse()
        {
            List<Produkt> produkty = new List<Produkt>();
            string[] radky = Uloziste.NactiRadky("produkt.csv");

            foreach (string radek in radky)
            {
                string[] hodnoty = radek.Split(';');
                int id = int.Parse(hodnoty[0]);
                string nazev = hodnoty[1];
                decimal cena = decimal.Parse(hodnoty[2]);
                string velikost = hodnoty[3];
                string barva = hodnoty[4];
                string kodBarvy = hodnoty[5];

                Produkt p = new Produkt(id, nazev, cena, velikost, barva, kodBarvy);
                produkty.Add(p);
            }
            return produkty;
        }

        private static int VypocitejNoveId(List<Produkt> produkty)
        {
            int maxId = 0;
            foreach (Produkt p in produkty)
            {
                if (p.Id > maxId) { 
                    maxId = p.Id;
                }
            }
            return maxId + 1;
        }

        private static void PrevedNaCsv(List<Produkt> produkty)
        {
            List<string> radky = new List<string>();

            foreach (Produkt p in produkty)
            {
                string radek = $"{p.Id};{p.Nazev};{p.Cena};{p.Velikost};{p.Barva};{p.KodBarvy}";
                radky.Add(radek);
            }

            Uloziste.UlozRadky("produkt.csv", radky);
        }
    }
}
