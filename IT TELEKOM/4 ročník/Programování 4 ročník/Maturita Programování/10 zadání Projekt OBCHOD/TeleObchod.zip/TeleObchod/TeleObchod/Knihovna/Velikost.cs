﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Knihovna
{
    public class Velikost : Entita
    {
        private Velikost(int id, string nazev) : base(id, nazev)
        {
        }

        public static List<Velikost> NactiVse()
        {
            List<Velikost> velikosti = new List<Velikost>();
            string[] radky = Uloziste.NactiRadky("velikost.csv");

            foreach (string radek in radky)
            {
                string[] hodnoty = radek.Split(';');
                int id = int.Parse(hodnoty[0]);
                string nazev = hodnoty[1];

                Velikost v = new Velikost(id, nazev);
                velikosti.Add(v);
            }
            return velikosti;
        }
    }
}
