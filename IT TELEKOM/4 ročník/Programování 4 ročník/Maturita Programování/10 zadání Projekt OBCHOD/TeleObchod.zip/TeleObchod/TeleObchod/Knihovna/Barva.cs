﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Knihovna
{
    public class Barva : Entita
    {
        public string Kod { get; set; }

        private Barva(int id, string nazev, string kod) : base(id, nazev)
        {
            Kod = kod;
        }

        public static List<Barva> NactiVse()
        {
            List<Barva> barvy = new List<Barva>();
            string[] radky = Uloziste.NactiRadky("barva.csv");

            foreach (string radek in radky)
            {
                string[] hodnoty = radek.Split(';');
                int id = int.Parse(hodnoty[0]);
                string nazev = hodnoty[1];
                string kod = hodnoty[2];

                Barva b = new Barva(id, nazev, kod);
                barvy.Add(b);
            }
            return barvy;
        }

    }
}
