﻿using static System.Net.Mime.MediaTypeNames;
using System;
using System.Security.Cryptography.X509Certificates;

namespace _2C_Auto
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Auto a1 = new Auto("ABC123");
            Console.WriteLine(a1);  //Console.WriteLine(a1.ToString());
            Console.WriteLine(a1.VratInfo());
            //a1.VypisInfo(); - není vhodné používat metodu, co rovnou vypisuje na consoli

            Auto a2 = new Auto("FGH358", 1551, 2003, new DateTime(2023, 5, 20));
            Console.WriteLine(a2);  //Console.WriteLine(a1.ToString());
            Console.WriteLine(a2.VratInfo());
            //a2.VypisInfo();
        }
    }

    class Auto
    {
        string znacka = "";
        int najetoKm = 0;
        int rokVyroby = DateTime.Now.Year;
        DateTime? datumTK = null; //? lze vložit i null hodnotu

        public Auto (string znacka, int najetoKm, int rokVyroby, DateTime? datumTK)
        {
            this.znacka = znacka;
            this.najetoKm = najetoKm;
            this.rokVyroby = rokVyroby;
            this.datumTK = datumTK;
        }

        public Auto(string znacka)
        {
            this.znacka = znacka;
        }

        public override string ToString()
        {
            return $"znacka: {znacka}, najetoKm: {najetoKm}, rokVyroby: {rokVyroby}, datumTK: {datumTK}";
        }

        //TATO METODA JE NEEFEKTIVNÍ
        //public void VypisInfo() //void znamená, že metoda nic nevrací, nesmí mít v těle ani return
        //{
        //    Console.WriteLine($"{znacka} ({rokVyroby}), najeto {najetoKm} km");
        //}

        public string VratInfo() //vrací něco, musí mít určeno, co opřesně (pomocí return)
        {
            return $"{znacka} ({rokVyroby}), najeto {najetoKm} km";
        }
    }
}