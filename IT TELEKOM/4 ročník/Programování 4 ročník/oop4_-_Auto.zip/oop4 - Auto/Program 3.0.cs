﻿using static System.Net.Mime.MediaTypeNames;
using System;
using System.Security.Cryptography.X509Certificates;
using System.Drawing;

namespace _2C_Auto
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*
            Auto a1 = new Auto("ABC123");
            Console.WriteLine(a1);  //Console.WriteLine(a1.ToString());
            Console.WriteLine(a1.VratInfo());
            //a1.VypisInfo(); - není vhodné používat metodu, co rovnou vypisuje na consoli

            Auto a2 = new Auto("FGH358", 1551, 2003, new DateTime(2023, 5, 20));
            Console.WriteLine(a2);  //Console.WriteLine(a1.ToString());
            Console.WriteLine(a2.VratInfo());
            //a2.VypisInfo();
            */

            List<Auto> auta = new List<Auto>();
            auta.Add(new Auto("ABC123"));
            auta.Add(new Auto("FGH358", 1551, 2003, new DateTime(2023, 5, 20)));

            Console.WriteLine("Zadej nový vůz:");
            try
            {
                Console.Write("\tZnačka: ");
                string znacka = Console.ReadLine().Trim().ToUpper();
                Console.Write("\tNajeto km: ");
                int km = int.Parse(Console.ReadLine().Trim());
                Console.Write("\tRok výroby: ");
                int rokVyroby = int.Parse(Console.ReadLine().Trim());

                Boolean autoPrevodovka = false;
                Console.Write("\tAutomatická převodovka (a/n): ");
                if (Console.ReadLine().Trim().ToLower().Equals("a"))
                    autoPrevodovka = true;

                Console.Write("\tBarva (anglicky): ");
                Color barva = ColorTranslator.FromHtml(Console.ReadLine().Trim().ToLower());

                Console.WriteLine("\tPoslední datum technické kontroly:");
                Console.Write("\t\tDen: ");
                int den = int.Parse(Console.ReadLine().Trim());
                Console.Write("\t\tMěsíc: ");
                int mesic = int.Parse(Console.ReadLine().Trim());
                Console.Write("\t\tRok: ");
                int rok = int.Parse(Console.ReadLine().Trim());
                DateTime dtTk = new DateTime(rok, mesic, den);
                
                Auto autoX = new Auto(znacka, km, rokVyroby, dtTk,autoPrevodovka,barva);
                auta.Add(autoX);

            }
            catch (Exception e)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(e.Message);
                Console.ResetColor();            
            }

            //výpis informací
            foreach (Auto a in auta)
            { 
                Console.WriteLine(a.ToString());            
            }
        }
    }

    class Auto
    {
        string znacka = "";
        int najetoKm = 0;
        int rokVyroby = DateTime.Now.Year;
        DateTime? datumTK = null; //? lze vložit i null hodnotu        
        bool autoPrevodovka = false;
        Color? barva = null;

        public Auto(string znacka, int najetoKm, int rokVyroby, DateTime? datumTK, bool autoPrevodovka, Color? barva)
        {
            this.znacka = znacka;
            this.najetoKm = najetoKm;
            this.rokVyroby = rokVyroby;
            this.datumTK = datumTK;
            this.autoPrevodovka = autoPrevodovka;
            this.barva = barva;
        }

        public Auto (string znacka, int najetoKm, int rokVyroby, DateTime? datumTK)
        {
            this.znacka = znacka;
            this.najetoKm = najetoKm;
            this.rokVyroby = rokVyroby;
            this.datumTK = datumTK;
        }

        public Auto(string znacka)
        {
            this.znacka = znacka;
        }

        public override string ToString()
        {
            return $"{this.GetType().Name} [znacka: {znacka}, najetoKm: {najetoKm}, rokVyroby: {rokVyroby}, datumTK: {datumTK}, autoPrevodovka: {autoPrevodovka}, barva: {barva}]";
        }

        //TATO METODA JE NEEFEKTIVNÍ
        //public void VypisInfo() //void znamená, že metoda nic nevrací, nesmí mít v těle ani return
        //{
        //    Console.WriteLine($"{znacka} ({rokVyroby}), najeto {najetoKm} km");
        //}

        public string VratInfo() //vrací něco, musí mít určeno, co opřesně (pomocí return)
        {
            return $"{znacka} ({rokVyroby}), najeto {najetoKm} km";
        }
    }
}