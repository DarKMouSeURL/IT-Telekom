﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2C_staticClasses
{
    static class Uloziste
    {
        static private List<int> cisla = new List<int>();

        static public void PridejCislo(int cislo)
        {
            cisla.Add(cislo);
        }

        static public string VratCisla()
        {
            StringBuilder sb = new StringBuilder();
            foreach (int x in cisla)
            {
                sb.Append(x+" ");
            }
            return sb.ToString();

            //string text = "";
            //foreach (int x in cisla)
            //{
            //    text += x.ToString() + " ";
            //}
            //return text;
        }

    }
}
