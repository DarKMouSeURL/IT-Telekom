﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2C_staticClasses
{
    class Program
    {
        static void Main(string[] args)
        {
            //Matika m1 = new Matika();
            //Console.WriteLine(m1.Soucet(5, 7));

          

            Console.WriteLine(Matika.Soucet(5, 7));
            Console.WriteLine(Matika.Podil(5, 7));
            Console.WriteLine(Matika.AbsHodnota(-8));

            Uloziste.PridejCislo(5);
            Uloziste.PridejCislo(-8);
            Uloziste.PridejCislo(12);
            Uloziste.PridejCislo(10);
            Console.WriteLine(Uloziste.VratCisla());


            Console.ReadLine();
        }
    }
}
