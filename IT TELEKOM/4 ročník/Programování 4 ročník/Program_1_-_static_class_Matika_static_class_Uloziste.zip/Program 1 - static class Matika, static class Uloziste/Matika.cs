﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace _2C_staticClasses
{
    static class Matika
    {
        static public int Soucet(int a, int b)
        {
            return a + b;
        }

        static public double Podil(int a, int b)
        {
            return (double)a / (double)b;
        }

        static public int AbsHodnota(int a)
        {
            if (a < 0)
                return -1 * a;
            return a;
        }
    }
}
