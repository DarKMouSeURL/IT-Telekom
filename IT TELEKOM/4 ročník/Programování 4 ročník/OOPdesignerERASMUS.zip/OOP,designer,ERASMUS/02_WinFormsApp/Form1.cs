namespace _02_WinFormsApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.label1.Text = "Muj projekt2";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.label1.Text = "Projekt2";
            //string slovo = "Tatry";
            string slovo = this.textBox1.Text;
            int i = 0;
            while(i<20)
            {
                //this.label1.Text += slovo + " ";
                this.label1.Text += i + ". " + slovo + Environment.NewLine;
                i++;
            }
        }
    }
}
