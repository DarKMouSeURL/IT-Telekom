﻿namespace _03_ConsoleApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!  - Projekt3");

            Console.WriteLine("Stisni Enter...");
            Console.ReadLine();
        }
    }
}
