﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _04_WpfApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            this.Title = "Muj pokus...";
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //this.Background = Colors.Lime;
            Brush stetec = new SolidColorBrush(Colors.Lime);
            this.Background = stetec;

            this.tb1.Text = "novy text do tb1";

        }
    }
}