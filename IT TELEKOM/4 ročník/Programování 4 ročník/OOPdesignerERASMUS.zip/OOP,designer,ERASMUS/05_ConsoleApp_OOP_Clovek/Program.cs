﻿namespace _05_ConsoleApp_OOP_Clovek
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("OOP, trieda Clovek");

            //          konstruktor
            Clovek c1 = new Clovek();
            Console.WriteLine(c1);
            c1.PridatRoky(4);
            Console.WriteLine(c1);
            c1.PridatRoky(10);
            Console.WriteLine(c1);
            Console.WriteLine("---------------------");

            Clovek c2 = new Clovek("Peter","Novak",2008);
            Console.WriteLine(c2);

            Clovek c3 = new Clovek("Zuza","Vrbovska",1999);
            Console.WriteLine(c3);

            Console.ReadLine();
        }
    }
    public class Clovek
    {
        //atributy
        public string meno = "Fero";
        public string priezvisko = "Durian";
        public int rokNarodenia = 2001;
        public int vek = 0;
        //konstruktory
        public Clovek(string meno, string priezvisko, int rokNarodenia)
        {
            this.meno = meno;
            this.priezvisko = priezvisko;
            this.rokNarodenia = rokNarodenia;
        }
        public Clovek()
        {

        }
        //metody
        public override string ToString()
        {
            string vsetko = $"{this.meno} {this.priezvisko} {this.rokNarodenia}, vek={this.vek}";
            return vsetko;
        }
        public void PridatRoky(int pocetRoku)
        {
            this.vek += pocetRoku;
        }
    }
}
