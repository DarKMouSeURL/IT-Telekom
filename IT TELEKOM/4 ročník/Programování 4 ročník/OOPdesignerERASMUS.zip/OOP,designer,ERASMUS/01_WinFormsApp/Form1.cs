namespace _01_WinFormsApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            //this.BackColor = Color.Red;
            this.BackColor = Color.Yellow;
            this.Width = 1500;
            this.Height = 600;
            this.Text = "Window Forms App - Erasmus2025";
        }
        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Po stisku OK chci modrou farbu");
            this.BackColor = Color.Blue;
            this.Width = 1200;
            this.Height = 1000;
            this.Text = "1. projekt";
            this.textBox1.Text = "novy text";
        }
        private void button2_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Magenta;
            this.button1.BackColor = Color.Orange;
        }
        private void button3_Click(object sender, EventArgs e)
        {
            string cislo1Str = this.textBox1.Text;
            string cislo2Str = this.textBox2.Text;

            string soucetStr = cislo1Str + cislo2Str;

            //this.button1.Text = soucetStr;
            this.Text = soucetStr;

            int cislo1 = Convert.ToInt32(cislo1Str);
            int cislo2 = Convert.ToInt32(cislo2Str);

            int soucet = cislo1 + cislo2;
            this.button1.Text = soucet.ToString();
        }
        private void button4_Click(object sender, EventArgs e)
        {
            string s = "";
            for (int i = 0; i < 101; i++)
            {
                s = s + i + " ";
            }
            this.textBox3.Text = s;
        }
    }
}
