﻿using System.Linq.Expressions;

namespace _2C_OOP1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            Zak z1 = new Zak(); //konstruktor BEZPARAMETRICKÝ
            z1.jmeno = "Lenka";
            z1.rocnik = 2;

            Console.WriteLine(z1.jmeno);
            Console.WriteLine(z1.rocnik);
            
            Zak z2 = new Zak("Jana", 3, 1.5);
            Zak z3 = new Zak("Mirek", 2);
            Zak z4 = new Zak("Alena", 1);
            Zak z5 = new Zak("David", 4, 1.99);

            Console.WriteLine(z1.ToString());

            Console.ReadLine();
        }
    }
}