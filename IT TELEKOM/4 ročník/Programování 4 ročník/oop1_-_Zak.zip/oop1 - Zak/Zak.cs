﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2C_OOP1
{
    internal class Zak
    {
        //modifikátor přístupu private - zvenku není povolena 
        //ani pro čtení ani pro zápis
        //public - povolujeme pro čtení i pro zápis
        public string jmeno;      
        public int rocnik;
        private double prumer;
       
        //konstruktor1
        public Zak(string jmeno, int rocnik, double prumer)
        {
            this.jmeno = jmeno;
            this.rocnik = rocnik;
            this.prumer = prumer;
        }
        
        //konstruktor2 - přetížený
        public Zak(string jmeno, int rocnik)
        {
            this.jmeno = jmeno;
            this.rocnik = rocnik;           
        }

        //konstruktor3 - přetížený, bezparametrický
        public Zak()
        {
            
        }

        public override string ToString()
        {
            return string.Format($"jméno: {jmeno}, ročník: {rocnik}, průměr: {prumer}");
        }
    }
}
